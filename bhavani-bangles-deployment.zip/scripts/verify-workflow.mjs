/**
 * End-to-End API & Database Transaction Verification Script for BHAVANI BANGLES
 */
const BASE = "http://127.0.0.1:3000";

async function run() {
  console.log("1. Testing Owner Login...");
  const loginRes = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "owner", password: "Owner@123" }),
  });
  if (!loginRes.ok) throw new Error(`Login failed: ${await loginRes.text()}`);
  const cookie = loginRes.headers.get("set-cookie")?.split(";")[0];
  if (!cookie) throw new Error("No session cookie returned!");
  console.log("   ✓ Login succeeded with HTTP-only session cookie");

  const headers = { "Content-Type": "application/json", Cookie: cookie };

  console.log("2. Testing Live Owner Dashboard API...");
  const dashRes = await fetch(`${BASE}/api/dashboard?range=this_month`, { headers });
  const dash = await dashRes.json();
  if (!dashRes.ok || !dash.kpis) throw new Error("Dashboard API failed");
  console.log(`   ✓ Dashboard loaded: Today Sales ₹${dash.kpis.todayTotalSales}, Products: ${dash.kpis.totalProducts}, Insights: ${dash.aiInsights.length}`);

  console.log("3. Fetching Products for POS Billing Test...");
  const prodRes = await fetch(`${BASE}/api/products`, { headers });
  const { products } = await prodRes.json();
  const target = products.find((p) => p.currentStock >= 5);
  if (!target) throw new Error("No stocked product found");
  const stockBefore = target.currentStock;
  console.log(`   ✓ Selected "${target.name}" (Stock before: ${stockBefore})`);

  console.log("4. Executing Transactional POS Sale (2 units)...");
  const saleRes = await fetch(`${BASE}/api/sales`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      customerName: "Verification Test Client",
      customerPhone: "9999988888",
      items: [{ productId: target.id, quantity: 2, unitPrice: target.sellingPrice, discount: 0, gstPercent: target.gstPercent }],
      gstType: "CGST_SGST",
      paymentMethod: "UPI",
    }),
  });
  const saleData = await saleRes.json();
  if (!saleRes.ok) throw new Error(`POS Sale failed: ${JSON.stringify(saleData)}`);
  console.log(`   ✓ Created Invoice ${saleData.sale.invoiceNumber} — Grand Total ₹${saleData.sale.grandTotal}`);

  console.log("5. Verifying Automatic Stock Deduction in DB...");
  const afterRes = await fetch(`${BASE}/api/products/${target.id}`, { headers });
  const { product: afterProd } = await afterRes.json();
  if (afterProd.currentStock !== stockBefore - 2) {
    throw new Error(`Stock mismatch! Expected ${stockBefore - 2}, got ${afterProd.currentStock}`);
  }
  console.log(`   ✓ Stock accurately reduced: ${stockBefore} -> ${afterProd.currentStock}`);

  console.log("6. Verifying Owner Invoice Cancellation & Stock Restoration...");
  const cancelRes = await fetch(`${BASE}/api/sales/${saleData.sale.id}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify({ action: "CANCEL", reason: "Automated E2E verification cleanup" }),
  });
  if (!cancelRes.ok) throw new Error(`Cancel failed: ${await cancelRes.text()}`);
  const restoredRes = await fetch(`${BASE}/api/products/${target.id}`, { headers });
  const { product: restoredProd } = await restoredRes.json();
  if (restoredProd.currentStock !== stockBefore) {
    throw new Error(`Stock restore mismatch! Expected ${stockBefore}, got ${restoredProd.currentStock}`);
  }
  console.log(`   ✓ Invoice cancelled & stock restored to ${restoredProd.currentStock}`);

  console.log("7. Verifying RBAC (Billing Staff cannot access Settings)...");
  const staffLogin = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "cashier", password: "Cashier@123" }),
  });
  const staffCookie = staffLogin.headers.get("set-cookie")?.split(";")[0];
  const forbiddenRes = await fetch(`${BASE}/api/audit-logs`, { headers: { Cookie: staffCookie } });
  if (forbiddenRes.status !== 403) {
    throw new Error(`RBAC check failed! Expected 403, got ${forbiddenRes.status}`);
  }
  console.log("   ✓ RBAC enforced: Billing Staff blocked (403) from Admin Audit Logs");

  console.log("\nALL END-TO-END VERIFICATION CHECKS PASSED!");
}

run().catch((err) => {
  console.error("VERIFICATION FAILED:", err);
  process.exit(1);
});
