"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  ShoppingBag,
  Gem,
  BarChart3,
  Settings,
  Search,
  Bell,
  LogOut,
  Menu,
  X,
  Sparkles,
  CheckCheck,
} from "lucide-react";
import { useAuth } from "./AuthContext";
import { formatCurrency } from "@/lib/format";
import { applyTheme, getSavedTheme } from "@/lib/theme";
import { LANGUAGE_OPTIONS, useLanguage } from "@/lib/i18n";

const NAV_ITEMS = [
  { href: "/pos", labelKey: "nav.pos", icon: ShoppingBag, module: "pos", highlight: true },
  { href: "/reports", labelKey: "nav.reports", icon: BarChart3, module: "reports" },
  { href: "/settings", labelKey: "nav.settings", icon: Settings, module: "settings" },
];

export function AppShell({
  children,
  title,
  subtitle,
  actions,
}: {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  const { user, loading, logout, can } = useAuth();
  const { lang, setLang, t } = useLanguage();
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Global Search
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<{
    products: { id: string; name: string; code: string; sellingPrice: number; currentStock: number }[];
    customers: { id: string; name: string; phone: string; outstandingAmount: number }[];
    invoices: { id: string; invoiceNumber: string; customerName: string; grandTotal: number }[];
    suppliers: { id: string; name: string; phone: string }[];
  } | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Notifications
  const [notifications, setNotifications] = useState<
    { id: string; type: string; title: string; message: string; isRead: boolean; createdAt: string }[]
  >([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    applyTheme(getSavedTheme());
  }, []);

  const loadNotifications = () => {
    if (!user) return;
    fetch("/api/notifications")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d) {
          setNotifications(d.notifications || []);
          setUnreadCount(d.unreadCount || 0);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery.trim().length >= 2) {
        fetch(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`)
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d) {
              setSearchResults(d);
              setShowSearch(true);
            }
          });
      } else {
        setSearchResults(null);
        setShowSearch(false);
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearch(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const markAllRead = async () => {
    await fetch("/api/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) });
    setUnreadCount(0);
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ivory-100">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-rosegold-500/10 border border-rosegold-300 flex items-center justify-center mx-auto animate-pulse">
            <Sparkles className="w-6 h-6 text-rosegold-500" />
          </div>
          <p className="font-serif text-xl tracking-wide text-espresso-800">BHAVANI BANGLES</p>
          <p className="text-xs text-espresso-400">Loading retail workspace...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  const visibleNav = NAV_ITEMS.filter((item) => can(item.module, "canView"));

  return (
    <div className="min-h-screen flex bg-ivory-100">
      {/* Mobile Sidebar Backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-espresso-900/40 backdrop-blur-xs lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-50 h-screen w-64 bg-white border-r border-ivory-300 flex flex-col transition-transform duration-200 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        {/* Brand Logo */}
        <div className="px-5 py-5 border-b border-ivory-200 flex items-center justify-between">
          <Link href="/pos" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rosegold-500 to-champagne-500 flex items-center justify-center text-white shadow-sm">
              <Gem className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-serif text-lg font-bold tracking-wide text-espresso-900 leading-tight">
                BHAVANI
              </h1>
              <p className="text-[10px] font-semibold tracking-[0.22em] text-rosegold-600 uppercase">
                BANGLES POS
              </p>
            </div>
          </Link>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-espresso-500 hover:bg-ivory-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                  active
                    ? "bg-blush-200 text-rosegold-700 shadow-xs"
                    : item.highlight
                    ? "bg-rosegold-500 text-white hover:bg-rosegold-600 shadow-sm my-2"
                    : "text-espresso-600 hover:bg-ivory-100 hover:text-espresso-900"
                }`}
              >
                <Icon className={`w-4.5 h-4.5 shrink-0 ${active ? "text-rosegold-600" : ""}`} />
                <span className="truncate">{t(item.labelKey)}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Profile Footer */}
        <div className="p-3.5 border-t border-ivory-200 bg-ivory-50/60">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="text-sm font-semibold text-espresso-900 truncate">{user.fullName}</p>
              <p className="text-xs text-rosegold-600 font-medium truncate">{user.roleDisplayName}</p>
            </div>
            <button
              onClick={logout}
              title="Sign Out"
              className="p-2 rounded-xl text-espresso-500 hover:bg-rose-50 hover:text-rose-600 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Wrapper */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-ivory-100/90 backdrop-blur-md border-b border-ivory-300/70 px-4 lg:px-7 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-xl bg-white border border-ivory-300 text-espresso-700"
              >
                <Menu className="w-5 h-5" />
              </button>
              {title && (
                <div>
                  <h2 className="font-serif text-xl lg:text-2xl font-bold text-espresso-900 leading-tight">
                    {title}
                  </h2>
                  {subtitle && <p className="text-xs text-espresso-500">{subtitle}</p>}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5">
              {/* Quick Language Switcher (EN / தமிழ் / हिन्दी) */}
              <div className="inline-flex items-center rounded-xl bg-white border border-ivory-300 p-0.5">
                {LANGUAGE_OPTIONS.map((opt) => (
                  <button
                    key={opt.code}
                    type="button"
                    onClick={() => setLang(opt.code)}
                    title={opt.label}
                    className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                      lang === opt.code
                        ? "bg-rosegold-500 text-white"
                        : "text-espresso-600 hover:bg-ivory-100"
                    }`}
                  >
                    {opt.short}
                  </button>
                ))}
              </div>

              {/* Global Search */}
              <div ref={searchRef} className="relative hidden md:block w-72">
                <Search className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => searchResults && setShowSearch(true)}
                  placeholder="Search products, invoices, customers..."
                  className="w-full rounded-xl border border-ivory-300 bg-white pl-9 pr-3 py-2 text-xs text-espresso-900 placeholder:text-espresso-400 focus:border-rosegold-400 focus:outline-none focus:ring-2 focus:ring-rosegold-100"
                />
                {showSearch && searchResults && (
                  <div className="absolute right-0 mt-2 w-96 bg-white rounded-2xl border border-ivory-300 shadow-elevated p-3 space-y-3 max-h-96 overflow-y-auto z-50">
                    {searchResults.products.length === 0 &&
                    searchResults.customers.length === 0 &&
                    searchResults.invoices.length === 0 ? (
                      <p className="text-xs text-espresso-400 text-center py-4">No matching records found</p>
                    ) : (
                      <>
                        {searchResults.products.length > 0 && (
                          <div>
                            <p className="text-[10px] font-bold uppercase tracking-wider text-espresso-400 mb-1">Products</p>
                            {searchResults.products.map((p) => (
                              <button
                                key={p.id}
                                onClick={() => {
                                  setShowSearch(false);
                                  router.push("/products");
                                }}
                                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-ivory-100 text-left text-xs"
                              >
                                <span className="font-medium text-espresso-800 truncate">{p.name}</span>
                                <span className="text-rosegold-600 font-semibold ml-2 shrink-0">
                                  {formatCurrency(p.sellingPrice)}
                                </span>
                              </button>
                            ))}
                          </div>
                        )}
                        {searchResults.invoices.length > 0 && (
                          <div>
                            <p className="text-[10px] font-bold uppercase tracking-wider text-espresso-400 mb-1">Invoices</p>
                            {searchResults.invoices.map((inv) => (
                              <button
                                key={inv.id}
                                onClick={() => {
                                  setShowSearch(false);
                                  router.push("/invoices");
                                }}
                                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-ivory-100 text-left text-xs"
                              >
                                <span className="font-medium text-espresso-800">
                                  {inv.invoiceNumber} — {inv.customerName}
                                </span>
                                <span className="font-semibold text-espresso-700">{formatCurrency(inv.grandTotal)}</span>
                              </button>
                            ))}
                          </div>
                        )}
                        {searchResults.customers.length > 0 && (
                          <div>
                            <p className="text-[10px] font-bold uppercase tracking-wider text-espresso-400 mb-1">Customers</p>
                            {searchResults.customers.map((c) => (
                              <button
                                key={c.id}
                                onClick={() => {
                                  setShowSearch(false);
                                  router.push("/customers");
                                }}
                                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-ivory-100 text-left text-xs"
                              >
                                <span className="font-medium text-espresso-800">{c.name}</span>
                                <span className="text-espresso-400">{c.phone}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Notifications Bell */}
              <div className="relative">
                <button
                  onClick={() => {
                    const next = !showNotifs;
                    setShowNotifs(next);
                    if (next) loadNotifications();
                  }}
                  className="relative p-2.5 rounded-xl bg-white border border-ivory-300 text-espresso-600 hover:border-rosegold-300 transition-colors"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4.5 h-4.5 rounded-full bg-rosegold-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}
                </button>

                {showNotifs && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl border border-ivory-300 shadow-elevated z-50 overflow-hidden">
                    <div className="px-4 py-3 border-b border-ivory-200 flex items-center justify-between bg-ivory-50">
                      <span className="text-xs font-bold uppercase tracking-wider text-espresso-700">
                        Alerts & Notifications
                      </span>
                      {unreadCount > 0 && (
                        <button
                          onClick={markAllRead}
                          className="text-xs text-rosegold-600 hover:underline inline-flex items-center gap-1"
                        >
                          <CheckCheck className="w-3.5 h-3.5" /> Mark all read
                        </button>
                      )}
                    </div>
                    <div className="max-h-80 overflow-y-auto divide-y divide-ivory-100">
                      {notifications.length === 0 ? (
                        <p className="text-xs text-espresso-400 text-center py-6">No notifications</p>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            className={`px-4 py-3 text-xs ${n.isRead ? "bg-white" : "bg-blush-50/70"}`}
                          >
                            <p className="font-semibold text-espresso-900">{n.title}</p>
                            <p className="text-espresso-500 mt-0.5">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {actions}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-7 max-w-[1600px] w-full mx-auto">{children}</main>
      </div>
    </div>
  );
}
