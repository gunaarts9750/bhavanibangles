"use client";

import React, { useEffect, useRef, useState } from "react";
import JsBarcode from "jsbarcode";
import { Printer, X } from "lucide-react";
import { formatCurrency } from "@/lib/format";

function BarcodeSvg({ value }: { value: string }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    if (ref.current) {
      try {
        JsBarcode(ref.current, value, {
          format: "CODE128",
          width: 1.5,
          height: 36,
          displayValue: true,
          fontSize: 10,
          margin: 2,
        });
      } catch {
        // fallback if non-standard barcode chars
      }
    }
  }, [value]);
  return <svg ref={ref} className="mx-auto max-w-full" />;
}

export function BarcodeModal({
  product,
  onClose,
}: {
  product: { name: string; code: string; barcode: string; sellingPrice: number; mrp: number; size?: string | null };
  onClose: () => void;
}) {
  const [copies, setCopies] = useState(6);

  return (
    <div className="fixed inset-0 z-50 bg-espresso-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-elevated max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        <div className="px-5 py-3.5 border-b border-ivory-200 bg-ivory-50 flex items-center justify-between no-print">
          <div>
            <h3 className="font-serif text-lg font-bold text-espresso-900">Print Barcode Labels</h3>
            <p className="text-xs text-espresso-500">{product.name} ({product.code})</p>
          </div>
          <div className="flex items-center gap-3">
            <label className="text-xs text-espresso-600 flex items-center gap-2">
              Copies:
              <input
                type="number"
                min={1}
                max={48}
                value={copies}
                onChange={(e) => setCopies(Math.max(1, Math.min(48, Number(e.target.value))))}
                className="w-16 bb-input py-1 px-2 text-center"
              />
            </label>
            <button onClick={() => window.print()} className="bb-btn-primary py-1.5 px-3 text-xs">
              <Printer className="w-3.5 h-3.5" /> Print Sheet
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-ivory-200">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-ivory-100/50">
          <div id="printable-area" className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-white p-4 rounded-xl">
            {Array.from({ length: copies }).map((_, idx) => (
              <div
                key={idx}
                className="border border-dashed border-ivory-400 rounded-lg p-2.5 text-center bg-white"
              >
                <p className="text-[10px] font-bold tracking-widest text-rosegold-700 uppercase">
                  BHAVANI BANGLES
                </p>
                <p className="text-[11px] font-semibold text-espresso-900 truncate mt-0.5">{product.name}</p>
                <BarcodeSvg value={product.barcode} />
                <div className="flex items-center justify-between text-[10px] font-semibold text-espresso-700 mt-1 px-1">
                  <span>{product.size ? `Size: ${product.size}` : product.code}</span>
                  <span>MRP: {formatCurrency(product.mrp || product.sellingPrice)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
