"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { useRouter, usePathname } from "next/navigation";

export interface AuthUser {
  id: string;
  username: string;
  fullName: string;
  email: string | null;
  roleId: string;
  roleName: string;
  roleDisplayName: string;
  permissions: Record<
    string,
    { canView: boolean; canCreate: boolean; canEdit: boolean; canDelete: boolean }
  >;
}

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  can: (module: string, action?: "canView" | "canCreate" | "canEdit" | "canDelete") => boolean;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  loading: true,
  refreshUser: async () => {},
  logout: async () => {},
  can: () => false,
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  const pathnameRef = React.useRef(pathname);
  pathnameRef.current = pathname;

  const refreshUser = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        setUser(null);
        if (pathnameRef.current !== "/login") {
          router.replace("/login");
        }
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.replace("/login");
  };

  const can = (module: string, action: "canView" | "canCreate" | "canEdit" | "canDelete" = "canView") => {
    if (!user) return false;
    if (user.roleName === "SUPER_ADMIN") return true;
    return Boolean(user.permissions?.[module]?.[action]);
  };

  return (
    <AuthContext.Provider value={{ user, loading, refreshUser, logout, can }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
