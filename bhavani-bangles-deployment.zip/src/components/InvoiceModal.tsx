"use client";

import React, { useState, useEffect } from "react";
import { X, Printer, Download, MessageCircle } from "lucide-react";
import { formatCurrency, formatDateTime, buildWhatsAppInvoiceUrl } from "@/lib/format";
import { downloadInvoicePDF, PrintableInvoiceData, ShopSettingData } from "@/lib/export";
import {
  PrinterConfig,
  DEFAULT_PRINTER_CONFIG,
  getSavedPrinterConfig,
  applyPresetToConfig,
  triggerConfiguredPrint,
} from "@/lib/printer";

export function InvoiceModal({
  invoice,
  onClose,
  autoPrint = false,
}: {
  invoice: PrintableInvoiceData;
  onClose: () => void;
  autoPrint?: boolean;
}) {
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(DEFAULT_PRINTER_CONFIG);
  const [format, setFormat] = useState<"A4" | "THERMAL_80" | "THERMAL_58">("THERMAL_58");
  const [printedOnce, setPrintedOnce] = useState(false);
  const [shop, setShop] = useState<ShopSettingData>({
    shopName: "BHAVANI BANGLES",
    shopTagline: "Exquisite Bangles & Bridal Jewellery",
    address: "142, Sarafa Bazaar, Heritage Jewellery Lane, Jaipur, Rajasthan - 302003",
    phone: "+91 98290 45678",
    gstin: "08AABCB1234F1Z5",
    invoiceTerms: "Goods once sold will be exchanged within 7 days with original bill.",
    thankYouMessage: "Thank you for shopping at BHAVANI BANGLES!",
  });

  useEffect(() => {
    const saved = getSavedPrinterConfig();
    setPrinterConfig(saved);
    if (saved.preset === "A4" || saved.preset === "A5") {
      setFormat("A4");
    } else if (saved.preset === "THERMAL_80" || saved.preset === "THERMAL_76") {
      setFormat("THERMAL_80");
    } else {
      setFormat("THERMAL_58");
    }

    fetch("/api/settings")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.settings) {
          setShop(d.settings);
        }
      })
      .catch(() => {});
  }, []);

  const handlePrint = () => {
    const cfg =
      format === "A4"
        ? applyPresetToConfig(printerConfig, "A4")
        : format === "THERMAL_80"
        ? applyPresetToConfig(printerConfig, "THERMAL_80")
        : printerConfig.preset === "CUSTOM" && printerConfig.paperWidthMm <= 65
        ? printerConfig
        : applyPresetToConfig(printerConfig, "THERMAL_58");
    triggerConfiguredPrint(cfg);
  };

  useEffect(() => {
    if (autoPrint && !printedOnce) {
      setPrintedOnce(true);
      const t = setTimeout(() => {
        handlePrint();
      }, 250);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoPrint, printedOnce]);

  const waUrl = buildWhatsAppInvoiceUrl({
    phone: invoice.customerPhone,
    shopName: shop.shopName,
    invoiceNumber: invoice.invoiceNumber,
    customerName: invoice.customerName,
    grandTotal: invoice.grandTotal,
    paidAmount: invoice.paidAmount,
    balanceDue: invoice.balanceDue,
    items: invoice.items,
    thankYouMessage: shop.thankYouMessage || undefined,
  });

  return (
    <div className="fixed inset-0 z-50 bg-espresso-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-elevated max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Action Bar */}
        <div className="px-5 py-3.5 border-b border-ivory-200 bg-ivory-50 flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-2">
            {(["A4", "THERMAL_80", "THERMAL_58"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFormat(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  format === f
                    ? "bg-rosegold-500 text-white"
                    : "bg-white border border-ivory-300 text-espresso-700 hover:bg-ivory-100"
                }`}
              >
                {f === "A4" ? "A4 Tax Invoice" : f === "THERMAL_80" ? "80mm Thermal" : "58mm Thermal"}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="bb-btn-primary py-1.5 px-3 text-xs">
              <Printer className="w-3.5 h-3.5" /> Print
            </button>
            <button
              onClick={() => downloadInvoicePDF(invoice, shop, format)}
              className="bb-btn-gold py-1.5 px-3 text-xs"
            >
              <Download className="w-3.5 h-3.5" /> PDF
            </button>
            <a
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
            >
              <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
            </a>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-ivory-200 text-espresso-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-ivory-100/60 flex justify-center">
          <div
            id="printable-area"
            className={`bg-white border border-ivory-300 shadow-soft text-espresso-900 ${
              format === "A4"
                ? "w-full max-w-[760px] p-8 rounded-xl"
                : format === "THERMAL_80"
                ? "w-[320px] p-4 font-mono text-xs"
                : "w-[240px] p-3 font-mono text-[11px]"
            }`}
          >
            {format === "A4" ? (
              <div className="space-y-6">
                <div className="flex items-start justify-between border-b-2 border-rosegold-300 pb-5">
                  <div>
                    <h1 className="font-serif text-3xl font-bold tracking-wide text-espresso-900">
                      {shop.shopName}
                    </h1>
                    {shop.shopTagline && (
                      <p className="text-xs text-rosegold-600 font-medium tracking-widest uppercase mt-0.5">
                        {shop.shopTagline}
                      </p>
                    )}
                    <p className="text-xs text-espresso-500 mt-2 max-w-sm">{shop.address}</p>
                    <p className="text-xs text-espresso-600 mt-1">
                      Phone: {shop.phone} {shop.gstin && <>• GSTIN: <span className="font-semibold">{shop.gstin}</span></>}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-3 py-1 rounded-full bg-blush-200 text-rosegold-700 text-xs font-bold tracking-wider uppercase">
                      TAX INVOICE
                    </span>
                    <p className="text-base font-bold text-espresso-900 mt-2">{invoice.invoiceNumber}</p>
                    <p className="text-xs text-espresso-500">{formatDateTime(invoice.saleDate)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 bg-ivory-50 rounded-xl p-4 border border-ivory-200 text-xs">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wider text-espresso-400">Billed To</p>
                    <p className="font-semibold text-sm text-espresso-900 mt-0.5">{invoice.customerName}</p>
                    {invoice.customerPhone && <p className="text-espresso-600">Mobile: {invoice.customerPhone}</p>}
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-espresso-400">Payment Info</p>
                    <p className="font-semibold text-sm text-espresso-900 mt-0.5">{invoice.paymentMethod}</p>
                    <p className="text-espresso-600">Status: <span className="font-semibold">{invoice.paymentStatus}</span></p>
                  </div>
                </div>

                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-blush-100 text-espresso-800 border-y border-rosegold-200">
                      <th className="py-2.5 px-2 text-left">#</th>
                      <th className="py-2.5 px-2 text-left">Product Description</th>
                      <th className="py-2.5 px-2 text-center">HSN</th>
                      <th className="py-2.5 px-2 text-center">Qty</th>
                      <th className="py-2.5 px-2 text-right">Rate</th>
                      <th className="py-2.5 px-2 text-right">Disc</th>
                      <th className="py-2.5 px-2 text-right">GST</th>
                      <th className="py-2.5 px-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ivory-200">
                    {invoice.items.map((it, idx) => (
                      <tr key={idx}>
                        <td className="py-2.5 px-2 text-espresso-500">{idx + 1}</td>
                        <td className="py-2.5 px-2">
                          <p className="font-medium text-espresso-900">{it.productName}</p>
                          <p className="text-[10px] text-espresso-400">{it.productCode}</p>
                        </td>
                        <td className="py-2.5 px-2 text-center text-espresso-500">{it.hsnCode || "7117"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums">{it.quantity} {it.unit}</td>
                        <td className="py-2.5 px-2 text-right tabular-nums">{formatCurrency(it.unitPrice)}</td>
                        <td className="py-2.5 px-2 text-right tabular-nums">{formatCurrency(it.discount)}</td>
                        <td className="py-2.5 px-2 text-right tabular-nums">{it.gstPercent}%</td>
                        <td className="py-2.5 px-2 text-right font-semibold tabular-nums">{formatCurrency(it.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="grid grid-cols-2 gap-6 pt-3 border-t border-ivory-200">
                  <div className="text-[11px] text-espresso-500 whitespace-pre-line">
                    <p className="font-semibold text-espresso-700 mb-1">Terms & Conditions</p>
                    {shop.invoiceTerms}
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-espresso-500">Subtotal</span>
                      <span className="tabular-nums font-medium">{formatCurrency(invoice.subtotal)}</span>
                    </div>
                    {invoice.itemDiscount + invoice.billDiscount > 0 && (
                      <div className="flex justify-between text-emerald-700">
                        <span>Total Discount</span>
                        <span className="tabular-nums">-{formatCurrency(invoice.itemDiscount + invoice.billDiscount)}</span>
                      </div>
                    )}
                    {invoice.gstType === "IGST" ? (
                      <div className="flex justify-between">
                        <span className="text-espresso-500">IGST</span>
                        <span className="tabular-nums">{formatCurrency(invoice.igstAmount)}</span>
                      </div>
                    ) : invoice.totalGst > 0 ? (
                      <>
                        <div className="flex justify-between">
                          <span className="text-espresso-500">CGST</span>
                          <span className="tabular-nums">{formatCurrency(invoice.cgstAmount)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-espresso-500">SGST</span>
                          <span className="tabular-nums">{formatCurrency(invoice.sgstAmount)}</span>
                        </div>
                      </>
                    ) : null}
                    {invoice.roundOff !== 0 && (
                      <div className="flex justify-between">
                        <span className="text-espresso-500">Round Off</span>
                        <span className="tabular-nums">{formatCurrency(invoice.roundOff)}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-2 border-t border-rosegold-200 text-base font-bold text-rosegold-700">
                      <span>Grand Total</span>
                      <span className="tabular-nums">{formatCurrency(invoice.grandTotal)}</span>
                    </div>
                    <div className="flex justify-between text-espresso-700">
                      <span>Amount Paid</span>
                      <span className="tabular-nums font-semibold">{formatCurrency(invoice.paidAmount)}</span>
                    </div>
                    {invoice.balanceDue > 0 && (
                      <div className="flex justify-between text-rose-600 font-semibold">
                        <span>Balance Due</span>
                        <span className="tabular-nums">{formatCurrency(invoice.balanceDue)}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="text-center pt-4 border-t border-dashed border-ivory-300">
                  <p className="font-serif text-base text-rosegold-700 font-semibold">
                    {shop.thankYouMessage}
                  </p>
                </div>
              </div>
            ) : (
              /* 80mm / 58mm Thermal Receipt */
              <div className="space-y-2 leading-tight">
                <div className="text-center border-b border-dashed border-espresso-400 pb-2">
                  <p className="font-bold text-sm">{shop.shopName}</p>
                  <p className="text-[10px]">{shop.address}</p>
                  <p className="text-[10px]">Ph: {shop.phone}</p>
                  {shop.gstin && <p className="text-[10px]">GSTIN: {shop.gstin}</p>}
                </div>
                <div className="border-b border-dashed border-espresso-400 pb-1.5 text-[10px]">
                  <div className="flex justify-between">
                    <span>Inv: {invoice.invoiceNumber}</span>
                    <span>{new Date(invoice.saleDate).toLocaleDateString("en-IN")}</span>
                  </div>
                  <div>Cust: {invoice.customerName}</div>
                </div>
                <div className="border-b border-dashed border-espresso-400 pb-1.5 space-y-1.5">
                  {invoice.items.map((it, idx) => (
                    <div key={idx}>
                      <div className="font-semibold truncate">{it.productName}</div>
                      <div className="flex justify-between text-[10px]">
                        <span>{it.quantity} x {it.unitPrice.toFixed(0)} (GST {it.gstPercent}%)</span>
                        <span className="font-semibold">{formatCurrency(it.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="space-y-1 text-[11px]">
                  <div className="flex justify-between"><span>Subtotal</span><span>{formatCurrency(invoice.subtotal)}</span></div>
                  {invoice.totalGst > 0 && (
                    <div className="flex justify-between"><span>GST</span><span>{formatCurrency(invoice.totalGst)}</span></div>
                  )}
                  <div className="flex justify-between font-bold text-xs border-t border-dashed border-espresso-400 pt-1">
                    <span>GRAND TOTAL</span><span>{formatCurrency(invoice.grandTotal)}</span>
                  </div>
                  <div className="flex justify-between"><span>Paid ({invoice.paymentMethod})</span><span>{formatCurrency(invoice.paidAmount)}</span></div>
                  {invoice.balanceDue > 0 && (
                    <div className="flex justify-between font-bold"><span>Balance Due</span><span>{formatCurrency(invoice.balanceDue)}</span></div>
                  )}
                </div>
                <p className="text-center text-[10px] pt-2 border-t border-dashed border-espresso-400">
                  {shop.thankYouMessage}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
