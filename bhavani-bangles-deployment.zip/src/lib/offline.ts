"use client";

import { PrintableInvoiceData } from "./export";

const CACHE_KEY = "bb_pos_cache_v1";
const QUEUE_KEY = "bb_offline_bills_v1";

export interface OfflineQueuedBill {
  offlineId: string;
  createdAt: string;
  payload: Record<string, unknown>;
  previewInvoice: PrintableInvoiceData;
}

export function savePosCache(data: { products: unknown[]; categories: unknown[]; customers: unknown[] }) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ ...data, cachedAt: new Date().toISOString() }));
  } catch {
    // ignore storage quota errors
  }
}

export function loadPosCache<T extends { products: unknown[]; categories: unknown[]; customers: unknown[] }>(): T | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function getOfflineQueue(): OfflineQueuedBill[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    return raw ? (JSON.parse(raw) as OfflineQueuedBill[]) : [];
  } catch {
    return [];
  }
}

export function saveOfflineQueue(queue: OfflineQueuedBill[]) {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch {
    // ignore
  }
}

export function enqueueOfflineBill(bill: OfflineQueuedBill): OfflineQueuedBill[] {
  const queue = getOfflineQueue();
  const next = [bill, ...queue];
  saveOfflineQueue(next);
  return next;
}

export function generateOfflineInvoiceNumber(): string {
  const now = new Date();
  const d = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const rand = String(Math.floor(100 + Math.random() * 900));
  return `OFF-${d}-${rand}`;
}

export async function syncOfflineQueue(): Promise<{ synced: number; failed: number; remaining: OfflineQueuedBill[] }> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return { synced: 0, failed: 0, remaining: [] };

  let synced = 0;
  let failed = 0;
  const remaining: OfflineQueuedBill[] = [];

  // Process oldest first to keep chronological invoice order
  for (const item of [...queue].reverse()) {
    try {
      const res = await fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...item.payload,
          notes: `${item.payload.notes ? item.payload.notes + " | " : ""}Synced from Offline Bill ${item.previewInvoice.invoiceNumber}`,
        }),
      });
      if (res.ok) {
        synced++;
      } else {
        failed++;
        remaining.push(item);
      }
    } catch {
      failed++;
      remaining.push(item);
    }
  }

  const orderedRemaining = remaining.reverse();
  saveOfflineQueue(orderedRemaining);
  return { synced, failed, remaining: orderedRemaining };
}
