import bcrypt from "bcryptjs";
import { prisma } from "./prisma";

const ALL_MODULES = [
  "dashboard",
  "pos",
  "products",
  "inventory",
  "purchases",
  "customers",
  "invoices",
  "quotations",
  "returns",
  "expenses",
  "staff",
  "reports",
  "settings",
];

const DEFAULT_CATEGORIES = [
  { name: "Glass Bangles", slug: "glass-bangles", sortOrder: 1 },
  { name: "Metal Bangles", slug: "metal-bangles", sortOrder: 2 },
  { name: "Bridal Bangles", slug: "bridal-bangles", sortOrder: 3 },
  { name: "Designer Bangles", slug: "designer-bangles", sortOrder: 4 },
  { name: "Stone Bangles", slug: "stone-bangles", sortOrder: 5 },
  { name: "Antique Bangles", slug: "antique-bangles", sortOrder: 6 },
  { name: "Fancy Bangles", slug: "fancy-bangles", sortOrder: 7 },
  { name: "Kids Bangles", slug: "kids-bangles", sortOrder: 8 },
  { name: "Bracelet Collections", slug: "bracelet-collections", sortOrder: 9 },
  { name: "Artificial Jewellery", slug: "artificial-jewellery", sortOrder: 10 },
  { name: "Earrings", slug: "earrings", sortOrder: 11 },
  { name: "Necklaces", slug: "necklaces", sortOrder: 12 },
  { name: "Other Accessories", slug: "other-accessories", sortOrder: 13 },
];

export async function ensureDefaultAdminSeeded() {
  await prisma.setting.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      shopName: "BHAVANI BANGLES",
      shopTagline: "Exquisite Bangles & Bridal Jewellery",
      defaultPrintFormat: "THERMAL_58",
    },
  });

  const roleDefs = [
    { name: "SUPER_ADMIN", displayName: "Super Admin / Owner", description: "Full unrestricted access to all modules, reports, staff and settings." },
    { name: "SHOP_MANAGER", displayName: "Shop Manager", description: "Manages daily operations, billing, inventory, purchases, staff and reports." },
    { name: "BILLING_STAFF", displayName: "Billing Staff", description: "POS billing, invoice printing, quotations, customers and sales returns." },
    { name: "INVENTORY_STAFF", displayName: "Inventory Staff", description: "Product catalog, barcode labels, stock management and purchases." },
  ];

  const roles: Record<string, string> = {};
  for (const r of roleDefs) {
    const role = await prisma.role.upsert({
      where: { name: r.name },
      update: { displayName: r.displayName, description: r.description },
      create: r,
    });
    roles[r.name] = role.id;
  }

  const matrix: Record<string, Record<string, [boolean, boolean, boolean, boolean]>> = {
    SUPER_ADMIN: Object.fromEntries(ALL_MODULES.map((m) => [m, [true, true, true, true]])),
    SHOP_MANAGER: {
      dashboard: [true, false, false, false],
      pos: [true, true, true, false],
      products: [true, true, true, true],
      inventory: [true, true, true, false],
      purchases: [true, true, true, false],
      customers: [true, true, true, false],
      invoices: [true, true, true, false],
      quotations: [true, true, true, true],
      returns: [true, true, true, false],
      expenses: [true, true, true, false],
      staff: [true, true, true, false],
      reports: [true, false, false, false],
      settings: [true, false, false, false],
    },
    BILLING_STAFF: {
      dashboard: [true, false, false, false],
      pos: [true, true, false, false],
      products: [true, false, false, false],
      inventory: [false, false, false, false],
      purchases: [false, false, false, false],
      customers: [true, true, true, false],
      invoices: [true, true, false, false],
      quotations: [true, true, true, false],
      returns: [true, true, false, false],
      expenses: [false, false, false, false],
      staff: [false, false, false, false],
      reports: [false, false, false, false],
      settings: [false, false, false, false],
    },
    INVENTORY_STAFF: {
      dashboard: [true, false, false, false],
      pos: [false, false, false, false],
      products: [true, true, true, false],
      inventory: [true, true, true, false],
      purchases: [true, true, true, false],
      customers: [false, false, false, false],
      invoices: [false, false, false, false],
      quotations: [false, false, false, false],
      returns: [false, false, false, false],
      expenses: [false, false, false, false],
      staff: [false, false, false, false],
      reports: [true, false, false, false],
      settings: [false, false, false, false],
    },
  };

  for (const [roleName, perms] of Object.entries(matrix)) {
    const roleId = roles[roleName];
    for (const [mod, [canView, canCreate, canEdit, canDelete]] of Object.entries(perms)) {
      await prisma.permission.upsert({
        where: { roleId_module: { roleId, module: mod } },
        update: { canView, canCreate, canEdit, canDelete },
        create: { roleId, module: mod, canView, canCreate, canEdit, canDelete },
      });
    }
  }

  for (const cat of DEFAULT_CATEGORIES) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: {},
      create: cat,
    });
  }

  const adminPassword = process.env.INITIAL_ADMIN_PASSWORD || "bhavani@2026";
  const adminHash = await bcrypt.hash(adminPassword, 10);
  await prisma.user.upsert({
    where: { username: "admin" },
    update: { isActive: true },
    create: {
      username: "admin",
      email: "admin@bhavanibangles.in",
      fullName: "BHAVANI BANGLES Admin",
      passwordHash: adminHash,
      roleId: roles.SUPER_ADMIN,
      isActive: true,
    },
  });

  const ownerHash = await bcrypt.hash("Owner@123", 10);
  await prisma.user.upsert({
    where: { username: "owner" },
    update: { isActive: true },
    create: {
      username: "owner",
      email: "owner@bhavanibangles.in",
      fullName: "BHAVANI BANGLES Owner",
      passwordHash: ownerHash,
      roleId: roles.SUPER_ADMIN,
      isActive: true,
    },
  });
}
