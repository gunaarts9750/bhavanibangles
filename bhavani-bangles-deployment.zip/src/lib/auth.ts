import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { prisma } from "./prisma";
import { NextResponse } from "next/server";

const COOKIE_NAME = "bb_session";
const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "bhavani-bangles-super-secret-jwt-key-change-in-production-2026"
);

export interface SessionUser {
  id: string;
  username: string;
  fullName: string;
  email: string | null;
  roleId: string;
  roleName: string;
  roleDisplayName: string;
  permissions: Record<
    string,
    { canView: boolean; canCreate: boolean; canEdit: boolean; canDelete: boolean }
  >;
}

export async function signSessionToken(payload: { userId: string; sessionId: string }) {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(SECRET);
}

export async function verifySessionToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as { userId: string; sessionId: string };
  } catch {
    return null;
  }
}

export async function setSessionCookie(token: string, isHttps = false) {
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12, // 12 hours automatic session expiry
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(COOKIE_NAME)?.value;
    if (!token) return null;

    const payload = await verifySessionToken(token);
    if (!payload?.userId) return null;

    const session = await prisma.session.findUnique({
      where: { id: payload.sessionId },
    });

    if (!session || !session.isActive || session.expiresAt < new Date()) {
      return null;
    }

    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      include: {
        role: {
          include: {
            permissions: true,
          },
        },
      },
    });

    if (!user || !user.isActive) return null;

    const permissions: SessionUser["permissions"] = {};
    for (const p of user.role.permissions) {
      permissions[p.module] = {
        canView: p.canView,
        canCreate: p.canCreate,
        canEdit: p.canEdit,
        canDelete: p.canDelete,
      };
    }

    return {
      id: user.id,
      username: user.username,
      fullName: user.fullName,
      email: user.email,
      roleId: user.roleId,
      roleName: user.role.name,
      roleDisplayName: user.role.displayName,
      permissions,
    };
  } catch {
    return null;
  }
}

export function hasPermission(
  user: SessionUser | null,
  module: string,
  action: "canView" | "canCreate" | "canEdit" | "canDelete" = "canView"
): boolean {
  if (!user) return false;
  if (user.roleName === "SUPER_ADMIN") return true;
  return Boolean(user.permissions[module]?.[action]);
}

export async function requireAuth(
  module?: string,
  action: "canView" | "canCreate" | "canEdit" | "canDelete" = "canView"
): Promise<{ user: SessionUser; error: null } | { user: null; error: NextResponse }> {
  const user = await getCurrentUser();
  if (!user) {
    return {
      user: null,
      error: NextResponse.json({ error: "Authentication required" }, { status: 401 }),
    };
  }
  if (module && !hasPermission(user, module, action)) {
    return {
      user: null,
      error: NextResponse.json(
        { error: `Access denied: missing ${action} permission on ${module}` },
        { status: 403 }
      ),
    };
  }
  return { user, error: null };
}

export async function createAuditLog(params: {
  userId?: string | null;
  username?: string | null;
  action: string;
  module: string;
  entityId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        username: params.username ?? null,
        action: params.action,
        module: params.module,
        entityId: params.entityId ?? null,
        details: params.details ?? null,
        ipAddress: params.ipAddress ?? null,
      },
    });
  } catch (err) {
    console.error("Audit log failed:", err);
  }
}
