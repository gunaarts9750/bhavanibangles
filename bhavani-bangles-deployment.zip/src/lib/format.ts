export function formatCurrency(amount: number | string | null | undefined, symbol = "₹"): string {
  const num = Number(amount ?? 0);
  if (Number.isNaN(num)) return `${symbol}0.00`;
  return (
    symbol +
    num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

export function formatNumber(val: number | string | null | undefined): string {
  const num = Number(val ?? 0);
  if (Number.isNaN(num)) return "0";
  return num.toLocaleString("en-IN");
}

export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return "-";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return "-";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

export function buildWhatsAppInvoiceUrl(params: {
  phone?: string | null;
  shopName: string;
  invoiceNumber: string;
  customerName: string;
  grandTotal: number;
  paidAmount: number;
  balanceDue: number;
  items: { productName: string; quantity: number; total: number }[];
  thankYouMessage?: string;
}) {
  const cleanPhone = (params.phone || "").replace(/[^0-9]/g, "");
  const phoneWithCode = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;

  const itemLines = params.items
    .map((it, idx) => `${idx + 1}. ${it.productName} x${it.quantity} = ₹${it.total.toFixed(2)}`)
    .join("\n");

  const text = [
    `*${params.shopName}*`,
    `Invoice: *${params.invoiceNumber}*`,
    `Customer: ${params.customerName}`,
    `-------------------`,
    itemLines,
    `-------------------`,
    `*Grand Total: ₹${params.grandTotal.toFixed(2)}*`,
    `Paid: ₹${params.paidAmount.toFixed(2)}`,
    params.balanceDue > 0 ? `Balance Due: ₹${params.balanceDue.toFixed(2)}` : `Status: PAID`,
    ``,
    params.thankYouMessage || `Thank you for shopping at ${params.shopName}!`,
  ].join("\n");

  return `https://wa.me/${phoneWithCode}?text=${encodeURIComponent(text)}`;
}

export function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(" ");
}
