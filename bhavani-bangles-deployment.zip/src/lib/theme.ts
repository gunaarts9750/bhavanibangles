export type ThemeId = "rosegold" | "blue" | "red" | "purple" | "emerald" | "amber";

export interface ThemeOption {
  id: ThemeId;
  name: string;
  swatch: string;
  vars: Record<string, string>;
}

export const THEME_OPTIONS: ThemeOption[] = [
  {
    id: "rosegold",
    name: "Rose Gold",
    swatch: "#B76E79",
    vars: {
      "--accent-50": "253 245 246",
      "--accent-100": "248 230 233",
      "--accent-200": "239 200 206",
      "--accent-300": "223 158 169",
      "--accent-400": "203 125 138",
      "--accent-500": "183 110 121",
      "--accent-600": "158 86 97",
      "--accent-700": "130 66 76",
      "--accent-800": "107 54 63",
      "--accent-900": "88 46 53",
    },
  },
  {
    id: "blue",
    name: "Royal Blue",
    swatch: "#2563EB",
    vars: {
      "--accent-50": "239 246 255",
      "--accent-100": "219 234 254",
      "--accent-200": "191 219 254",
      "--accent-300": "147 197 253",
      "--accent-400": "96 165 250",
      "--accent-500": "37 99 235",
      "--accent-600": "29 78 216",
      "--accent-700": "30 64 175",
      "--accent-800": "30 58 138",
      "--accent-900": "23 37 84",
    },
  },
  {
    id: "red",
    name: "Crimson Red",
    swatch: "#DC2626",
    vars: {
      "--accent-50": "254 242 242",
      "--accent-100": "254 226 226",
      "--accent-200": "254 202 202",
      "--accent-300": "252 165 165",
      "--accent-400": "248 113 113",
      "--accent-500": "220 38 38",
      "--accent-600": "185 28 28",
      "--accent-700": "153 27 27",
      "--accent-800": "127 29 29",
      "--accent-900": "69 10 10",
    },
  },
  {
    id: "purple",
    name: "Royal Purple",
    swatch: "#9333EA",
    vars: {
      "--accent-50": "250 245 255",
      "--accent-100": "243 232 255",
      "--accent-200": "233 213 255",
      "--accent-300": "216 180 254",
      "--accent-400": "192 132 252",
      "--accent-500": "147 51 234",
      "--accent-600": "126 34 206",
      "--accent-700": "107 33 168",
      "--accent-800": "88 28 135",
      "--accent-900": "59 7 100",
    },
  },
  {
    id: "emerald",
    name: "Emerald Green",
    swatch: "#059669",
    vars: {
      "--accent-50": "236 253 245",
      "--accent-100": "209 250 229",
      "--accent-200": "167 243 208",
      "--accent-300": "110 231 183",
      "--accent-400": "52 211 153",
      "--accent-500": "5 150 105",
      "--accent-600": "4 120 87",
      "--accent-700": "6 95 70",
      "--accent-800": "6 78 59",
      "--accent-900": "2 44 34",
    },
  },
  {
    id: "amber",
    name: "Golden Amber",
    swatch: "#D97706",
    vars: {
      "--accent-50": "255 251 235",
      "--accent-100": "254 243 199",
      "--accent-200": "253 230 138",
      "--accent-300": "252 211 77",
      "--accent-400": "251 191 36",
      "--accent-500": "217 119 6",
      "--accent-600": "180 83 9",
      "--accent-700": "146 64 14",
      "--accent-800": "120 53 15",
      "--accent-900": "69 26 3",
    },
  },
];

const STORAGE_KEY = "bb_pos_theme";

export function getSavedTheme(): ThemeId {
  if (typeof window === "undefined") return "rosegold";
  const saved = localStorage.getItem(STORAGE_KEY) as ThemeId | null;
  if (saved && THEME_OPTIONS.some((t) => t.id === saved)) {
    return saved;
  }
  return "rosegold";
}

export function applyTheme(themeId: ThemeId): void {
  if (typeof window === "undefined") return;
  const option = THEME_OPTIONS.find((t) => t.id === themeId) || THEME_OPTIONS[0];
  const root = document.documentElement;
  root.setAttribute("data-theme", option.id);
  for (const [key, value] of Object.entries(option.vars)) {
    root.style.setProperty(key, value);
  }
  localStorage.setItem(STORAGE_KEY, option.id);
}
