export type PrinterPresetId =
  | "THERMAL_58"
  | "THERMAL_76"
  | "THERMAL_80"
  | "A5"
  | "A4"
  | "CUSTOM";

export interface PrinterConfig {
  preset: PrinterPresetId;
  paperWidthMm: number;   // Physical roll/sheet width in mm (e.g. 58, 76, 80, 148, 210)
  marginMm: number;       // Page margin in mm (e.g. 2 for 58mm, 3 for 80mm, 8 for A4)
  fontSizePx: number;     // Base font size in px (e.g. 10 for 58mm, 12 for 80mm)
  extraFeedLines: number; // Extra blank lines at bottom for thermal tear/cut bar
  autoPrint: boolean;     // Auto-trigger print after POS checkout
  showAddress: boolean;
  showGstin: boolean;
  showItemGst: boolean;
  showThankYou: boolean;
  printerLabel: string;   // Friendly name / connected printer label
}

export interface PrinterPresetMeta {
  id: PrinterPresetId;
  name: string;
  subtitle: string;
  defaults: Pick<PrinterConfig, "paperWidthMm" | "marginMm" | "fontSizePx" | "extraFeedLines">;
}

export const PRINTER_PRESETS: PrinterPresetMeta[] = [
  {
    id: "THERMAL_58",
    name: "58mm Small Thermal (2\")",
    subtitle: "Compact Bluetooth / USB mini thermal receipt printer",
    defaults: { paperWidthMm: 58, marginMm: 2, fontSizePx: 10, extraFeedLines: 3 },
  },
  {
    id: "THERMAL_76",
    name: "76mm Thermal / Dot Matrix",
    subtitle: "Medium 3-inch impact / thermal receipt roll",
    defaults: { paperWidthMm: 76, marginMm: 3, fontSizePx: 11, extraFeedLines: 3 },
  },
  {
    id: "THERMAL_80",
    name: "80mm Thermal POS (3\")",
    subtitle: "Standard retail POS thermal receipt printer",
    defaults: { paperWidthMm: 80, marginMm: 3, fontSizePx: 12, extraFeedLines: 2 },
  },
  {
    id: "A5",
    name: "A5 Half-Page Invoice",
    subtitle: "Half A4 sheet (148 × 210 mm)",
    defaults: { paperWidthMm: 148, marginMm: 6, fontSizePx: 12, extraFeedLines: 0 },
  },
  {
    id: "A4",
    name: "A4 Tax Invoice",
    subtitle: "Standard laser / inkjet full-page printer",
    defaults: { paperWidthMm: 210, marginMm: 8, fontSizePx: 13, extraFeedLines: 0 },
  },
  {
    id: "CUSTOM",
    name: "Custom Printer Size",
    subtitle: "Set your own roll width, margin & font size",
    defaults: { paperWidthMm: 58, marginMm: 2, fontSizePx: 10, extraFeedLines: 2 },
  },
];

const STORAGE_KEY = "bb_printer_config_v1";

export const DEFAULT_PRINTER_CONFIG: PrinterConfig = {
  preset: "THERMAL_58",
  paperWidthMm: 58,
  marginMm: 2,
  fontSizePx: 10,
  extraFeedLines: 3,
  autoPrint: true,
  showAddress: true,
  showGstin: true,
  showItemGst: true,
  showThankYou: true,
  printerLabel: "",
};

export function isThermalPreset(preset: PrinterPresetId, paperWidthMm?: number): boolean {
  if (preset === "THERMAL_58" || preset === "THERMAL_76" || preset === "THERMAL_80") {
    return true;
  }
  if (preset === "CUSTOM") {
    return (paperWidthMm ?? 80) <= 100;
  }
  return false;
}

export function getSavedPrinterConfig(fallbackFormat?: string): PrinterConfig {
  if (typeof window === "undefined") {
    return DEFAULT_PRINTER_CONFIG;
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PrinterConfig>;
      return {
        ...DEFAULT_PRINTER_CONFIG,
        ...parsed,
        paperWidthMm: Math.min(220, Math.max(40, Number(parsed.paperWidthMm) || DEFAULT_PRINTER_CONFIG.paperWidthMm)),
        marginMm: Math.min(20, Math.max(0, Number(parsed.marginMm ?? DEFAULT_PRINTER_CONFIG.marginMm))),
        fontSizePx: Math.min(18, Math.max(8, Number(parsed.fontSizePx) || DEFAULT_PRINTER_CONFIG.fontSizePx)),
        extraFeedLines: Math.min(8, Math.max(0, Number(parsed.extraFeedLines ?? DEFAULT_PRINTER_CONFIG.extraFeedLines))),
      };
    }
  } catch {
    // ignore storage errors
  }

  if (fallbackFormat) {
    const match = PRINTER_PRESETS.find((p) => p.id === fallbackFormat);
    if (match) {
      return {
        ...DEFAULT_PRINTER_CONFIG,
        preset: match.id,
        ...match.defaults,
      };
    }
  }
  return DEFAULT_PRINTER_CONFIG;
}

export function savePrinterConfig(config: PrinterConfig): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // ignore storage errors
  }
}

export function applyPresetToConfig(current: PrinterConfig, preset: PrinterPresetId): PrinterConfig {
  const meta = PRINTER_PRESETS.find((p) => p.id === preset);
  if (!meta) return { ...current, preset };
  if (preset === "CUSTOM") {
    return { ...current, preset };
  }
  return {
    ...current,
    preset,
    ...meta.defaults,
  };
}

/**
 * Injects dynamic @page CSS rules matching the selected printer paper size & margins
 * so thermal (58mm/76mm/80mm/custom) and sheet (A5/A4) printers print without clipping.
 */
export function injectDynamicPrintStyle(config: PrinterConfig): void {
  if (typeof document === "undefined") return;
  const styleId = "bb-dynamic-print-style";
  let el = document.getElementById(styleId) as HTMLStyleElement | null;
  if (!el) {
    el = document.createElement("style");
    el.id = styleId;
    document.head.appendChild(el);
  }

  const thermal = isThermalPreset(config.preset, config.paperWidthMm);
  const printableWidthMm = Math.max(36, config.paperWidthMm - config.marginMm * 2);

  const pageSizeRule =
    config.preset === "A4"
      ? "A4 portrait"
      : config.preset === "A5"
      ? "A5 portrait"
      : `${config.paperWidthMm}mm auto`;

  el.textContent = `
    @media print {
      @page {
        size: ${pageSizeRule};
        margin: ${config.marginMm}mm;
      }
      html, body {
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
      }
      #printable-area {
        width: ${thermal ? `${printableWidthMm}mm` : "100%"} !important;
        max-width: ${thermal ? `${printableWidthMm}mm` : "100%"} !important;
        font-size: ${config.fontSizePx}px !important;
        padding: 0 !important;
        margin: 0 !important;
        color: #000 !important;
        background: #fff !important;
      }
    }
  `;
}

export function triggerConfiguredPrint(config: PrinterConfig): void {
  injectDynamicPrintStyle(config);
  window.print();
}
