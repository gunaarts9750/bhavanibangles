"use client";

import React, { createContext, useContext, useEffect, useState } from "react";

export type LangCode = "en" | "ta" | "hi";

export const LANGUAGE_OPTIONS: { code: LangCode; label: string; short: string; native: string }[] = [
  { code: "en", label: "English", short: "EN", native: "English" },
  { code: "ta", label: "Tamil", short: "த", native: "தமிழ்" },
  { code: "hi", label: "Hindi", short: "हि", native: "हिन्दी" },
];

const TRANSLATIONS: Record<LangCode, Record<string, string>> = {
  en: {
    "nav.pos": "Billing POS",
    "nav.reports": "Reports",
    "nav.settings": "Settings",
    "nav.signOut": "Sign Out",
    "pos.title": "Billing POS",
    "pos.subtitle": "Enter Code/Barcode, Qty & Amount and press Enter to print bill directly",
    "pos.quickEntry": "Quick Direct Bill Entry",
    "pos.quickHint": "Enter barcode/code, qty & price — press Enter to bill & print directly",
    "pos.code": "Code / Barcode",
    "pos.codePlaceholder": "e.g. 1, 2 or scan barcode",
    "pos.qty": "Qty",
    "pos.price": "Price / Amount (₹) *",
    "pos.pricePlaceholder": "e.g. 250",
    "pos.add": "Add",
    "pos.billEnter": "Bill (Enter)",
    "pos.billing": "Billing...",
    "pos.billDiscount": "Bill Discount ₹",
    "pos.taxMode": "Tax Mode",
    "pos.noGst": "No Extra GST",
    "pos.roundOff": "Round Off",
    "pos.paymentMode": "Payment Mode",
    "pos.cash": "Cash",
    "pos.upi": "UPI",
    "pos.card": "Card",
    "pos.bank": "Bank",
    "pos.split": "Split",
    "pos.due": "Due",
    "pos.subtotal": "Subtotal",
    "pos.totalDiscount": "Total Discount",
    "pos.grandTotal": "Grand Total",
    "pos.confirmPrint": "Confirm & Print Bill",
    "pos.autoPrintOn": "Auto-Print ON",
    "pos.autoPrintOff": "Auto-Print OFF",
    "pos.onlineMode": "Online Mode",
    "pos.offlineMode": "Offline Mode",
    "reports.title": "Reports & Business Analytics",
    "reports.subtitle": "Filter & export live financial, GST, stock, customer & staff reports in PDF or Excel",
    "reports.resetBills": "Reset Bills (01)",
    "reports.resetting": "Resetting...",
    "reports.exportExcel": "Export Excel",
    "reports.exportPdf": "Export PDF",
    "reports.dateRange": "Date Range:",
    "reports.to": "to",
    "reports.applyFilter": "Apply Filter",
    "reports.clear": "Clear",
    "reports.loading": "Generating report...",
    "reports.empty": "No records found for this report",
    "settings.title": "Settings",
    "settings.subtitle": "Switch language, color theme and customize the shop details printed on bills",
    "settings.language": "Language",
    "settings.languageHint": "Choose your preferred display language",
    "settings.themeColor": "Theme Color",
    "settings.themeHint": "Choose your preferred color theme for the billing interface",
    "settings.billDetails": "Bill Details",
    "settings.billHint": "Edit shop name, address, phone number & footer printed on bills",
    "settings.shopName": "Shop Name *",
    "settings.phone": "Phone Number",
    "settings.address": "Shop Address",
    "settings.gstin": "GSTIN (Optional)",
    "settings.billPrefix": "Bill Prefix",
    "settings.thankYou": "Thank You Message (Bill Footer)",
    "settings.save": "Save Bill Details",
    "settings.saving": "Saving...",
  },
  ta: {
    "nav.pos": "பில்லிங் POS",
    "nav.reports": "ரிப்போர்ட்ஸ்",
    "nav.settings": "செட்டிங்ஸ்",
    "nav.signOut": "வெளியேறு",
    "pos.title": "பில்லிங் POS",
    "pos.subtitle": "கோடு/பார்கோடு, எண்ணிக்கை & விலை போட்டு Enter அழுத்தினால் பில் நேரடியாக வரும்",
    "pos.quickEntry": "விரைவு நேரடி பில்",
    "pos.quickHint": "பார்கோடு/கோடு, எண்ணிக்கை & விலை போட்டு Enter அழுத்தவும்",
    "pos.code": "கோடு / பார்கோடு",
    "pos.codePlaceholder": "எ.கா. 1, 2 அல்லது பார்கோடு",
    "pos.qty": "எண்ணிக்கை",
    "pos.price": "விலை / தொகை (₹) *",
    "pos.pricePlaceholder": "எ.கா. 250",
    "pos.add": "சேர்",
    "pos.billEnter": "பில் (Enter)",
    "pos.billing": "பில் ஆகிறது...",
    "pos.billDiscount": "பில் தள்ளுபடி ₹",
    "pos.taxMode": "வரி முறை",
    "pos.noGst": "கூடுதல் GST இல்லை",
    "pos.roundOff": "ரவுண்ட் ஆஃப்",
    "pos.paymentMode": "பணம் செலுத்தும் முறை",
    "pos.cash": "பணம்",
    "pos.upi": "UPI",
    "pos.card": "கார்டு",
    "pos.bank": "வங்கி",
    "pos.split": "பிரித்து",
    "pos.due": "பாக்கி",
    "pos.subtotal": "கூட்டுத்தொகை",
    "pos.totalDiscount": "மொத்த தள்ளுபடி",
    "pos.grandTotal": "மொத்த தொகை",
    "pos.confirmPrint": "பில் உறுதி & பிரிண்ட்",
    "pos.autoPrintOn": "ஆட்டோ-பிரிண்ட் ON",
    "pos.autoPrintOff": "ஆட்டோ-பிரிண்ட் OFF",
    "pos.onlineMode": "ஆன்லைன்",
    "pos.offlineMode": "ஆஃப்லைன்",
    "reports.title": "ரிப்போர்ட்ஸ் & கணக்கு",
    "reports.subtitle": "விற்பனை, GST, ஸ்டாக் மற்றும் கணக்கு அறிக்கைகளை PDF / Excel-இல் பதிவிறக்கவும்",
    "reports.resetBills": "ரீசெட் பில் (01)",
    "reports.resetting": "ரீசெட் ஆகிறது...",
    "reports.exportExcel": "Excel பதிவிறக்கு",
    "reports.exportPdf": "PDF பதிவிறக்கு",
    "reports.dateRange": "தேதி வரம்பு:",
    "reports.to": "முதல்",
    "reports.applyFilter": "பில்டர் செய்",
    "reports.clear": "அழி",
    "reports.loading": "ரிப்போர்ட் தயாராகிறது...",
    "reports.empty": "இந்த ரிப்போர்ட்டில் பதிவுகள் இல்லை",
    "settings.title": "செட்டிங்ஸ்",
    "settings.subtitle": "மொழி, தீம் கலர் மற்றும் பில்லில் வரும் கடை விவரங்களை மாற்றவும்",
    "settings.language": "மொழி (Language)",
    "settings.languageHint": "உங்களுக்கு விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்",
    "settings.themeColor": "தீம் கலர்",
    "settings.themeHint": "பில்லிங் பக்கத்திற்கு விருப்பமான கலரைத் தேர்ந்தெடுக்கவும்",
    "settings.billDetails": "பில் விவரங்கள்",
    "settings.billHint": "பில்லில் பிரிண்ட் ஆகும் கடை பெயர், முகவரி, போன் நம்பர் மாற்றவும்",
    "settings.shopName": "கடை பெயர் *",
    "settings.phone": "போன் நம்பர்",
    "settings.address": "கடை முகவரி",
    "settings.gstin": "GSTIN (விருப்பம்)",
    "settings.billPrefix": "பில் முன்னொட்டு",
    "settings.thankYou": "நன்றி செய்தி (பில் அடிப்பகுதி)",
    "settings.save": "விவரங்களை சேமி",
    "settings.saving": "சேமிக்கிறது...",
  },
  hi: {
    "nav.pos": "बिलिंग POS",
    "nav.reports": "रिपोर्ट्स",
    "nav.settings": "सेटिंग्स",
    "nav.signOut": "लॉग आउट",
    "pos.title": "बिलिंग POS",
    "pos.subtitle": "कोड/बारकोड, मात्रा और कीमत डालकर Enter दबाएं — बिल सीधे प्रिंट होगा",
    "pos.quickEntry": "त्वरित बिल एंट्री",
    "pos.quickHint": "बारकोड/कोड, मात्रा और कीमत डालें — सीधे बिल के लिए Enter दबाएं",
    "pos.code": "कोड / बारकोड",
    "pos.codePlaceholder": "जैसे 1, 2 या बारकोड स्कैन करें",
    "pos.qty": "मात्रा",
    "pos.price": "कीमत / राशि (₹) *",
    "pos.pricePlaceholder": "जैसे 250",
    "pos.add": "जोड़ें",
    "pos.billEnter": "बिल (Enter)",
    "pos.billing": "बिल बन रहा है...",
    "pos.billDiscount": "बिल छूट ₹",
    "pos.taxMode": "टैक्स मोड",
    "pos.noGst": "अतिरिक्त GST नहीं",
    "pos.roundOff": "राउंड ऑफ",
    "pos.paymentMode": "भुगतान का तरीका",
    "pos.cash": "नकद",
    "pos.upi": "UPI",
    "pos.card": "कार्ड",
    "pos.bank": "बैंक",
    "pos.split": "बांटकर",
    "pos.due": "बाकी",
    "pos.subtotal": "उप-योग",
    "pos.totalDiscount": "कुल छूट",
    "pos.grandTotal": "कुल राशि",
    "pos.confirmPrint": "बिल कन्फर्म व प्रिंट",
    "pos.autoPrintOn": "ऑटो-प्रिंट चालू",
    "pos.autoPrintOff": "ऑटो-प्रिंट बंद",
    "pos.onlineMode": "ऑनलाइन",
    "pos.offlineMode": "ऑफलाइन",
    "reports.title": "रिपोर्ट्स और विश्लेषण",
    "reports.subtitle": "बिक्री, GST, स्टॉक और ग्राहक रिपोर्ट PDF या Excel में डाउनलोड करें",
    "reports.resetBills": "बिल रीसेट (01)",
    "reports.resetting": "रीसेट हो रहा है...",
    "reports.exportExcel": "Excel डाउनलोड",
    "reports.exportPdf": "PDF डाउनलोड",
    "reports.dateRange": "तारीख चुनें:",
    "reports.to": "से",
    "reports.applyFilter": "फ़िल्टर लगाएं",
    "reports.clear": "साफ़ करें",
    "reports.loading": "रिपोर्ट लोड हो रही है...",
    "reports.empty": "इस रिपोर्ट में कोई रिकॉर्ड नहीं मिला",
    "settings.title": "सेटिंग्स",
    "settings.subtitle": "भाषा, थीम रंग और बिल पर छपने वाले दुकान के विवरण बदलें",
    "settings.language": "भाषा (Language)",
    "settings.languageHint": "अपनी पसंदीदा भाषा चुनें",
    "settings.themeColor": "थीम रंग",
    "settings.themeHint": "बिलिंग इंटरफ़ेस के लिए अपना पसंदीदा रंग चुनें",
    "settings.billDetails": "बिल विवरण",
    "settings.billHint": "बिल पर छपने वाला दुकान का नाम, पता, फ़ोन नंबर बदलें",
    "settings.shopName": "दुकान का नाम *",
    "settings.phone": "फ़ोन नंबर",
    "settings.address": "दुकान का पता",
    "settings.gstin": "GSTIN (वैकल्पिक)",
    "settings.billPrefix": "बिल उपसर्ग",
    "settings.thankYou": "धन्यवाद संदेश (बिल फ़ुटर)",
    "settings.save": "विवरण सहेजें",
    "settings.saving": "सहेजा जा रहा है...",
  },
};

const LANG_STORAGE_KEY = "bb_pos_lang";

interface LanguageContextValue {
  lang: LangCode;
  setLang: (code: LangCode) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextValue>({
  lang: "en",
  setLang: () => {},
  t: (key) => TRANSLATIONS.en[key] || key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<LangCode>("en");

  useEffect(() => {
    const saved = localStorage.getItem(LANG_STORAGE_KEY) as LangCode | null;
    if (saved && (saved === "en" || saved === "ta" || saved === "hi")) {
      setLangState(saved);
      document.documentElement.lang = saved;
    }
  }, []);

  const setLang = (code: LangCode) => {
    setLangState(code);
    if (typeof window !== "undefined") {
      localStorage.setItem(LANG_STORAGE_KEY, code);
      document.documentElement.lang = code;
    }
  };

  const t = (key: string) => TRANSLATIONS[lang]?.[key] || TRANSLATIONS.en[key] || key;

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
