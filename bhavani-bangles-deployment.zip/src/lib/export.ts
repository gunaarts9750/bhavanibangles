"use client";

import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export function exportToExcel(rows: Record<string, unknown>[], fileName: string, sheetName = "Sheet1") {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  XLSX.writeFile(workbook, `${fileName}.xlsx`);
}

export async function parseExcelFile(file: File): Promise<Record<string, unknown>[]> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });
  const firstSheet = workbook.SheetNames[0];
  const sheet = workbook.Sheets[firstSheet];
  return XLSX.utils.sheet_to_json(sheet);
}

export function exportTableToPDF(params: {
  title: string;
  subtitle?: string;
  headers: string[];
  rows: (string | number)[][];
  fileName: string;
  shopName?: string;
}) {
  const doc = new jsPDF({ orientation: params.headers.length > 7 ? "landscape" : "portrait" });
  doc.setFontSize(16);
  doc.setTextColor(44, 30, 26);
  doc.text(params.shopName || "BHAVANI BANGLES", 14, 16);

  doc.setFontSize(12);
  doc.setTextColor(183, 110, 121);
  doc.text(params.title, 14, 24);

  if (params.subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(110, 90, 82);
    doc.text(params.subtitle, 14, 30);
  }

  autoTable(doc, {
    head: [params.headers],
    body: params.rows,
    startY: params.subtitle ? 35 : 30,
    styles: { fontSize: 8.5, textColor: [44, 30, 26] },
    headStyles: { fillColor: [183, 110, 121], textColor: [255, 255, 255] },
    alternateRowStyles: { fillColor: [250, 247, 242] },
  });

  doc.save(`${params.fileName}.pdf`);
}

export interface PrintableInvoiceData {
  invoiceNumber: string;
  saleDate: string;
  customerName: string;
  customerPhone?: string | null;
  subtotal: number;
  itemDiscount: number;
  billDiscount: number;
  gstType: string;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalGst: number;
  roundOff: number;
  grandTotal: number;
  paidAmount: number;
  balanceDue: number;
  paymentMethod: string;
  paymentStatus: string;
  items: {
    productName: string;
    productCode: string;
    hsnCode?: string | null;
    unit: string;
    quantity: number;
    unitPrice: number;
    discount: number;
    gstPercent: number;
    gstAmount: number;
    total: number;
  }[];
}

export interface ShopSettingData {
  shopName: string;
  shopTagline?: string | null;
  address: string;
  phone: string;
  email?: string | null;
  gstin?: string | null;
  invoiceTerms?: string | null;
  thankYouMessage?: string | null;
}

export function downloadInvoicePDF(
  invoice: PrintableInvoiceData,
  shop: ShopSettingData,
  format: "A4" | "THERMAL_80" | "THERMAL_58" = "A4"
) {
  if (format === "A4") {
    const doc = new jsPDF({ unit: "mm", format: "a4" });
    doc.setFillColor(250, 247, 242);
    doc.rect(0, 0, 210, 38, "F");

    doc.setFontSize(20);
    doc.setTextColor(44, 30, 26);
    doc.text(shop.shopName, 14, 16);

    doc.setFontSize(9);
    doc.setTextColor(110, 90, 82);
    doc.text(shop.address, 14, 23);
    doc.text(`Phone: ${shop.phone}${shop.gstin ? `  |  GSTIN: ${shop.gstin}` : ""}`, 14, 29);

    doc.setFontSize(13);
    doc.setTextColor(183, 110, 121);
    doc.text("TAX INVOICE", 196, 16, { align: "right" });
    doc.setFontSize(9.5);
    doc.setTextColor(44, 30, 26);
    doc.text(`Invoice #: ${invoice.invoiceNumber}`, 196, 23, { align: "right" });
    doc.text(`Date: ${new Date(invoice.saleDate).toLocaleString("en-IN")}`, 196, 29, { align: "right" });

    doc.setFontSize(10);
    doc.text(`Bill To: ${invoice.customerName}`, 14, 46);
    if (invoice.customerPhone) {
      doc.setFontSize(9);
      doc.text(`Phone: ${invoice.customerPhone}`, 14, 52);
    }
    doc.text(`Payment Mode: ${invoice.paymentMethod} (${invoice.paymentStatus})`, 196, 46, { align: "right" });

    autoTable(doc, {
      startY: 58,
      head: [["#", "Product", "HSN", "Qty", "Rate", "Disc", "GST%", "Total"]],
      body: invoice.items.map((it, idx) => [
        idx + 1,
        `${it.productName} (${it.productCode})`,
        it.hsnCode || "7117",
        `${it.quantity} ${it.unit}`,
        `Rs.${it.unitPrice.toFixed(2)}`,
        `Rs.${it.discount.toFixed(2)}`,
        `${it.gstPercent}%`,
        `Rs.${it.total.toFixed(2)}`,
      ]),
      styles: { fontSize: 8.5, textColor: [44, 30, 26] },
      headStyles: { fillColor: [183, 110, 121], textColor: [255, 255, 255] },
      alternateRowStyles: { fillColor: [250, 247, 242] },
    });

    const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
    const summaryX = 132;
    doc.setFontSize(9.5);
    doc.text(`Subtotal:`, summaryX, finalY);
    doc.text(`Rs.${invoice.subtotal.toFixed(2)}`, 196, finalY, { align: "right" });

    let y = finalY + 6;
    if (invoice.billDiscount + invoice.itemDiscount > 0) {
      doc.text(`Discount:`, summaryX, y);
      doc.text(`-Rs.${(invoice.billDiscount + invoice.itemDiscount).toFixed(2)}`, 196, y, { align: "right" });
      y += 6;
    }
    if (invoice.gstType === "IGST") {
      doc.text(`IGST:`, summaryX, y);
      doc.text(`Rs.${invoice.igstAmount.toFixed(2)}`, 196, y, { align: "right" });
      y += 6;
    } else if (invoice.totalGst > 0) {
      doc.text(`CGST + SGST:`, summaryX, y);
      doc.text(`Rs.${invoice.cgstAmount.toFixed(2)} + Rs.${invoice.sgstAmount.toFixed(2)}`, 196, y, { align: "right" });
      y += 6;
    }
    if (invoice.roundOff !== 0) {
      doc.text(`Round Off:`, summaryX, y);
      doc.text(`Rs.${invoice.roundOff.toFixed(2)}`, 196, y, { align: "right" });
      y += 6;
    }

    doc.setFontSize(12);
    doc.setTextColor(183, 110, 121);
    doc.text(`Grand Total:`, summaryX, y + 2);
    doc.text(`Rs.${invoice.grandTotal.toFixed(2)}`, 196, y + 2, { align: "right" });

    doc.setFontSize(9.5);
    doc.setTextColor(44, 30, 26);
    doc.text(`Amount Paid: Rs.${invoice.paidAmount.toFixed(2)}`, summaryX, y + 9);
    if (invoice.balanceDue > 0) {
      doc.setTextColor(185, 28, 28);
      doc.text(`Balance Due: Rs.${invoice.balanceDue.toFixed(2)}`, summaryX, y + 15);
    }

    if (shop.invoiceTerms) {
      doc.setFontSize(8);
      doc.setTextColor(110, 90, 82);
      doc.text("Terms & Conditions:", 14, finalY);
      doc.text(doc.splitTextToSize(shop.invoiceTerms, 108), 14, finalY + 5);
    }

    doc.setFontSize(9);
    doc.setTextColor(183, 110, 121);
    doc.text(shop.thankYouMessage || `Thank you for shopping at ${shop.shopName}!`, 105, 285, { align: "center" });

    doc.save(`${invoice.invoiceNumber}-A4.pdf`);
  } else {
    const width = format === "THERMAL_80" ? 80 : 58;
    const height = Math.max(130, 85 + invoice.items.length * 10);
    const doc = new jsPDF({ unit: "mm", format: [width, height] });
    const cx = width / 2;
    let y = 8;

    doc.setFontSize(format === "THERMAL_80" ? 11 : 9);
    doc.text(shop.shopName, cx, y, { align: "center" });
    y += 4.5;
    doc.setFontSize(7);
    const addrLines = doc.splitTextToSize(shop.address, width - 8);
    doc.text(addrLines, cx, y, { align: "center" });
    y += addrLines.length * 3.2;
    doc.text(`Ph: ${shop.phone}`, cx, y, { align: "center" });
    y += 3.5;
    if (shop.gstin) {
      doc.text(`GSTIN: ${shop.gstin}`, cx, y, { align: "center" });
      y += 3.5;
    }
    doc.text("----------------------------------------", cx, y, { align: "center" });
    y += 4;
    doc.text(`Inv: ${invoice.invoiceNumber}`, 4, y);
    doc.text(new Date(invoice.saleDate).toLocaleDateString("en-IN"), width - 4, y, { align: "right" });
    y += 3.5;
    doc.text(`Cust: ${invoice.customerName}`, 4, y);
    y += 4;
    doc.text("----------------------------------------", cx, y, { align: "center" });
    y += 4;

    for (const it of invoice.items) {
      const name = it.productName.length > (format === "THERMAL_80" ? 28 : 19)
        ? it.productName.slice(0, format === "THERMAL_80" ? 27 : 18) + "."
        : it.productName;
      doc.text(name, 4, y);
      y += 3.3;
      doc.text(`  ${it.quantity} x ${it.unitPrice.toFixed(0)} (GST ${it.gstPercent}%)`, 4, y);
      doc.text(`Rs.${it.total.toFixed(2)}`, width - 4, y, { align: "right" });
      y += 4;
    }

    doc.text("----------------------------------------", cx, y, { align: "center" });
    y += 4;
    doc.text(`Subtotal:`, 4, y);
    doc.text(`Rs.${invoice.subtotal.toFixed(2)}`, width - 4, y, { align: "right" });
    y += 3.5;
    doc.text(`Total GST:`, 4, y);
    doc.text(`Rs.${invoice.totalGst.toFixed(2)}`, width - 4, y, { align: "right" });
    y += 4;
    doc.setFontSize(9);
    doc.text(`GRAND TOTAL:`, 4, y);
    doc.text(`Rs.${invoice.grandTotal.toFixed(2)}`, width - 4, y, { align: "right" });
    y += 4.5;
    doc.setFontSize(7);
    doc.text(`Paid (${invoice.paymentMethod}): Rs.${invoice.paidAmount.toFixed(2)}`, 4, y);
    y += 3.5;
    if (invoice.balanceDue > 0) {
      doc.text(`Balance Due: Rs.${invoice.balanceDue.toFixed(2)}`, 4, y);
      y += 3.5;
    }
    y += 3;
    doc.text(shop.thankYouMessage || "Thank you! Visit again.", cx, y, { align: "center" });

    doc.save(`${invoice.invoiceNumber}-${format}.pdf`);
  }
}
