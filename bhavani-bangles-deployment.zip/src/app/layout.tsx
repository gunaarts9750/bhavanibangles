import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/components/AuthContext";
import { LanguageProvider } from "@/lib/i18n";

export const metadata: Metadata = {
  title: "BHAVANI BANGLES — Retail Billing & Inventory Management",
  description: "Premium Retail POS Billing, GST Invoicing & Inventory Management Software for BHAVANI BANGLES.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans bg-ivory-100 text-espresso-900 min-h-screen">
        <LanguageProvider>
          <AuthProvider>{children}</AuthProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
