"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Gem, Lock, User, Eye, EyeOff, ArrowRight, KeyRound, CheckCircle2 } from "lucide-react";
import { useAuth } from "@/components/AuthContext";

export default function LoginPage() {
  const router = useRouter();
  const { refreshUser } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Forgot Password modal state
  const [forgotOpen, setForgotOpen] = useState(false);
  const [fpUser, setFpUser] = useState("");
  const [fpCode, setFpCode] = useState("");
  const [fpNewPass, setFpNewPass] = useState("");
  const [fpStep, setFpStep] = useState<1 | 2>(1);
  const [fpMsg, setFpMsg] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login failed");
        return;
      }
      await refreshUser();
      router.replace("/pos");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setFpMsg("");
    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(
        fpStep === 1
          ? { username: fpUser }
          : { username: fpUser, resetCode: fpCode, newPassword: fpNewPass }
      ),
    });
    const data = await res.json();
    if (!res.ok) {
      setFpMsg(data.error || "Reset failed");
      return;
    }
    if (fpStep === 1) {
      setFpStep(2);
      setFpMsg(`${data.message} Recovery Code: ${data.recoveryCodeHint}`);
    } else {
      setFpMsg(data.message);
      setTimeout(() => {
        setForgotOpen(false);
        setFpStep(1);
        setFpCode("");
        setFpNewPass("");
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen bg-ivory-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 bg-white rounded-3xl shadow-elevated border border-ivory-300 overflow-hidden">
        {/* Left Brand Showcase */}
        <div className="bg-gradient-to-br from-espresso-900 via-espresso-800 to-rosegold-900 text-ivory-100 p-8 md:p-10 flex flex-col justify-between">
          <div>
            <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-white/10 border border-champagne-400/30 text-champagne-200 text-xs font-medium">
              <Gem className="w-3.5 h-3.5 text-champagne-300" />
              Luxury Retail POS Suite
            </div>
            <h1 className="font-serif text-4xl font-bold tracking-wide text-white mt-6 leading-tight">
              BHAVANI BANGLES
            </h1>
            <p className="text-champagne-200/90 text-sm mt-2">
              Complete Retail Billing, GST Invoicing & Inventory Management Software
            </p>
          </div>

          <div className="space-y-3 my-8">
            {[
              "Fast Barcode & Keyboard-Ready POS Billing",
              "Real-Time Multi-Category Bangle Inventory",
              "A4, 80mm & 58mm Thermal GST Invoices",
              "Customer CRM, Suppliers, Purchases & Profit Analytics",
            ].map((feat) => (
              <div key={feat} className="flex items-center gap-2.5 text-xs text-ivory-200">
                <CheckCircle2 className="w-4 h-4 text-champagne-400 shrink-0" />
                <span>{feat}</span>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-white/10 text-[11px] text-ivory-300/80">
            Role-based access • Encrypted sessions • Live database transactions
          </div>
        </div>

        {/* Right Sign-in Form */}
        <div className="p-8 md:p-10 flex flex-col justify-center">
          <div className="mb-6">
            <h2 className="font-serif text-2xl font-bold text-espresso-900">Welcome Back</h2>
            <p className="text-xs text-espresso-500 mt-1">Sign in with your staff or owner credentials</p>
          </div>

          {error && (
            <div className="mb-4 rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs text-rose-700 font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="bb-label">Username</label>
              <div className="relative">
                <User className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bb-input pl-10"
                  placeholder="Enter username"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="bb-label mb-0">Password</label>
                <button
                  type="button"
                  onClick={() => setForgotOpen(true)}
                  className="text-xs text-rosegold-600 hover:underline font-medium"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bb-input pl-10 pr-10"
                  placeholder="Enter password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-espresso-400 hover:text-espresso-700"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="bb-btn-primary w-full py-3 mt-2">
              {loading ? "Signing in..." : "Sign In to Store"}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {forgotOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-elevated space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blush-100 text-rosegold-600">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-xl font-bold text-espresso-900">Account Recovery</h3>
                <p className="text-xs text-espresso-500">Reset your Bhavani Bangles password</p>
              </div>
            </div>
            {fpMsg && (
              <div className="rounded-xl bg-ivory-100 border border-champagne-300 p-3 text-xs text-espresso-800">
                {fpMsg}
              </div>
            )}
            <form onSubmit={handleForgot} className="space-y-3">
              <div>
                <label className="bb-label">Username</label>
                <input
                  type="text"
                  value={fpUser}
                  onChange={(e) => setFpUser(e.target.value)}
                  className="bb-input"
                  placeholder="e.g. cashier"
                  required
                />
              </div>
              {fpStep === 2 && (
                <>
                  <div>
                    <label className="bb-label">6-Digit Recovery Code</label>
                    <input
                      type="text"
                      value={fpCode}
                      onChange={(e) => setFpCode(e.target.value)}
                      className="bb-input"
                      required
                    />
                  </div>
                  <div>
                    <label className="bb-label">New Password</label>
                    <input
                      type="password"
                      value={fpNewPass}
                      onChange={(e) => setFpNewPass(e.target.value)}
                      className="bb-input"
                      minLength={6}
                      required
                    />
                  </div>
                </>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setForgotOpen(false)} className="bb-btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="bb-btn-primary">
                  {fpStep === 1 ? "Generate Code" : "Update Password"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
