"use client";

import React, { useEffect, useState } from "react";
import { RotateCcw, Plus, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatDateTime } from "@/lib/format";

interface ReturnRow {
  id: string;
  returnNumber: string;
  returnDate: string;
  returnedItems: string;
  reason: string;
  refundAmount: number;
  exchangeDiff: number;
  refundMethod: string;
  sale: { invoiceNumber: string; customerName: string };
}

interface SaleLookup {
  id: string;
  invoiceNumber: string;
  customerName: string;
  items: { productId: string; productName: string; quantity: number; unitPrice: number }[];
}

export default function ReturnsPage() {
  const [returns, setReturns] = useState<ReturnRow[]>([]);
  const [sales, setSales] = useState<SaleLookup[]>([]);
  const [modalOpen, setModalOpen] = useState(false);

  const [selectedSaleId, setSelectedSaleId] = useState("");
  const [returnQtys, setReturnQtys] = useState<Record<string, number>>({});
  const [reason, setReason] = useState("");
  const [refundMethod, setRefundMethod] = useState("CASH");
  const [error, setError] = useState("");

  const loadAll = async () => {
    const [rRes, sRes] = await Promise.all([fetch("/api/returns"), fetch("/api/sales")]);
    if (rRes.ok) setReturns((await rRes.json()).returns || []);
    if (sRes.ok) setSales(((await sRes.json()).sales || []).filter((s: { isCancelled: boolean }) => !s.isCancelled));
  };

  useEffect(() => {
    loadAll();
  }, []);

  const selectedSale = sales.find((s) => s.id === selectedSaleId) || null;

  const handleProcessReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!selectedSale) return;
    const returnedItems = selectedSale.items
      .filter((it) => (returnQtys[it.productId] || 0) > 0)
      .map((it) => ({
        productId: it.productId,
        productName: it.productName,
        quantity: returnQtys[it.productId],
        unitPrice: it.unitPrice,
      }));

    if (returnedItems.length === 0) {
      setError("Select quantity > 0 for at least one item to return.");
      return;
    }

    const res = await fetch("/api/returns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ saleId: selectedSale.id, returnedItems, reason, refundMethod }),
    });
    const d = await res.json();
    if (!res.ok) {
      setError(d.error || "Return failed");
      return;
    }
    setModalOpen(false);
    setReturnQtys({});
    setReason("");
    loadAll();
  };

  return (
    <AppShell
      title="Sales Returns & Exchange"
      subtitle="Process customer returns, restock items automatically & track refunds"
      actions={
        <button
          onClick={() => {
            setSelectedSaleId(sales[0]?.id || "");
            setModalOpen(true);
          }}
          className="bb-btn-primary py-2 px-3.5 text-xs"
        >
          <Plus className="w-4 h-4" /> Process Return / Exchange
        </button>
      }
    >
      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                <th className="py-3 px-4 text-left">Return #</th>
                <th className="py-3 px-3 text-left">Date</th>
                <th className="py-3 px-3 text-left">Original Invoice</th>
                <th className="py-3 px-3 text-left">Customer</th>
                <th className="py-3 px-3 text-left">Returned Items</th>
                <th className="py-3 px-3 text-left">Reason</th>
                <th className="py-3 px-3 text-right">Refund</th>
                <th className="py-3 px-4 text-center">Mode</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {returns.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-espresso-400">
                    <RotateCcw className="w-6 h-6 mx-auto mb-2 opacity-40" />
                    No sales returns recorded yet
                  </td>
                </tr>
              ) : (
                returns.map((r) => {
                  const items = JSON.parse(r.returnedItems || "[]") as { productName: string; quantity: number }[];
                  return (
                    <tr key={r.id}>
                      <td className="py-3 px-4 font-bold text-espresso-900">{r.returnNumber}</td>
                      <td className="py-3 px-3 text-espresso-500">{formatDateTime(r.returnDate)}</td>
                      <td className="py-3 px-3 font-semibold text-rosegold-700">{r.sale.invoiceNumber}</td>
                      <td className="py-3 px-3">{r.sale.customerName}</td>
                      <td className="py-3 px-3">{items.map((i) => `${i.productName} (x${i.quantity})`).join(", ")}</td>
                      <td className="py-3 px-3 text-espresso-600">{r.reason}</td>
                      <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(r.refundAmount)}</td>
                      <td className="py-3 px-4 text-center"><span className="bb-badge-blush">{r.refundMethod}</span></td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleProcessReturn} className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Process Sales Return</h3>
              <button type="button" onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            {error && <div className="rounded-xl bg-rose-50 p-3 text-xs text-rose-700">{error}</div>}

            <div>
              <label className="bb-label">Select Invoice *</label>
              <select
                value={selectedSaleId}
                onChange={(e) => {
                  setSelectedSaleId(e.target.value);
                  setReturnQtys({});
                }}
                className="bb-input"
                required
              >
                {sales.map((s) => (
                  <option key={s.id} value={s.id}>{s.invoiceNumber} — {s.customerName}</option>
                ))}
              </select>
            </div>

            {selectedSale && (
              <div className="space-y-2 border border-ivory-200 rounded-xl p-3 bg-ivory-50">
                <p className="text-[11px] font-bold uppercase text-espresso-500">Select Return Quantities</p>
                {selectedSale.items.map((it) => (
                  <div key={it.productId} className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-medium text-espresso-800">{it.productName} (Sold: {it.quantity} @ {formatCurrency(it.unitPrice)})</span>
                    <input
                      type="number"
                      min={0}
                      max={it.quantity}
                      value={returnQtys[it.productId] || 0}
                      onChange={(e) => setReturnQtys({ ...returnQtys, [it.productId]: Number(e.target.value) })}
                      className="w-20 bb-input py-1 text-center"
                    />
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="bb-label">Return Reason *</label>
                <input value={reason} onChange={(e) => setReason(e.target.value)} className="bb-input" placeholder="Size mismatch (2.4 -> 2.6)" required />
              </div>
              <div>
                <label className="bb-label">Refund Mode</label>
                <select value={refundMethod} onChange={(e) => setRefundMethod(e.target.value)} className="bb-input">
                  <option value="CASH">Cash Refund</option>
                  <option value="UPI">UPI Refund</option>
                  <option value="STORE_CREDIT">Store Credit</option>
                  <option value="EXCHANGE">Exchange</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Confirm Return & Restock</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
