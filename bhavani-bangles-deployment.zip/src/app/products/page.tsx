"use client";

import React, { useEffect, useState } from "react";
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Barcode,
  Upload,
  Download,
  FileSpreadsheet,
  X,
  ImagePlus,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { BarcodeModal } from "@/components/BarcodeModal";
import { useAuth } from "@/components/AuthContext";
import { formatCurrency } from "@/lib/format";
import { exportToExcel, exportTableToPDF, parseExcelFile } from "@/lib/export";

interface Product {
  id: string;
  name: string;
  code: string;
  barcode: string;
  imageUrl?: string | null;
  categoryId: string;
  category: { id: string; name: string };
  brand?: string | null;
  designName?: string | null;
  color?: string | null;
  size?: string | null;
  material?: string | null;
  unit: string;
  purchasePrice: number;
  sellingPrice: number;
  mrp: number;
  discount: number;
  gstPercent: number;
  hsnCode?: string | null;
  openingStock: number;
  currentStock: number;
  minStockAlert: number;
  supplierId?: string | null;
  supplier?: { id: string; name: string } | null;
  rackNumber?: string | null;
  description?: string | null;
}

const EMPTY_FORM = {
  name: "",
  code: "",
  barcode: "",
  imageUrl: "",
  categoryId: "",
  brand: "Bhavani Signature",
  designName: "",
  color: "",
  size: "2.4",
  material: "",
  unit: "Set",
  purchasePrice: 0,
  sellingPrice: 0,
  mrp: 0,
  discount: 0,
  gstPercent: 3,
  hsnCode: "7117",
  openingStock: 0,
  minStockAlert: 5,
  supplierId: "",
  rackNumber: "",
  description: "",
};

export default function ProductsPage() {
  const { can } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [suppliers, setSuppliers] = useState<{ id: string; name: string }[]>([]);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [stockFilter, setStockFilter] = useState("");
  const [loading, setLoading] = useState(true);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [barcodeProduct, setBarcodeProduct] = useState<Product | null>(null);

  const loadAll = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (catFilter) params.set("categoryId", catFilter);
    if (stockFilter) params.set("stock", stockFilter);

    const [pRes, cRes, sRes] = await Promise.all([
      fetch(`/api/products?${params.toString()}`),
      fetch("/api/categories"),
      fetch("/api/suppliers"),
    ]);
    if (pRes.ok) setProducts((await pRes.json()).products || []);
    if (cRes.ok) {
      const cats = (await cRes.json()).categories || [];
      setCategories(cats);
    }
    if (sRes.ok) setSuppliers((await sRes.json()).suppliers || []);
    setLoading(false);
  };

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catFilter, stockFilter]);

  const openCreate = () => {
    setEditingId(null);
    setForm({ ...EMPTY_FORM, categoryId: categories[0]?.id || "" });
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      code: p.code,
      barcode: p.barcode,
      imageUrl: p.imageUrl || "",
      categoryId: p.categoryId,
      brand: p.brand || "",
      designName: p.designName || "",
      color: p.color || "",
      size: p.size || "",
      material: p.material || "",
      unit: p.unit,
      purchasePrice: p.purchasePrice,
      sellingPrice: p.sellingPrice,
      mrp: p.mrp,
      discount: p.discount,
      gstPercent: p.gstPercent,
      hsnCode: p.hsnCode || "7117",
      openingStock: p.currentStock,
      minStockAlert: p.minStockAlert,
      supplierId: p.supplierId || "",
      rackNumber: p.rackNumber || "",
      description: p.description || "",
    });
    setModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (res.ok && data.url) {
      setForm((prev) => ({ ...prev, imageUrl: data.url }));
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg("");
    try {
      const url = editingId ? `/api/products/${editingId}` : "/api/products";
      const method = editingId ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setMsg(data.error || "Failed to save product");
        return;
      }
      setModalOpen(false);
      await loadAll();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (p: Product) => {
    if (!confirm(`Archive product "${p.name}"?`)) return;
    const res = await fetch(`/api/products/${p.id}`, { method: "DELETE" });
    if (res.ok) loadAll();
  };

  const handleExcelImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const rows = await parseExcelFile(file);
    const res = await fetch("/api/products/bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows }),
    });
    const data = await res.json();
    if (res.ok) {
      setMsg(`Successfully imported ${data.imported} product(s) from Excel.`);
      loadAll();
    } else {
      setMsg(data.error || "Bulk import failed");
    }
    e.target.value = "";
  };

  const handleExportExcel = () => {
    exportToExcel(
      products.map((p) => ({
        Code: p.code,
        Barcode: p.barcode,
        Name: p.name,
        Category: p.category.name,
        Color: p.color || "",
        Size: p.size || "",
        Unit: p.unit,
        "Purchase Price": p.purchasePrice,
        "Selling Price": p.sellingPrice,
        MRP: p.mrp,
        "GST %": p.gstPercent,
        HSN: p.hsnCode || "",
        Stock: p.currentStock,
        Rack: p.rackNumber || "",
      })),
      "bhavani-bangles-products",
      "Products"
    );
  };

  const handleExportPDF = () => {
    exportTableToPDF({
      title: "Product Catalog & Pricing List",
      subtitle: `Total Active SKUs: ${products.length}`,
      headers: ["Code", "Product Name", "Category", "Size/Color", "Sell Price", "GST%", "Stock", "Rack"],
      rows: products.map((p) => [
        p.code,
        p.name,
        p.category.name,
        `${p.size || "-"} / ${p.color || "-"}`,
        `Rs.${p.sellingPrice}`,
        `${p.gstPercent}%`,
        `${p.currentStock} ${p.unit}`,
        p.rackNumber || "-",
      ]),
      fileName: "bhavani-bangles-catalog",
    });
  };

  return (
    <AppShell
      title="Product Catalog"
      subtitle="Manage bangles, bridal sets, jewellery SKUs, pricing & barcode labels"
      actions={
        <div className="flex items-center gap-2">
          {can("products", "canCreate") && (
            <>
              <label className="bb-btn-secondary py-2 px-3 text-xs cursor-pointer">
                <Upload className="w-3.5 h-3.5" /> Import Excel
                <input type="file" accept=".xlsx,.xls,.csv" onChange={handleExcelImport} className="hidden" />
              </label>
              <button onClick={openCreate} className="bb-btn-primary py-2 px-3.5 text-xs">
                <Plus className="w-4 h-4" /> Add Product
              </button>
            </>
          )}
        </div>
      }
    >
      {msg && (
        <div className="mb-4 rounded-xl bg-blush-100 border border-rosegold-300 px-4 py-2.5 text-xs text-espresso-900 flex justify-between">
          <span>{msg}</span>
          <button onClick={() => setMsg("")} className="underline">Close</button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bb-card p-4 mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && loadAll()}
              placeholder="Search name, code, barcode..."
              className="bb-input pl-10 py-2 text-xs"
            />
          </div>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="bb-input py-2 text-xs w-48">
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <select value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} className="bb-input py-2 text-xs w-40">
            <option value="">All Stock</option>
            <option value="low">Low Stock</option>
            <option value="out">Out of Stock</option>
          </select>
          <button onClick={loadAll} className="bb-btn-secondary py-2 px-3 text-xs">Search</button>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={handleExportExcel} className="bb-btn-secondary py-2 px-3 text-xs">
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Excel
          </button>
          <button onClick={handleExportPDF} className="bb-btn-secondary py-2 px-3 text-xs">
            <Download className="w-3.5 h-3.5 text-rosegold-600" /> PDF
          </button>
        </div>
      </div>

      {/* Product Table */}
      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-espresso-600 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4 text-left">Product & Code</th>
                <th className="py-3 px-3 text-left">Category</th>
                <th className="py-3 px-3 text-left">Details</th>
                <th className="py-3 px-3 text-right">Purchase</th>
                <th className="py-3 px-3 text-right">Selling / MRP</th>
                <th className="py-3 px-3 text-center">GST / HSN</th>
                <th className="py-3 px-3 text-center">Stock</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {loading ? (
                <tr><td colSpan={8} className="py-10 text-center text-espresso-400">Loading products...</td></tr>
              ) : products.length === 0 ? (
                <tr><td colSpan={8} className="py-10 text-center text-espresso-400">No products found</td></tr>
              ) : (
                products.map((p) => (
                  <tr key={p.id} className="hover:bg-ivory-50/70">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        {p.imageUrl ? (
                          <img src={p.imageUrl} alt={p.name} className="w-10 h-10 rounded-lg object-cover border border-ivory-300" />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-blush-100 text-rosegold-600 flex items-center justify-center font-serif font-bold text-sm shrink-0">
                            {p.name.slice(0, 2).toUpperCase()}
                          </div>
                        )}
                        <div>
                          <p className="font-semibold text-espresso-900">{p.name}</p>
                          <p className="text-[11px] text-espresso-400">{p.code} • {p.barcode}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="bb-badge-blush">{p.category.name}</span>
                    </td>
                    <td className="py-3 px-3 text-espresso-600">
                      <p>{p.color || "-"} • Size {p.size || "-"}</p>
                      <p className="text-[10px] text-espresso-400">Rack: {p.rackNumber || "-"} • {p.material || "-"}</p>
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-espresso-600">
                      {formatCurrency(p.purchasePrice)}
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      <p className="font-bold text-espresso-900">{formatCurrency(p.sellingPrice)}</p>
                      <p className="text-[10px] text-espresso-400">MRP {formatCurrency(p.mrp)}</p>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <p className="font-semibold">{p.gstPercent}%</p>
                      <p className="text-[10px] text-espresso-400">{p.hsnCode || "7117"}</p>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={
                          p.currentStock <= 0
                            ? "bb-badge-danger"
                            : p.currentStock <= p.minStockAlert
                            ? "bb-badge-warning"
                            : "bb-badge-success"
                        }
                      >
                        {p.currentStock} {p.unit}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => setBarcodeProduct(p)}
                          title="Print Barcode Labels"
                          className="p-1.5 rounded-lg hover:bg-ivory-200 text-espresso-600"
                        >
                          <Barcode className="w-4 h-4" />
                        </button>
                        {can("products", "canEdit") && (
                          <button
                            onClick={() => openEdit(p)}
                            title="Edit Product"
                            className="p-1.5 rounded-lg hover:bg-ivory-200 text-rosegold-600"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                        {can("products", "canDelete") && (
                          <button
                            onClick={() => handleDelete(p)}
                            title="Archive Product"
                            className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleSave}
            className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-elevated overflow-hidden"
          >
            <div className="px-6 py-4 border-b border-ivory-200 bg-ivory-50 flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">
                {editingId ? "Edit Product" : "Add New Product"}
              </h3>
              <button type="button" onClick={() => setModalOpen(false)} className="p-1.5 rounded-lg hover:bg-ivory-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="bb-label">Product Name *</label>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. Rajasthani Royal Bridal Chooda Set"
                  required
                />
              </div>
              <div>
                <label className="bb-label">Category *</label>
                <select
                  value={form.categoryId}
                  onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
                  className="bb-input"
                  required
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="bb-label">Product Code (Auto if blank)</label>
                <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="bb-input" placeholder="BB-BRD-003" />
              </div>
              <div>
                <label className="bb-label">Barcode (Auto if blank)</label>
                <input value={form.barcode} onChange={(e) => setForm({ ...form, barcode: e.target.value })} className="bb-input" placeholder="8901001..." />
              </div>
              <div>
                <label className="bb-label">Product Image</label>
                <label className="bb-input flex items-center gap-2 cursor-pointer text-xs text-espresso-500">
                  <ImagePlus className="w-4 h-4 text-rosegold-500" />
                  {form.imageUrl ? "Image uploaded ✓" : "Upload photo..."}
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>

              <div>
                <label className="bb-label">Brand</label>
                <input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">Design Name</label>
                <input value={form.designName} onChange={(e) => setForm({ ...form, designName: e.target.value })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">Material</label>
                <input value={form.material} onChange={(e) => setForm({ ...form, material: e.target.value })} className="bb-input" placeholder="Glass, Brass, Lac, Kundan" />
              </div>

              <div>
                <label className="bb-label">Colour</label>
                <input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="bb-input" placeholder="Maroon & Gold" />
              </div>
              <div>
                <label className="bb-label">Size</label>
                <input value={form.size} onChange={(e) => setForm({ ...form, size: e.target.value })} className="bb-input" placeholder="2.2 / 2.4 / 2.6 / 2.8" />
              </div>
              <div>
                <label className="bb-label">Unit</label>
                <select value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className="bb-input">
                  {["Set", "Pair", "Piece", "Dozen", "Box"].map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="bb-label">Purchase Price (₹)</label>
                <input type="number" step="0.01" value={form.purchasePrice} onChange={(e) => setForm({ ...form, purchasePrice: Number(e.target.value) })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">Selling Price (₹) *</label>
                <input type="number" step="0.01" value={form.sellingPrice} onChange={(e) => setForm({ ...form, sellingPrice: Number(e.target.value) })} className="bb-input" required />
              </div>
              <div>
                <label className="bb-label">MRP (₹)</label>
                <input type="number" step="0.01" value={form.mrp} onChange={(e) => setForm({ ...form, mrp: Number(e.target.value) })} className="bb-input" />
              </div>

              <div>
                <label className="bb-label">Default Discount (%)</label>
                <input type="number" step="0.1" value={form.discount} onChange={(e) => setForm({ ...form, discount: Number(e.target.value) })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">GST %</label>
                <input type="number" step="0.5" value={form.gstPercent} onChange={(e) => setForm({ ...form, gstPercent: Number(e.target.value) })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">HSN Code</label>
                <input value={form.hsnCode} onChange={(e) => setForm({ ...form, hsnCode: e.target.value })} className="bb-input" />
              </div>

              {!editingId && (
                <div>
                  <label className="bb-label">Opening Stock</label>
                  <input type="number" value={form.openingStock} onChange={(e) => setForm({ ...form, openingStock: Number(e.target.value) })} className="bb-input" />
                </div>
              )}
              <div>
                <label className="bb-label">Min Stock Alert</label>
                <input type="number" value={form.minStockAlert} onChange={(e) => setForm({ ...form, minStockAlert: Number(e.target.value) })} className="bb-input" />
              </div>
              <div>
                <label className="bb-label">Rack Number</label>
                <input value={form.rackNumber} onChange={(e) => setForm({ ...form, rackNumber: e.target.value })} className="bb-input" placeholder="A-01" />
              </div>

              <div>
                <label className="bb-label">Primary Supplier</label>
                <select value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })} className="bb-input">
                  <option value="">None</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-3">
                <label className="bb-label">Description</label>
                <textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bb-input" />
              </div>
            </div>

            <div className="px-6 py-4 border-t border-ivory-200 bg-ivory-50 flex justify-end gap-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" disabled={saving} className="bb-btn-primary">
                {saving ? "Saving..." : editingId ? "Update Product" : "Create Product"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Barcode Label Printer Modal */}
      {barcodeProduct && (
        <BarcodeModal product={barcodeProduct} onClose={() => setBarcodeProduct(null)} />
      )}
    </AppShell>
  );
}
