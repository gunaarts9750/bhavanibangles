"use client";

import React, { useEffect, useState } from "react";
import { Plus, Truck, Building2, IndianRupee, Trash2, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatDate } from "@/lib/format";

interface Supplier {
  id: string;
  name: string;
  contactPerson?: string | null;
  phone: string;
  email?: string | null;
  address?: string | null;
  gstin?: string | null;
  pendingBalance: number;
  _count?: { purchases: number; products: number };
}

interface Purchase {
  id: string;
  purchaseNumber: string;
  supplierInvoice?: string | null;
  purchaseDate: string;
  subtotal: number;
  gstAmount: number;
  totalAmount: number;
  paidAmount: number;
  pendingAmount: number;
  paymentStatus: string;
  supplier: { name: string };
  items: { id: string; quantity: number; purchasePrice: number; total: number; product: { name: string; code: string } }[];
}

export default function PurchasesPage() {
  const [tab, setTab] = useState<"purchases" | "suppliers">("purchases");
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; code: string; purchasePrice: number; gstPercent: number }[]>([]);

  const [purchaseModal, setPurchaseModal] = useState(false);
  const [supplierModal, setSupplierModal] = useState(false);
  const [paySupplier, setPaySupplier] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState(0);
  const [error, setError] = useState("");

  // Purchase Form
  const [pSupplierId, setPSupplierId] = useState("");
  const [pInvoice, setPInvoice] = useState("");
  const [pPaid, setPPaid] = useState(0);
  const [pMethod, setPMethod] = useState("BANK_TRANSFER");
  const [pItems, setPItems] = useState<{ productId: string; quantity: number; purchasePrice: number; gstPercent: number }[]>([]);

  // Supplier Form
  const [sForm, setSForm] = useState({ name: "", contactPerson: "", phone: "", email: "", address: "", gstin: "" });

  const loadAll = async () => {
    const [puRes, suRes, prRes] = await Promise.all([
      fetch("/api/purchases"),
      fetch("/api/suppliers"),
      fetch("/api/products"),
    ]);
    if (puRes.ok) setPurchases((await puRes.json()).purchases || []);
    if (suRes.ok) setSuppliers((await suRes.json()).suppliers || []);
    if (prRes.ok) setProducts((await prRes.json()).products || []);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const addPurchaseRow = () => {
    const first = products[0];
    if (!first) return;
    setPItems((prev) => [
      ...prev,
      { productId: first.id, quantity: 10, purchasePrice: first.purchasePrice, gstPercent: first.gstPercent },
    ]);
  };

  const purchaseTotal = pItems.reduce((sum, it) => {
    const base = it.quantity * it.purchasePrice;
    return sum + base + (base * it.gstPercent) / 100;
  }, 0);

  const handleSavePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/purchases", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        supplierId: pSupplierId,
        supplierInvoice: pInvoice,
        items: pItems,
        paidAmount: pPaid,
        paymentMethod: pMethod,
      }),
    });
    const d = await res.json();
    if (!res.ok) {
      setError(d.error || "Failed to record purchase");
      return;
    }
    setPurchaseModal(false);
    setPItems([]);
    setPInvoice("");
    setPPaid(0);
    loadAll();
  };

  const handleSaveSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/suppliers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sForm),
    });
    if (res.ok) {
      setSupplierModal(false);
      setSForm({ name: "", contactPerson: "", phone: "", email: "", address: "", gstin: "" });
      loadAll();
    }
  };

  const handlePaySupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paySupplier) return;
    const res = await fetch(`/api/suppliers/${paySupplier.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "PAYMENT", amount: payAmount, method: "BANK_TRANSFER" }),
    });
    if (res.ok) {
      setPaySupplier(null);
      setPayAmount(0);
      loadAll();
    }
  };

  return (
    <AppShell
      title="Purchases & Suppliers"
      subtitle="Record wholesale bangle stock purchases & track supplier ledgers"
      actions={
        <div className="flex items-center gap-2">
          <button onClick={() => setSupplierModal(true)} className="bb-btn-secondary py-2 px-3 text-xs">
            <Building2 className="w-3.5 h-3.5" /> Add Supplier
          </button>
          <button
            onClick={() => {
              setPSupplierId(suppliers[0]?.id || "");
              if (pItems.length === 0 && products[0]) {
                setPItems([{ productId: products[0].id, quantity: 10, purchasePrice: products[0].purchasePrice, gstPercent: products[0].gstPercent }]);
              }
              setPurchaseModal(true);
            }}
            className="bb-btn-primary py-2 px-3.5 text-xs"
          >
            <Plus className="w-4 h-4" /> New Purchase Entry
          </button>
        </div>
      }
    >
      <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-ivory-300 w-fit mb-5">
        <button
          onClick={() => setTab("purchases")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
            tab === "purchases" ? "bg-rosegold-500 text-white" : "text-espresso-600"
          }`}
        >
          <Truck className="w-3.5 h-3.5" /> Purchase Invoices ({purchases.length})
        </button>
        <button
          onClick={() => setTab("suppliers")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
            tab === "suppliers" ? "bg-rosegold-500 text-white" : "text-espresso-600"
          }`}
        >
          <Building2 className="w-3.5 h-3.5" /> Suppliers ({suppliers.length})
        </button>
      </div>

      {tab === "purchases" ? (
        <div className="bb-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
                <tr>
                  <th className="py-3 px-4 text-left">Purchase #</th>
                  <th className="py-3 px-3 text-left">Date</th>
                  <th className="py-3 px-3 text-left">Supplier</th>
                  <th className="py-3 px-3 text-left">Items</th>
                  <th className="py-3 px-3 text-right">Total</th>
                  <th className="py-3 px-3 text-right">Paid</th>
                  <th className="py-3 px-3 text-right">Pending</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ivory-200">
                {purchases.map((p) => (
                  <tr key={p.id}>
                    <td className="py-3 px-4 font-bold text-espresso-900">
                      {p.purchaseNumber}
                      {p.supplierInvoice && <p className="text-[10px] font-normal text-espresso-400">Ref: {p.supplierInvoice}</p>}
                    </td>
                    <td className="py-3 px-3 text-espresso-500">{formatDate(p.purchaseDate)}</td>
                    <td className="py-3 px-3 font-medium">{p.supplier.name}</td>
                    <td className="py-3 px-3 text-espresso-600">
                      {p.items.map((it) => `${it.product.name} (x${it.quantity})`).join(", ")}
                    </td>
                    <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(p.totalAmount)}</td>
                    <td className="py-3 px-3 text-right text-emerald-700 tabular-nums">{formatCurrency(p.paidAmount)}</td>
                    <td className="py-3 px-3 text-right text-rose-600 tabular-nums">{formatCurrency(p.pendingAmount)}</td>
                    <td className="py-3 px-4 text-center">
                      <span className={p.paymentStatus === "PAID" ? "bb-badge-success" : "bb-badge-warning"}>
                        {p.paymentStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {suppliers.map((s) => (
            <div key={s.id} className="bb-card p-5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold text-espresso-900">{s.name}</h3>
                  <p className="text-xs text-espresso-500">{s.contactPerson || "Primary Contact"} • {s.phone}</p>
                </div>
                <span className={s.pendingBalance > 0 ? "bb-badge-warning" : "bb-badge-success"}>
                  {s.pendingBalance > 0 ? `Due ${formatCurrency(s.pendingBalance)}` : "Settled"}
                </span>
              </div>
              <div className="text-xs text-espresso-600 space-y-1">
                {s.address && <p>{s.address}</p>}
                {s.gstin && <p className="font-mono text-[11px]">GSTIN: {s.gstin}</p>}
              </div>
              <div className="pt-3 border-t border-ivory-200 flex items-center justify-between text-xs">
                <span className="text-espresso-400">{s._count?.purchases || 0} purchase(s)</span>
                {s.pendingBalance > 0 && (
                  <button
                    onClick={() => {
                      setPaySupplier(s);
                      setPayAmount(s.pendingBalance);
                    }}
                    className="bb-btn-primary py-1.5 px-3 text-xs"
                  >
                    <IndianRupee className="w-3.5 h-3.5" /> Record Payment
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Purchase Modal */}
      {purchaseModal && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleSavePurchase} className="bg-white rounded-2xl max-w-3xl w-full p-6 space-y-4 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Record New Purchase (Auto-Updates Stock)</h3>
              <button type="button" onClick={() => setPurchaseModal(false)}><X className="w-4 h-4" /></button>
            </div>
            {error && <div className="rounded-xl bg-rose-50 p-3 text-xs text-rose-700">{error}</div>}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="bb-label">Supplier *</label>
                <select value={pSupplierId} onChange={(e) => setPSupplierId(e.target.value)} className="bb-input" required>
                  {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label className="bb-label">Supplier Invoice #</label>
                <input value={pInvoice} onChange={(e) => setPInvoice(e.target.value)} className="bb-input" placeholder="INV-8821" />
              </div>
              <div>
                <label className="bb-label">Payment Mode</label>
                <select value={pMethod} onChange={(e) => setPMethod(e.target.value)} className="bb-input">
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="UPI">UPI</option>
                  <option value="CASH">Cash</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="bb-label mb-0">Purchase Items</label>
                <button type="button" onClick={addPurchaseRow} className="text-xs font-semibold text-rosegold-600 hover:underline">
                  + Add Product Row
                </button>
              </div>
              {pItems.map((row, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                  <select
                    value={row.productId}
                    onChange={(e) => {
                      const pr = products.find((x) => x.id === e.target.value);
                      setPItems((prev) =>
                        prev.map((x, i) =>
                          i === idx ? { ...x, productId: e.target.value, purchasePrice: pr?.purchasePrice || 0, gstPercent: pr?.gstPercent || 3 } : x
                        )
                      );
                    }}
                    className="col-span-5 bb-input py-1.5 text-xs"
                  >
                    {products.map((pr) => <option key={pr.id} value={pr.id}>{pr.name} ({pr.code})</option>)}
                  </select>
                  <input
                    type="number"
                    min={1}
                    value={row.quantity}
                    onChange={(e) => setPItems((prev) => prev.map((x, i) => (i === idx ? { ...x, quantity: Number(e.target.value) } : x)))}
                    placeholder="Qty"
                    className="col-span-2 bb-input py-1.5 text-xs"
                  />
                  <input
                    type="number"
                    value={row.purchasePrice}
                    onChange={(e) => setPItems((prev) => prev.map((x, i) => (i === idx ? { ...x, purchasePrice: Number(e.target.value) } : x)))}
                    placeholder="Rate ₹"
                    className="col-span-2 bb-input py-1.5 text-xs"
                  />
                  <input
                    type="number"
                    value={row.gstPercent}
                    onChange={(e) => setPItems((prev) => prev.map((x, i) => (i === idx ? { ...x, gstPercent: Number(e.target.value) } : x)))}
                    placeholder="GST%"
                    className="col-span-2 bb-input py-1.5 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => setPItems((prev) => prev.filter((_, i) => i !== idx))}
                    className="col-span-1 text-rose-500 flex justify-center"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-ivory-200">
              <div>
                <p className="text-xs text-espresso-500">Total Purchase Value (Incl. GST)</p>
                <p className="text-xl font-bold text-rosegold-700 tabular-nums">{formatCurrency(purchaseTotal)}</p>
              </div>
              <div className="w-44">
                <label className="bb-label">Amount Paid Now (₹)</label>
                <input type="number" value={pPaid} onChange={(e) => setPPaid(Number(e.target.value))} className="bb-input" />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPurchaseModal(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Confirm Purchase & Add Stock</button>
            </div>
          </form>
        </div>
      )}

      {/* Add Supplier Modal */}
      {supplierModal && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={handleSaveSupplier} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 shadow-elevated">
            <h3 className="font-serif text-xl font-bold text-espresso-900">Add New Supplier</h3>
            <div><label className="bb-label">Supplier / Firm Name *</label><input value={sForm.name} onChange={(e) => setSForm({ ...sForm, name: e.target.value })} className="bb-input" required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">Contact Person</label><input value={sForm.contactPerson} onChange={(e) => setSForm({ ...sForm, contactPerson: e.target.value })} className="bb-input" /></div>
              <div><label className="bb-label">Phone *</label><input value={sForm.phone} onChange={(e) => setSForm({ ...sForm, phone: e.target.value })} className="bb-input" required /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">GSTIN</label><input value={sForm.gstin} onChange={(e) => setSForm({ ...sForm, gstin: e.target.value })} className="bb-input" /></div>
              <div><label className="bb-label">Email</label><input value={sForm.email} onChange={(e) => setSForm({ ...sForm, email: e.target.value })} className="bb-input" /></div>
            </div>
            <div><label className="bb-label">Address</label><input value={sForm.address} onChange={(e) => setSForm({ ...sForm, address: e.target.value })} className="bb-input" /></div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setSupplierModal(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Save Supplier</button>
            </div>
          </form>
        </div>
      )}

      {/* Pay Supplier Modal */}
      {paySupplier && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={handlePaySupplier} className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-elevated">
            <h3 className="font-serif text-xl font-bold text-espresso-900">Pay {paySupplier.name}</h3>
            <p className="text-xs text-espresso-500">Current Pending Balance: <b>{formatCurrency(paySupplier.pendingBalance)}</b></p>
            <div>
              <label className="bb-label">Payment Amount (₹)</label>
              <input type="number" min={1} max={paySupplier.pendingBalance} value={payAmount} onChange={(e) => setPayAmount(Number(e.target.value))} className="bb-input" required />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPaySupplier(null)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Record Payment</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
