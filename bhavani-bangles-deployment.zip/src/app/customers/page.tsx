"use client";

import React, { useEffect, useState } from "react";
import { UserPlus, Search, MessageCircle, Award, IndianRupee, Eye, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatDate } from "@/lib/format";

interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string | null;
  address?: string | null;
  birthday?: string | null;
  anniversary?: string | null;
  customerType: string;
  loyaltyPoints: number;
  totalPurchases: number;
  outstandingAmount: number;
  advanceBalance: number;
  _count?: { sales: number };
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    birthday: "",
    anniversary: "",
    customerType: "REGULAR",
    advanceBalance: 0,
  });

  const [detail, setDetail] = useState<(Customer & { sales: { id: string; invoiceNumber: string; saleDate: string; grandTotal: number; balanceDue: number; paymentStatus: string }[] }) | null>(null);
  const [duePayAmount, setDuePayAmount] = useState(0);

  const loadCustomers = async () => {
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (typeFilter !== "ALL") params.set("type", typeFilter);
    const res = await fetch(`/api/customers?${params.toString()}`);
    if (res.ok) setCustomers((await res.json()).customers || []);
  };

  useEffect(() => {
    loadCustomers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [typeFilter]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      setModalOpen(false);
      setForm({ name: "", phone: "", email: "", address: "", birthday: "", anniversary: "", customerType: "REGULAR", advanceBalance: 0 });
      loadCustomers();
    }
  };

  const openDetail = async (id: string) => {
    const res = await fetch(`/api/customers/${id}`);
    if (res.ok) {
      const d = await res.json();
      setDetail(d.customer);
      setDuePayAmount(d.customer.outstandingAmount || 0);
    }
  };

  const collectDue = async () => {
    if (!detail || duePayAmount <= 0) return;
    const res = await fetch(`/api/customers/${detail.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "COLLECT_DUE", amount: duePayAmount, method: "UPI" }),
    });
    if (res.ok) {
      await openDetail(detail.id);
      loadCustomers();
    }
  };

  return (
    <AppShell
      title="Customer CRM & Loyalty"
      subtitle="Manage bridal clients, VIP shoppers, due balances & WhatsApp outreach"
      actions={
        <button onClick={() => setModalOpen(true)} className="bb-btn-primary py-2 px-3.5 text-xs">
          <UserPlus className="w-4 h-4" /> Add Customer
        </button>
      }
    >
      <div className="bb-card p-4 mb-5 flex flex-wrap items-center gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && loadCustomers()}
            placeholder="Search by name, mobile, city..."
            className="bb-input pl-10 py-2 text-xs"
          />
        </div>
        {["ALL", "BRIDAL", "VIP", "REGULAR", "WHOLESALE"].map((t) => (
          <button
            key={t}
            onClick={() => setTypeFilter(t)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
              typeFilter === t ? "bg-rosegold-500 text-white border-rosegold-500" : "bg-white border-ivory-300 text-espresso-600"
            }`}
          >
            {t}
          </button>
        ))}
        <button onClick={loadCustomers} className="bb-btn-secondary py-2 px-3 text-xs">Search</button>
      </div>

      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                <th className="py-3 px-4 text-left">Customer</th>
                <th className="py-3 px-3 text-center">Tier</th>
                <th className="py-3 px-3 text-right">Total Purchases</th>
                <th className="py-3 px-3 text-right">Outstanding Due</th>
                <th className="py-3 px-3 text-center">Loyalty Pts</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {customers.map((c) => {
                const waMsg = encodeURIComponent(
                  `Namaste ${c.name} ji! Greetings from BHAVANI BANGLES. Explore our latest Bridal & Festive Bangle collection!${
                    c.outstandingAmount > 0 ? ` Friendly reminder: your pending balance is ₹${c.outstandingAmount}.` : ""
                  }`
                );
                const cleanPhone = c.phone.replace(/[^0-9]/g, "");
                return (
                  <tr key={c.id} className="hover:bg-ivory-50/70">
                    <td className="py-3 px-4">
                      <p className="font-semibold text-espresso-900">{c.name}</p>
                      <p className="text-[11px] text-espresso-400">{c.phone} {c.address ? `• ${c.address}` : ""}</p>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="bb-badge-blush">{c.customerType}</span>
                    </td>
                    <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(c.totalPurchases)}</td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      {c.outstandingAmount > 0 ? (
                        <span className="font-bold text-rose-600">{formatCurrency(c.outstandingAmount)}</span>
                      ) : (
                        <span className="text-emerald-600">Clear</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="inline-flex items-center gap-1 font-semibold text-champagne-700">
                        <Award className="w-3.5 h-3.5" /> {c.loyaltyPoints}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <a
                          href={`https://wa.me/${cleanPhone.length === 10 ? "91" + cleanPhone : cleanPhone}?text=${waMsg}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                          title="Send WhatsApp"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>
                        <button
                          onClick={() => openDetail(c.id)}
                          className="bb-btn-secondary py-1 px-2.5 text-xs"
                        >
                          <Eye className="w-3.5 h-3.5" /> History
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={handleSave} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 shadow-elevated">
            <h3 className="font-serif text-xl font-bold text-espresso-900">Add New Customer</h3>
            <div><label className="bb-label">Customer Name *</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bb-input" required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">Mobile Number *</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="bb-input" required /></div>
              <div>
                <label className="bb-label">Customer Type</label>
                <select value={form.customerType} onChange={(e) => setForm({ ...form, customerType: e.target.value })} className="bb-input">
                  <option value="REGULAR">Regular</option>
                  <option value="VIP">VIP</option>
                  <option value="BRIDAL">Bridal</option>
                  <option value="WHOLESALE">Wholesale</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">Birthday</label><input type="date" value={form.birthday} onChange={(e) => setForm({ ...form, birthday: e.target.value })} className="bb-input" /></div>
              <div><label className="bb-label">Anniversary</label><input type="date" value={form.anniversary} onChange={(e) => setForm({ ...form, anniversary: e.target.value })} className="bb-input" /></div>
            </div>
            <div><label className="bb-label">Address</label><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="bb-input" /></div>
            <div><label className="bb-label">Advance Deposit (₹)</label><input type="number" value={form.advanceBalance} onChange={(e) => setForm({ ...form, advanceBalance: Number(e.target.value) })} className="bb-input" /></div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Save Customer</button>
            </div>
          </form>
        </div>
      )}

      {/* Customer Detail & Due Collection Modal */}
      {detail && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-elevated max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-serif text-2xl font-bold text-espresso-900">{detail.name}</h3>
                <p className="text-xs text-espresso-500">{detail.phone} • {detail.address || "No address"} • {detail.customerType}</p>
              </div>
              <button onClick={() => setDetail(null)}><X className="w-5 h-5" /></button>
            </div>

            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="bg-ivory-50 p-3 rounded-xl border border-ivory-200">
                <p className="text-espresso-400">Total Purchases</p>
                <p className="text-base font-bold text-espresso-900 mt-0.5">{formatCurrency(detail.totalPurchases)}</p>
              </div>
              <div className="bg-rose-50/70 p-3 rounded-xl border border-rose-200">
                <p className="text-rose-700">Outstanding Due</p>
                <p className="text-base font-bold text-rose-700 mt-0.5">{formatCurrency(detail.outstandingAmount)}</p>
              </div>
              <div className="bg-champagne-50 p-3 rounded-xl border border-champagne-200">
                <p className="text-champagne-800">Loyalty Points</p>
                <p className="text-base font-bold text-champagne-800 mt-0.5">{detail.loyaltyPoints} pts</p>
              </div>
            </div>

            {detail.outstandingAmount > 0 && (
              <div className="bg-blush-50 border border-rosegold-200 rounded-xl p-4 flex flex-wrap items-end gap-3">
                <div className="flex-1">
                  <label className="bb-label">Collect Due Payment (₹)</label>
                  <input
                    type="number"
                    min={1}
                    max={detail.outstandingAmount}
                    value={duePayAmount}
                    onChange={(e) => setDuePayAmount(Number(e.target.value))}
                    className="bb-input py-1.5"
                  />
                </div>
                <button onClick={collectDue} className="bb-btn-primary py-2 text-xs">
                  <IndianRupee className="w-3.5 h-3.5" /> Record Payment
                </button>
              </div>
            )}

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-espresso-500 mb-2">Purchase Invoices</h4>
              <div className="divide-y divide-ivory-200 border border-ivory-200 rounded-xl">
                {detail.sales.length === 0 ? (
                  <p className="p-4 text-xs text-espresso-400 text-center">No invoices yet</p>
                ) : (
                  detail.sales.map((s) => (
                    <div key={s.id} className="px-4 py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-semibold text-espresso-900">{s.invoiceNumber}</p>
                        <p className="text-[11px] text-espresso-400">{formatDate(s.saleDate)}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{formatCurrency(s.grandTotal)}</p>
                        <span className={s.paymentStatus === "PAID" ? "text-emerald-600 text-[10px]" : "text-amber-600 text-[10px]"}>
                          {s.paymentStatus}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
