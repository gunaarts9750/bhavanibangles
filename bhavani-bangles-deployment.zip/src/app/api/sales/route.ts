import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("invoices", "canView");
  if (error) return error;

  const q = req.nextUrl.searchParams.get("q")?.trim() || "";
  const status = req.nextUrl.searchParams.get("status") || "";
  const from = req.nextUrl.searchParams.get("from") || "";
  const to = req.nextUrl.searchParams.get("to") || "";

  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [
      { invoiceNumber: { contains: q } },
      { customerName: { contains: q } },
      { customerPhone: { contains: q } },
    ];
  }
  if (status && status !== "ALL") where.paymentStatus = status;
  if (from || to) {
    where.saleDate = {
      ...(from ? { gte: new Date(`${from}T00:00:00`) } : {}),
      ...(to ? { lte: new Date(`${to}T23:59:59.999`) } : {}),
    };
  }

  const sales = await prisma.sale.findMany({
    where,
    include: {
      items: true,
      payments: true,
      customer: { select: { id: true, name: true, phone: true } },
      user: { select: { id: true, fullName: true, username: true } },
    },
    orderBy: { saleDate: "desc" },
    take: 200,
  });

  return NextResponse.json({ sales });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("pos", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    const {
      customerId,
      customerName,
      customerPhone,
      items,
      billDiscount = 0,
      gstType = "NONE",
      enableRoundOff = true,
      paymentMethod = "CASH",
      payments = [],
      paidAmount,
      advanceUsed = 0,
      notes,
    } = body;

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Cart cannot be empty" }, { status: 400 });
    }

    const sale = await prisma.$transaction(async (tx) => {
      const settings = await tx.setting.findUnique({ where: { id: "default" } });
      const allowNegative = settings?.allowNegativeStock ?? false;
      const prefix = settings?.invoicePrefix || "BB";
      const nextNum = settings?.nextInvoiceNumber ?? 1;
      const invoiceNumber = `${prefix}-${String(nextNum).padStart(2, "0")}`;

      // Increment invoice sequence atomically
      await tx.setting.upsert({
        where: { id: "default" },
        update: { nextInvoiceNumber: nextNum + 1 },
        create: { id: "default", nextInvoiceNumber: nextNum + 1 },
      });

      let subtotal = 0;
      let totalItemDiscount = 0;
      let totalGst = 0;

      const preparedItems: {
        productId: string | null;
        productName: string;
        productCode: string;
        hsnCode: string | null;
        unit: string;
        quantity: number;
        unitPrice: number;
        costPrice: number;
        discount: number;
        gstPercent: number;
        gstAmount: number;
        total: number;
        prevStock: number;
        newStock: number;
        minStockAlert: number;
      }[] = [];

      for (let idx = 0; idx < items.length; idx++) {
        const item = items[idx];
        const qty = Number(item.quantity);
        if (!qty || qty <= 0) throw new Error("Invalid item quantity");

        const prod = item.productId
          ? await tx.product.findUnique({ where: { id: item.productId } })
          : null;

        if (prod && !allowNegative && prod.currentStock < qty) {
          throw new Error(`Insufficient stock for "${prod.name}" (Available: ${prod.currentStock}, Requested: ${qty})`);
        }

        const unitPrice = Number(item.unitPrice ?? prod?.sellingPrice ?? 0);
        if (unitPrice < 0) throw new Error("Invalid item price");

        const lineDisc = Math.max(0, Number(item.discount || 0));
        const lineSub = unitPrice * qty;
        const taxable = Math.max(0, lineSub - lineDisc);
        const gstPct = gstType === "NONE" ? 0 : Number(item.gstPercent ?? prod?.gstPercent ?? 0);
        const gstAmt = Number(((taxable * gstPct) / 100).toFixed(2));
        const lineTotal = Number((taxable + gstAmt).toFixed(2));

        subtotal += lineSub;
        totalItemDiscount += lineDisc;
        totalGst += gstAmt;

        const codeLabel = String(item.productCode || prod?.code || idx + 1).trim();
        const nameLabel = String(item.productName || prod?.name || `Item #${codeLabel}`).trim();

        preparedItems.push({
          productId: prod ? prod.id : null,
          productName: nameLabel,
          productCode: codeLabel,
          hsnCode: prod?.hsnCode || null,
          unit: item.unit || prod?.unit || "Pcs",
          quantity: qty,
          unitPrice,
          costPrice: prod?.purchasePrice ?? 0,
          discount: lineDisc,
          gstPercent: gstPct,
          gstAmount: gstAmt,
          total: lineTotal,
          prevStock: prod?.currentStock ?? 0,
          newStock: prod ? prod.currentStock - qty : 0,
          minStockAlert: prod?.minStockAlert ?? 0,
        });
      }

      const billDiscNum = Math.max(0, Number(billDiscount || 0));
      const rawTotal = Math.max(0, subtotal - totalItemDiscount - billDiscNum + totalGst);
      const grandTotal = enableRoundOff ? Math.round(rawTotal) : Number(rawTotal.toFixed(2));
      const roundOff = Number((grandTotal - rawTotal).toFixed(2));

      // Compute payments
      const paymentRecords: { amount: number; method: string; referenceNo?: string; notes?: string }[] = [];
      if (Array.isArray(payments) && payments.length > 0) {
        for (const p of payments) {
          if (Number(p.amount) > 0) {
            paymentRecords.push({
              amount: Number(p.amount),
              method: p.method || "CASH",
              referenceNo: p.referenceNo || undefined,
              notes: p.notes || undefined,
            });
          }
        }
      } else {
        const amt = paidAmount !== undefined ? Number(paidAmount) : paymentMethod === "CREDIT" ? 0 : grandTotal;
        if (amt > 0) {
          paymentRecords.push({ amount: amt, method: paymentMethod === "CREDIT" ? "CASH" : paymentMethod });
        }
      }

      if (Number(advanceUsed) > 0) {
        paymentRecords.push({ amount: Number(advanceUsed), method: "ADVANCE", notes: "Customer advance adjusted" });
      }

      const totalPaid = Number(paymentRecords.reduce((s, p) => s + p.amount, 0).toFixed(2));
      const balanceDue = Math.max(0, Number((grandTotal - totalPaid).toFixed(2)));
      const paymentStatus = balanceDue <= 0 ? "PAID" : totalPaid > 0 ? "PARTIAL" : "DUE";

      const cgstAmount = gstType === "CGST_SGST" ? Number((totalGst / 2).toFixed(2)) : 0;
      const sgstAmount = gstType === "CGST_SGST" ? Number((totalGst / 2).toFixed(2)) : 0;
      const igstAmount = gstType === "IGST" ? Number(totalGst.toFixed(2)) : 0;

      const createdSale = await tx.sale.create({
        data: {
          invoiceNumber,
          customerId: customerId || null,
          customerName: customerName?.trim() || "Walk-in Customer",
          customerPhone: customerPhone?.trim() || null,
          userId: user.id,
          subtotal: Number(subtotal.toFixed(2)),
          itemDiscount: Number(totalItemDiscount.toFixed(2)),
          billDiscount: Number(billDiscNum.toFixed(2)),
          gstType,
          cgstAmount,
          sgstAmount,
          igstAmount,
          totalGst: Number(totalGst.toFixed(2)),
          roundOff,
          grandTotal,
          paidAmount: totalPaid,
          balanceDue,
          paymentStatus,
          paymentMethod: paymentRecords.length > 1 ? "SPLIT" : paymentMethod,
          notes: notes || null,
          items: {
            create: preparedItems.map((pi) => ({
              productId: pi.productId,
              productName: pi.productName,
              productCode: pi.productCode,
              hsnCode: pi.hsnCode,
              unit: pi.unit,
              quantity: pi.quantity,
              unitPrice: pi.unitPrice,
              costPrice: pi.costPrice,
              discount: pi.discount,
              gstPercent: pi.gstPercent,
              gstAmount: pi.gstAmount,
              total: pi.total,
            })),
          },
          payments: {
            create: paymentRecords,
          },
        },
        include: { items: true, payments: true },
      });

      // Deduct stock + log stock movements + generate low-stock notifications (for catalog products)
      for (const pi of preparedItems) {
        if (!pi.productId) continue;
        await tx.product.update({
          where: { id: pi.productId },
          data: { currentStock: pi.newStock },
        });
        await tx.stockMovement.create({
          data: {
            productId: pi.productId,
            type: "SALE",
            quantity: -pi.quantity,
            previousStock: pi.prevStock,
            newStock: pi.newStock,
            referenceId: createdSale.invoiceNumber,
            reason: `Sold via Invoice ${createdSale.invoiceNumber}`,
            userId: user.id,
          },
        });

        if (pi.newStock <= 0) {
          await tx.notification.create({
            data: {
              type: "OUT_OF_STOCK",
              title: `Out of Stock: ${pi.productName}`,
              message: `${pi.productCode} reached 0 stock after invoice ${invoiceNumber}.`,
              entityId: pi.productId,
            },
          });
        } else if (pi.newStock <= pi.minStockAlert) {
          await tx.notification.create({
            data: {
              type: "LOW_STOCK",
              title: `Low Stock: ${pi.productName}`,
              message: `${pi.productCode} has only ${pi.newStock} ${pi.unit} left (Min: ${pi.minStockAlert}).`,
              entityId: pi.productId,
            },
          });
        }
      }

      // Update Customer CRM, Loyalty Points & Ledger
      if (customerId) {
        const cust = await tx.customer.findUnique({ where: { id: customerId } });
        if (cust) {
          const earnedPoints =
            settings?.enableLoyaltyPoints && settings.loyaltyPointRate > 0
              ? Math.floor(grandTotal / settings.loyaltyPointRate)
              : 0;
          const newOutstanding = Number((cust.outstandingAmount + balanceDue).toFixed(2));
          const newAdvance = Math.max(0, Number((cust.advanceBalance - Number(advanceUsed || 0)).toFixed(2)));

          await tx.customer.update({
            where: { id: customerId },
            data: {
              totalPurchases: Number((cust.totalPurchases + grandTotal).toFixed(2)),
              outstandingAmount: newOutstanding,
              advanceBalance: newAdvance,
              loyaltyPoints: cust.loyaltyPoints + earnedPoints,
            },
          });

          await tx.customerLedger.create({
            data: {
              customerId,
              type: "SALE",
              amount: grandTotal,
              balance: newOutstanding,
              referenceNo: invoiceNumber,
              notes: `POS Invoice ${invoiceNumber} (Paid: ₹${totalPaid})`,
            },
          });
        }
      }

      // Update today's open cash register if present
      const todayStr = new Date().toISOString().slice(0, 10);
      const openReg = await tx.cashRegister.findFirst({ where: { date: todayStr, status: "OPEN" } });
      if (openReg) {
        let cashAdd = 0;
        let upiAdd = 0;
        let cardAdd = 0;
        for (const pr of paymentRecords) {
          if (pr.method === "CASH") cashAdd += pr.amount;
          else if (pr.method === "UPI") upiAdd += pr.amount;
          else if (pr.method === "CARD") cardAdd += pr.amount;
        }
        await tx.cashRegister.update({
          where: { id: openReg.id },
          data: {
            cashSales: openReg.cashSales + cashAdd,
            upiSales: openReg.upiSales + upiAdd,
            cardSales: openReg.cardSales + cardAdd,
            expectedCash: openReg.expectedCash + cashAdd,
          },
        });
      }

      return createdSale;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "SALE_CREATE",
      module: "pos",
      entityId: sale.id,
      details: `Created Invoice ${sale.invoiceNumber} for ${sale.customerName} — Total ₹${sale.grandTotal}`,
    });

    return NextResponse.json({ sale }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Billing failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
