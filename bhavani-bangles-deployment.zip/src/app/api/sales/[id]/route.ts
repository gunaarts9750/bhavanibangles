import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error } = await requireAuth("invoices", "canView");
  if (error) return error;

  const { id } = await params;
  const sale = await prisma.sale.findUnique({
    where: { id },
    include: {
      items: true,
      payments: true,
      customer: true,
      user: { select: { fullName: true, username: true } },
    },
  });
  if (!sale) return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
  return NextResponse.json({ sale });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("invoices", "canView");
  if (error) return error;

  const { id } = await params;
  const body = await req.json();

  try {
    // Action 1: Record Due Payment on an Invoice
    if (body.action === "ADD_PAYMENT") {
      const amount = Number(body.amount);
      if (!amount || amount <= 0) {
        return NextResponse.json({ error: "Valid payment amount required" }, { status: 400 });
      }

      const updated = await prisma.$transaction(async (tx) => {
        const sale = await tx.sale.findUnique({ where: { id } });
        if (!sale || sale.isCancelled) throw new Error("Invoice not found or cancelled");
        if (amount > sale.balanceDue + 0.01) throw new Error("Payment exceeds balance due");

        await tx.payment.create({
          data: {
            saleId: sale.id,
            amount,
            method: body.method || "CASH",
            referenceNo: body.referenceNo || null,
            notes: body.notes || "Due payment received",
          },
        });

        const newPaid = Number((sale.paidAmount + amount).toFixed(2));
        const newDue = Math.max(0, Number((sale.grandTotal - newPaid).toFixed(2)));
        const newStatus = newDue <= 0 ? "PAID" : "PARTIAL";

        const s = await tx.sale.update({
          where: { id },
          data: { paidAmount: newPaid, balanceDue: newDue, paymentStatus: newStatus },
          include: { items: true, payments: true },
        });

        if (sale.customerId) {
          const cust = await tx.customer.findUnique({ where: { id: sale.customerId } });
          if (cust) {
            const nextBal = Math.max(0, Number((cust.outstandingAmount - amount).toFixed(2)));
            await tx.customer.update({
              where: { id: sale.customerId },
              data: { outstandingAmount: nextBal },
            });
            await tx.customerLedger.create({
              data: {
                customerId: sale.customerId,
                type: "PAYMENT",
                amount: -amount,
                balance: nextBal,
                referenceNo: sale.invoiceNumber,
                notes: `Due payment via ${body.method || "CASH"}`,
              },
            });
          }
        }
        return s;
      });

      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "INVOICE_PAYMENT",
        module: "invoices",
        entityId: id,
        details: `Recorded payment of ₹${amount} on ${updated.invoiceNumber}`,
      });

      return NextResponse.json({ sale: updated });
    }

    // Action 2: Cancel Invoice (Owner approval only!)
    if (body.action === "CANCEL") {
      if (user.roleName !== "SUPER_ADMIN") {
        return NextResponse.json({ error: "Only the Store Owner can cancel an invoice" }, { status: 403 });
      }
      const reason = body.reason?.trim() || "Cancelled by Owner";

      const cancelled = await prisma.$transaction(async (tx) => {
        const sale = await tx.sale.findUnique({ where: { id }, include: { items: true } });
        if (!sale) throw new Error("Invoice not found");
        if (sale.isCancelled) throw new Error("Invoice is already cancelled");

        // Restore stock for catalog items
        for (const it of sale.items) {
          if (!it.productId) continue;
          const prod = await tx.product.findUnique({ where: { id: it.productId } });
          if (prod) {
            const newStock = prod.currentStock + it.quantity;
            await tx.product.update({ where: { id: prod.id }, data: { currentStock: newStock } });
            await tx.stockMovement.create({
              data: {
                productId: prod.id,
                type: "SALE_CANCEL",
                quantity: it.quantity,
                previousStock: prod.currentStock,
                newStock,
                referenceId: sale.invoiceNumber,
                reason: `Invoice cancelled: ${reason}`,
                userId: user.id,
              },
            });
          }
        }

        if (sale.customerId && sale.balanceDue > 0) {
          const cust = await tx.customer.findUnique({ where: { id: sale.customerId } });
          if (cust) {
            await tx.customer.update({
              where: { id: cust.id },
              data: {
                outstandingAmount: Math.max(0, cust.outstandingAmount - sale.balanceDue),
                totalPurchases: Math.max(0, cust.totalPurchases - sale.grandTotal),
              },
            });
          }
        }

        return tx.sale.update({
          where: { id },
          data: { isCancelled: true, paymentStatus: "CANCELLED", cancelReason: reason },
        });
      });

      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "SALE_CANCEL",
        module: "invoices",
        entityId: id,
        details: `Cancelled invoice ${cancelled.invoiceNumber}. Reason: ${reason}`,
      });

      return NextResponse.json({ sale: cancelled });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Action failed" }, { status: 400 });
  }
}
