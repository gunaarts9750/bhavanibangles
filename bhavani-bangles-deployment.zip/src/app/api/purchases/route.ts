import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth("purchases", "canView");
  if (error) return error;

  const purchases = await prisma.purchase.findMany({
    include: {
      supplier: true,
      items: { include: { product: { select: { name: true, code: true, unit: true } } } },
      user: { select: { fullName: true } },
    },
    orderBy: { purchaseDate: "desc" },
    take: 150,
  });
  return NextResponse.json({ purchases });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("purchases", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    const { supplierId, supplierInvoice, purchaseDate, items, paidAmount = 0, paymentMethod = "BANK_TRANSFER", notes } = body;

    if (!supplierId || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Supplier and at least one product are required" }, { status: 400 });
    }

    const purchase = await prisma.$transaction(async (tx) => {
      const count = await tx.purchase.count();
      const purchaseNumber = `PUR-${new Date().getFullYear()}-${String(count + 1).padStart(3, "0")}`;

      let subtotal = 0;
      let gstAmount = 0;
      const prepared = [];

      for (const it of items) {
        const qty = Number(it.quantity);
        const price = Number(it.purchasePrice);
        const gstPct = Number(it.gstPercent ?? 3);
        if (!qty || qty <= 0) throw new Error("Invalid quantity");
        const base = qty * price;
        const gst = Number(((base * gstPct) / 100).toFixed(2));
        subtotal += base;
        gstAmount += gst;
        prepared.push({
          productId: it.productId,
          quantity: qty,
          purchasePrice: price,
          gstPercent: gstPct,
          gstAmount: gst,
          total: Number((base + gst).toFixed(2)),
        });
      }

      const totalAmount = Number((subtotal + gstAmount).toFixed(2));
      const paid = Math.min(totalAmount, Math.max(0, Number(paidAmount || 0)));
      const pendingAmount = Number((totalAmount - paid).toFixed(2));
      const paymentStatus = pendingAmount <= 0 ? "PAID" : paid > 0 ? "PARTIAL" : "PENDING";

      const created = await tx.purchase.create({
        data: {
          purchaseNumber,
          supplierInvoice: supplierInvoice || null,
          supplierId,
          purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date(),
          subtotal: Number(subtotal.toFixed(2)),
          gstAmount: Number(gstAmount.toFixed(2)),
          totalAmount,
          paidAmount: paid,
          pendingAmount,
          paymentStatus,
          paymentMethod,
          notes: notes || null,
          userId: user.id,
          items: { create: prepared },
        },
        include: { supplier: true, items: true },
      });

      // Automatically increase stock & update purchase price
      for (const pi of prepared) {
        const prod = await tx.product.findUnique({ where: { id: pi.productId } });
        if (prod) {
          const newStock = prod.currentStock + pi.quantity;
          await tx.product.update({
            where: { id: prod.id },
            data: { currentStock: newStock, purchasePrice: pi.purchasePrice },
          });
          await tx.stockMovement.create({
            data: {
              productId: prod.id,
              type: "PURCHASE",
              quantity: pi.quantity,
              previousStock: prod.currentStock,
              newStock,
              referenceId: purchaseNumber,
              reason: `Stock received from ${created.supplier.name} (${purchaseNumber})`,
              userId: user.id,
            },
          });
        }
      }

      // Update supplier pending balance & ledger
      const sup = await tx.supplier.findUnique({ where: { id: supplierId } });
      if (sup) {
        const nextBal = Number((sup.pendingBalance + pendingAmount).toFixed(2));
        await tx.supplier.update({ where: { id: supplierId }, data: { pendingBalance: nextBal } });
        await tx.supplierLedger.create({
          data: {
            supplierId,
            type: "PURCHASE",
            amount: totalAmount,
            balance: nextBal,
            referenceNo: purchaseNumber,
            notes: `Purchase ${purchaseNumber} (Paid: ₹${paid})`,
          },
        });
      }

      return created;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PURCHASE_CREATE",
      module: "purchases",
      entityId: purchase.id,
      details: `Recorded purchase ${purchase.purchaseNumber} from ${purchase.supplier.name} — ₹${purchase.totalAmount}`,
    });

    return NextResponse.json({ purchase }, { status: 201 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Purchase failed" }, { status: 400 });
  }
}
