import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("staff", "canView");
  if (error) return error;

  const date = req.nextUrl.searchParams.get("date") || new Date().toISOString().slice(0, 10);
  const month = req.nextUrl.searchParams.get("month"); // YYYY-MM

  const attendances = await prisma.attendance.findMany({
    where: month ? { date: { startsWith: month } } : { date },
    include: { staff: { select: { id: true, name: true, staffCode: true, designation: true } } },
    orderBy: { date: "desc" },
  });

  return NextResponse.json({ attendances });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("staff", "canEdit");
  if (error) return error;

  try {
    const { staffId, date, status, action, notes } = await req.json();
    const targetDate = date || new Date().toISOString().slice(0, 10);
    if (!staffId) return NextResponse.json({ error: "Staff ID required" }, { status: 400 });

    const existing = await prisma.attendance.findUnique({
      where: { staffId_date: { staffId, date: targetDate } },
    });

    let record;
    if (action === "CHECK_IN") {
      record = await prisma.attendance.upsert({
        where: { staffId_date: { staffId, date: targetDate } },
        update: { status: "PRESENT", checkIn: new Date(), notes: notes || undefined },
        create: { staffId, date: targetDate, status: "PRESENT", checkIn: new Date(), notes: notes || null },
      });
    } else if (action === "CHECK_OUT") {
      if (!existing) {
        return NextResponse.json({ error: "No check-in found for today" }, { status: 400 });
      }
      record = await prisma.attendance.update({
        where: { id: existing.id },
        data: { checkOut: new Date(), notes: notes || existing.notes },
      });
    } else {
      record = await prisma.attendance.upsert({
        where: { staffId_date: { staffId, date: targetDate } },
        update: { status: status || "PRESENT", notes: notes || undefined },
        create: { staffId, date: targetDate, status: status || "PRESENT", notes: notes || null },
      });
    }

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "ATTENDANCE_UPDATE",
      module: "staff",
      entityId: staffId,
      details: `Updated attendance on ${targetDate}: ${action || status}`,
    });

    return NextResponse.json({ attendance: record });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Attendance update failed" }, { status: 400 });
  }
}
