import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth("settings", "canView");
  if (error) return error;

  const roles = await prisma.role.findMany({
    include: { permissions: { orderBy: { module: "asc" } }, _count: { select: { users: true } } },
    orderBy: { name: "asc" },
  });
  return NextResponse.json({ roles });
}

export async function PUT(req: NextRequest) {
  const { user, error } = await requireAuth("settings", "canEdit");
  if (error) return error;

  if (user.roleName !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Only Super Admin can modify role permissions" }, { status: 403 });
  }

  try {
    const { permissionId, canView, canCreate, canEdit, canDelete } = await req.json();
    const updated = await prisma.permission.update({
      where: { id: permissionId },
      data: { canView, canCreate, canEdit, canDelete },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PERMISSION_UPDATE",
      module: "settings",
      entityId: permissionId,
      details: `Updated permissions on module ${updated.module}`,
    });

    return NextResponse.json({ permission: updated });
  } catch {
    return NextResponse.json({ error: "Failed to update permission" }, { status: 400 });
  }
}
