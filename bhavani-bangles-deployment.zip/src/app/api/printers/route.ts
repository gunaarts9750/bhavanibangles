import { NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";
import os from "os";
import { requireAuth } from "@/lib/auth";

const execAsync = promisify(exec);

const VIRTUAL_PRINTER_PATTERNS = [
  /microsoft print to pdf/i,
  /microsoft xps/i,
  /onenote/i,
  /^fax$/i,
  /adobe pdf/i,
];

function isVirtualPrinter(name: string): boolean {
  return VIRTUAL_PRINTER_PATTERNS.some((re) => re.test(name.trim()));
}

let cachedPrinters: { name: string; isDefault: boolean; isOnline: boolean; isPhysical: boolean }[] | null = null;
let cachedAt = 0;
const PRINTER_CACHE_TTL_MS = 5 * 60 * 1000;

async function listWindowsPrinters(forceRefresh = false): Promise<{ name: string; isDefault: boolean; isOnline: boolean; isPhysical: boolean }[]> {
  if (process.platform !== "win32") return [];
  if (!forceRefresh && cachedPrinters && Date.now() - cachedAt < PRINTER_CACHE_TTL_MS) {
    return cachedPrinters;
  }
  const { stdout } = await execAsync(
    'powershell -NoProfile -Command "Get-CimInstance Win32_Printer | Select-Object Name, Default, PrinterStatus, WorkOffline | ConvertTo-Json"',
    { timeout: 4000 }
  );
  const raw = stdout.trim();
  if (!raw) {
    cachedPrinters = [];
    cachedAt = Date.now();
    return [];
  }
  const parsed = JSON.parse(raw);
  cachedPrinters = (Array.isArray(parsed) ? parsed : [parsed]).map(
    (p: { Name: string; Default?: boolean; WorkOffline?: boolean }) => ({
      name: p.Name,
      isDefault: Boolean(p.Default),
      isOnline: !p.WorkOffline,
      isPhysical: !isVirtualPrinter(p.Name),
    })
  );
  cachedAt = Date.now();
  return cachedPrinters;
}

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  try {
    const list = await listWindowsPrinters();
    const physicalPrinters = list.filter((p) => p.isPhysical);
    const defaultPrinter =
      physicalPrinters.find((p) => p.isDefault)?.name ||
      physicalPrinters[0]?.name ||
      null;
    return NextResponse.json({ printers: list, defaultPrinter });
  } catch {
    return NextResponse.json({ printers: [], defaultPrinter: null });
  }
}

interface PrintItem {
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface PrintPayload {
  printerName?: string | null;
  paperWidthMm?: number;
  shop?: {
    shopName?: string;
    address?: string;
    phone?: string;
    gstin?: string;
    thankYouMessage?: string;
  };
  invoice: {
    invoiceNumber: string;
    saleDate: string;
    subtotal: number;
    totalGst?: number;
    grandTotal: number;
    paidAmount: number;
    paymentMethod: string;
    items: PrintItem[];
  };
}

function formatReceiptText(payload: PrintPayload): string {
  const mm = Number(payload.paperWidthMm) || 58;
  const width = mm <= 60 ? 32 : mm <= 76 ? 40 : 42;
  const line = "-".repeat(width);
  const center = (s: string) => {
    const t = s.trim().slice(0, width);
    const pad = Math.max(0, Math.floor((width - t.length) / 2));
    return " ".repeat(pad) + t;
  };
  const row = (left: string, right: string) => {
    const maxL = Math.max(1, width - right.length - 1);
    const l = left.slice(0, maxL);
    const spaces = Math.max(1, width - l.length - right.length);
    return l + " ".repeat(spaces) + right;
  };

  const shop = payload.shop || {};
  const inv = payload.invoice;
  const out: string[] = [];

  out.push(center(shop.shopName || "BHAVANI BANGLES"));
  if (shop.address) out.push(center(shop.address));
  if (shop.phone) out.push(center(`Ph: ${shop.phone}`));
  if (shop.gstin) out.push(center(`GSTIN: ${shop.gstin}`));
  out.push(line);
  out.push(row(`Inv: ${inv.invoiceNumber}`, new Date(inv.saleDate).toLocaleDateString("en-IN")));
  out.push(line);

  for (const it of inv.items) {
    out.push(it.productName.slice(0, width));
    out.push(row(`  ${it.quantity} x ${Number(it.unitPrice).toFixed(2)}`, `Rs.${Number(it.total).toFixed(2)}`));
  }

  out.push(line);
  out.push(row("Subtotal", `Rs.${Number(inv.subtotal).toFixed(2)}`));
  if (inv.totalGst && inv.totalGst > 0) {
    out.push(row("GST", `Rs.${Number(inv.totalGst).toFixed(2)}`));
  }
  out.push(line);
  out.push(row("GRAND TOTAL", `Rs.${Number(inv.grandTotal).toFixed(2)}`));
  out.push(row(`Paid (${inv.paymentMethod})`, `Rs.${Number(inv.paidAmount).toFixed(2)}`));
  out.push(line);
  if (shop.thankYouMessage) {
    out.push(center(shop.thankYouMessage));
  }
  out.push("", "", "");
  return out.join("\r\n");
}

export async function POST(req: Request) {
  const { error } = await requireAuth();
  if (error) return error;

  try {
    const body = (await req.json()) as PrintPayload;
    if (!body?.invoice) {
      return NextResponse.json({ ok: false, error: "Missing invoice data" }, { status: 400 });
    }

    if (process.platform !== "win32") {
      return NextResponse.json({ ok: true, printed: false, reason: "Direct silent printing requires Windows" });
    }

    const list = await listWindowsPrinters();
    const physicalPrinters = list.filter((p) => p.isPhysical && p.isOnline);
    const targetPrinter =
      (body.printerName && !isVirtualPrinter(body.printerName) ? body.printerName : null) ||
      physicalPrinters.find((p) => p.isDefault)?.name ||
      physicalPrinters[0]?.name ||
      null;

    if (!targetPrinter) {
      return NextResponse.json({
        ok: true,
        printed: false,
        reason: "No physical printer connected",
      });
    }

    const receiptText = formatReceiptText(body);
    const tmpFile = path.join(os.tmpdir(), `bb-receipt-${Date.now()}.txt`);
    await fs.writeFile(tmpFile, receiptText, "utf8");

    try {
      const safeFile = tmpFile.replace(/'/g, "''");
      const safePrinter = targetPrinter.replace(/'/g, "''");
      await execAsync(
        `powershell -NoProfile -Command "Get-Content -Raw -Path '${safeFile}' | Out-Printer -Name '${safePrinter}'"`,
        { timeout: 6000 }
      );
      return NextResponse.json({ ok: true, printed: true, printer: targetPrinter });
    } finally {
      await fs.unlink(tmpFile).catch(() => {});
    }
  } catch (err) {
    console.error("Silent print error:", err);
    return NextResponse.json({ ok: false, printed: false, error: "Direct print failed" }, { status: 500 });
  }
}
