import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth("quotations", "canView");
  if (error) return error;

  const quotations = await prisma.quotation.findMany({
    include: { items: true, customer: true, user: { select: { fullName: true } } },
    orderBy: { quotationDate: "desc" },
    take: 100,
  });
  return NextResponse.json({ quotations });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("quotations", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    const { customerId, customerName, customerPhone, validUntil, items, discount = 0, gstType = "CGST_SGST", notes } = body;

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Add at least one product to quotation" }, { status: 400 });
    }

    const quotation = await prisma.$transaction(async (tx) => {
      const settings = await tx.setting.findUnique({ where: { id: "default" } });
      const prefix = settings?.quotationPrefix || "QT";
      const nextNum = settings?.nextQuotationNumber || 501;
      const quotationNumber = `${prefix}-${nextNum}`;

      await tx.setting.upsert({
        where: { id: "default" },
        update: { nextQuotationNumber: nextNum + 1 },
        create: { id: "default", nextQuotationNumber: nextNum + 1 },
      });

      let subtotal = 0;
      let totalGst = 0;
      const prepared = [];

      for (const it of items) {
        const prod = await tx.product.findUnique({ where: { id: it.productId } });
        if (!prod) throw new Error("Product not found");
        const qty = Number(it.quantity);
        const price = Number(it.unitPrice ?? prod.sellingPrice);
        const lineDisc = Number(it.discount || 0);
        const lineSub = qty * price;
        const taxable = Math.max(0, lineSub - lineDisc);
        const gstPct = gstType === "NONE" ? 0 : Number(it.gstPercent ?? prod.gstPercent);
        const gstAmt = Number(((taxable * gstPct) / 100).toFixed(2));
        subtotal += lineSub;
        totalGst += gstAmt;
        prepared.push({
          productId: prod.id,
          productName: prod.name,
          productCode: prod.code,
          unit: prod.unit,
          quantity: qty,
          unitPrice: price,
          discount: lineDisc,
          gstPercent: gstPct,
          gstAmount: gstAmt,
          total: Number((taxable + gstAmt).toFixed(2)),
        });
      }

      const grandTotal = Math.round(Math.max(0, subtotal - Number(discount || 0) + totalGst));

      return tx.quotation.create({
        data: {
          quotationNumber,
          customerId: customerId || null,
          customerName: customerName?.trim() || "Walk-in Customer",
          customerPhone: customerPhone || null,
          validUntil: validUntil ? new Date(validUntil) : new Date(Date.now() + 7 * 86400000),
          subtotal: Number(subtotal.toFixed(2)),
          discount: Number(discount || 0),
          gstType,
          totalGst: Number(totalGst.toFixed(2)),
          grandTotal,
          status: "APPROVED",
          notes: notes || null,
          userId: user.id,
          items: { create: prepared },
        },
        include: { items: true },
      });
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "QUOTATION_CREATE",
      module: "quotations",
      entityId: quotation.id,
      details: `Created Quotation ${quotation.quotationNumber} — ₹${quotation.grandTotal} (no stock deducted)`,
    });

    return NextResponse.json({ quotation }, { status: 201 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Quotation failed" }, { status: 400 });
  }
}
