import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("pos", "canCreate");
  if (error) return error;

  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const paymentMethod = body.paymentMethod || "CASH";

  try {
    const sale = await prisma.$transaction(async (tx) => {
      const quote = await tx.quotation.findUnique({ where: { id }, include: { items: true } });
      if (!quote) throw new Error("Quotation not found");
      if (quote.status === "CONVERTED") throw new Error("Quotation already converted to invoice");

      const settings = await tx.setting.findUnique({ where: { id: "default" } });
      const allowNegative = settings?.allowNegativeStock ?? false;
      const prefix = settings?.invoicePrefix || "BB";
      const nextNum = settings?.nextInvoiceNumber || 1001;
      const invoiceNumber = `${prefix}-${nextNum}`;

      await tx.setting.upsert({
        where: { id: "default" },
        update: { nextInvoiceNumber: nextNum + 1 },
        create: { id: "default", nextInvoiceNumber: nextNum + 1 },
      });

      const saleItems = [];
      for (const qi of quote.items) {
        const prod = await tx.product.findUnique({ where: { id: qi.productId } });
        if (!prod) throw new Error(`Product ${qi.productName} no longer exists`);
        if (!allowNegative && prod.currentStock < qi.quantity) {
          throw new Error(`Insufficient stock for ${prod.name} (Available: ${prod.currentStock})`);
        }
        const newStock = prod.currentStock - qi.quantity;
        await tx.product.update({ where: { id: prod.id }, data: { currentStock: newStock } });
        await tx.stockMovement.create({
          data: {
            productId: prod.id,
            type: "SALE",
            quantity: -qi.quantity,
            previousStock: prod.currentStock,
            newStock,
            referenceId: invoiceNumber,
            reason: `Converted from Quotation ${quote.quotationNumber}`,
            userId: user.id,
          },
        });
        saleItems.push({
          productId: prod.id,
          productName: qi.productName,
          productCode: qi.productCode,
          hsnCode: prod.hsnCode,
          unit: qi.unit,
          quantity: qi.quantity,
          unitPrice: qi.unitPrice,
          costPrice: prod.purchasePrice,
          discount: qi.discount,
          gstPercent: qi.gstPercent,
          gstAmount: qi.gstAmount,
          total: qi.total,
        });
      }

      const createdSale = await tx.sale.create({
        data: {
          invoiceNumber,
          customerId: quote.customerId,
          customerName: quote.customerName,
          customerPhone: quote.customerPhone,
          userId: user.id,
          subtotal: quote.subtotal,
          billDiscount: quote.discount,
          gstType: quote.gstType,
          cgstAmount: quote.gstType === "CGST_SGST" ? Number((quote.totalGst / 2).toFixed(2)) : 0,
          sgstAmount: quote.gstType === "CGST_SGST" ? Number((quote.totalGst / 2).toFixed(2)) : 0,
          igstAmount: quote.gstType === "IGST" ? quote.totalGst : 0,
          totalGst: quote.totalGst,
          grandTotal: quote.grandTotal,
          paidAmount: quote.grandTotal,
          balanceDue: 0,
          paymentStatus: "PAID",
          paymentMethod,
          notes: `Converted from Quotation ${quote.quotationNumber}`,
          items: { create: saleItems },
          payments: { create: [{ amount: quote.grandTotal, method: paymentMethod, notes: `From ${quote.quotationNumber}` }] },
        },
        include: { items: true, payments: true },
      });

      await tx.quotation.update({
        where: { id },
        data: { status: "CONVERTED", convertedSaleId: createdSale.id },
      });

      return createdSale;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "QUOTATION_CONVERT",
      module: "quotations",
      entityId: sale.id,
      details: `Converted quotation into Invoice ${sale.invoiceNumber} — ₹${sale.grandTotal}`,
    });

    return NextResponse.json({ sale }, { status: 201 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Conversion failed" }, { status: 400 });
  }
}
