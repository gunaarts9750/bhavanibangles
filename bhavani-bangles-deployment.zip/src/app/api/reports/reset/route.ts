import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function POST() {
  const { user, error } = await requireAuth("reports", "canView");
  if (error) return error;

  try {
    await prisma.$transaction(async (tx) => {
      await tx.returnRecord.deleteMany({});
      await tx.payment.deleteMany({});
      await tx.saleItem.deleteMany({});
      await tx.sale.deleteMany({});
      await tx.setting.upsert({
        where: { id: "default" },
        update: { nextInvoiceNumber: 1 },
        create: { id: "default", nextInvoiceNumber: 1 },
      });
    });

    await createAuditLog({
      userId: user.id,
      action: "RESET_BILLS",
      module: "reports",
      details: "Reset all sales/bills to 0 and restarted invoice numbering from 01",
    });

    return NextResponse.json({
      ok: true,
      nextInvoiceNumber: 1,
      message: "All bills reset to 0. Next bill will start from 01.",
    });
  } catch (err) {
    console.error("Reset reports error:", err);
    return NextResponse.json({ error: "Failed to reset bills and reports" }, { status: 500 });
  }
}
