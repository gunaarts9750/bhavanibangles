import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("reports", "canView");
  if (error) return error;

  const type = req.nextUrl.searchParams.get("type") || "sales";
  const from = req.nextUrl.searchParams.get("from");
  const to = req.nextUrl.searchParams.get("to");

  const dateFilter =
    from || to
      ? {
          ...(from ? { gte: new Date(`${from}T00:00:00`) } : {}),
          ...(to ? { lte: new Date(`${to}T23:59:59.999`) } : {}),
        }
      : undefined;

  try {
    if (type === "sales") {
      const sales = await prisma.sale.findMany({
        where: { isCancelled: false, ...(dateFilter ? { saleDate: dateFilter } : {}) },
        include: { items: true, user: { select: { fullName: true } } },
        orderBy: { saleDate: "desc" },
      });
      return NextResponse.json({
        summary: {
          totalBills: sales.length,
          totalRevenue: sales.reduce((s, x) => s + x.grandTotal, 0),
          totalGst: sales.reduce((s, x) => s + x.totalGst, 0),
          totalPaid: sales.reduce((s, x) => s + x.paidAmount, 0),
          totalDue: sales.reduce((s, x) => s + x.balanceDue, 0),
        },
        rows: sales.map((s) => ({
          invoiceNumber: s.invoiceNumber,
          date: s.saleDate,
          customer: s.customerName,
          items: s.items.reduce((acc, i) => acc + i.quantity, 0),
          subtotal: s.subtotal,
          gst: s.totalGst,
          grandTotal: s.grandTotal,
          paid: s.paidAmount,
          due: s.balanceDue,
          method: s.paymentMethod,
          status: s.paymentStatus,
          staff: s.user?.fullName || "-",
        })),
      });
    }

    if (type === "products" || type === "categories") {
      const items = await prisma.saleItem.findMany({
        where: {
          sale: { isCancelled: false, ...(dateFilter ? { saleDate: dateFilter } : {}) },
        },
        include: { product: { include: { category: true } } },
      });

      if (type === "products") {
        const map = new Map<string, { code: string; name: string; category: string; qty: number; revenue: number; cost: number; profit: number }>();
        for (const it of items) {
          const key = it.productId || `direct-${it.productCode}`;
          const cur = map.get(key) || {
            code: it.productCode,
            name: it.productName,
            category: it.product?.category?.name || "Direct Billing",
            qty: 0,
            revenue: 0,
            cost: 0,
            profit: 0,
          };
          cur.qty += it.quantity;
          cur.revenue += it.total;
          cur.cost += it.costPrice * it.quantity;
          cur.profit = Number((cur.revenue - cur.cost).toFixed(2));
          map.set(key, cur);
        }
        const rows = Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
        return NextResponse.json({ rows });
      } else {
        const map = new Map<string, { category: string; qty: number; revenue: number; cost: number; profit: number }>();
        for (const it of items) {
          const cat = it.product?.category?.name || "Other";
          const cur = map.get(cat) || { category: cat, qty: 0, revenue: 0, cost: 0, profit: 0 };
          cur.qty += it.quantity;
          cur.revenue += it.total;
          cur.cost += it.costPrice * it.quantity;
          cur.profit = Number((cur.revenue - cur.cost).toFixed(2));
          map.set(cat, cur);
        }
        return NextResponse.json({ rows: Array.from(map.values()).sort((a, b) => b.revenue - a.revenue) });
      }
    }

    if (type === "pnl") {
      const [sales, expenses, purchases, returns] = await Promise.all([
        prisma.sale.findMany({
          where: { isCancelled: false, ...(dateFilter ? { saleDate: dateFilter } : {}) },
          include: { items: true },
        }),
        prisma.expense.findMany({ where: dateFilter ? { expenseDate: dateFilter } : {} }),
        prisma.purchase.findMany({ where: dateFilter ? { purchaseDate: dateFilter } : {} }),
        prisma.returnRecord.findMany({ where: dateFilter ? { returnDate: dateFilter } : {} }),
      ]);

      const grossSales = sales.reduce((s, x) => s + x.grandTotal, 0);
      const gstCollected = sales.reduce((s, x) => s + x.totalGst, 0);
      const netSales = grossSales - gstCollected;
      const cogs = sales.reduce((s, x) => s + x.items.reduce((a, i) => a + i.costPrice * i.quantity, 0), 0);
      const totalReturns = returns.reduce((s, r) => s + r.refundAmount, 0);
      const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
      const totalPurchases = purchases.reduce((s, p) => s + p.totalAmount, 0);
      const grossProfit = netSales - cogs - totalReturns;
      const netProfit = grossProfit - totalExpenses;

      return NextResponse.json({
        pnl: { grossSales, gstCollected, netSales, cogs, totalReturns, grossProfit, totalExpenses, totalPurchases, netProfit },
        rows: [
          { metric: "Gross Sales (Incl. GST)", amount: grossSales },
          { metric: "GST Collected", amount: gstCollected },
          { metric: "Net Sales (Excl. GST)", amount: netSales },
          { metric: "Cost of Goods Sold (COGS)", amount: cogs },
          { metric: "Sales Returns / Refunds", amount: totalReturns },
          { metric: "Gross Profit", amount: grossProfit },
          { metric: "Operating Expenses", amount: totalExpenses },
          { metric: "Estimated Net Profit", amount: netProfit },
        ],
      });
    }

    if (type === "gst") {
      const items = await prisma.saleItem.findMany({
        where: { sale: { isCancelled: false, ...(dateFilter ? { saleDate: dateFilter } : {}) } },
        include: { sale: { select: { gstType: true } } },
      });
      const map = new Map<string, { hsn: string; gstRate: number; taxableValue: number; cgst: number; sgst: number; igst: number; totalGst: number }>();
      for (const it of items) {
        const key = `${it.hsnCode || "7117"}-${it.gstPercent}`;
        const cur = map.get(key) || { hsn: it.hsnCode || "7117", gstRate: it.gstPercent, taxableValue: 0, cgst: 0, sgst: 0, igst: 0, totalGst: 0 };
        const taxable = it.total - it.gstAmount;
        cur.taxableValue += taxable;
        if (it.sale.gstType === "IGST") cur.igst += it.gstAmount;
        else {
          cur.cgst += it.gstAmount / 2;
          cur.sgst += it.gstAmount / 2;
        }
        cur.totalGst += it.gstAmount;
        map.set(key, cur);
      }
      return NextResponse.json({ rows: Array.from(map.values()) });
    }

    if (type === "stock" || type === "low_stock") {
      const products = await prisma.product.findMany({
        where: { isActive: true },
        include: { category: true, supplier: true },
        orderBy: { currentStock: "asc" },
      });
      const filtered = type === "low_stock" ? products.filter((p) => p.currentStock <= p.minStockAlert) : products;
      return NextResponse.json({
        rows: filtered.map((p) => ({
          code: p.code,
          name: p.name,
          category: p.category.name,
          rack: p.rackNumber || "-",
          stock: p.currentStock,
          minAlert: p.minStockAlert,
          unit: p.unit,
          purchasePrice: p.purchasePrice,
          sellingPrice: p.sellingPrice,
          stockValue: p.currentStock * p.purchasePrice,
        })),
      });
    }

    if (type === "purchases") {
      const purchases = await prisma.purchase.findMany({
        where: dateFilter ? { purchaseDate: dateFilter } : {},
        include: { supplier: true },
        orderBy: { purchaseDate: "desc" },
      });
      return NextResponse.json({
        rows: purchases.map((p) => ({
          purchaseNumber: p.purchaseNumber,
          date: p.purchaseDate,
          supplier: p.supplier.name,
          invoice: p.supplierInvoice || "-",
          subtotal: p.subtotal,
          gst: p.gstAmount,
          total: p.totalAmount,
          paid: p.paidAmount,
          pending: p.pendingAmount,
          status: p.paymentStatus,
        })),
      });
    }

    if (type === "customers" || type === "outstanding") {
      const customers = await prisma.customer.findMany({
        where: type === "outstanding" ? { outstandingAmount: { gt: 0 } } : {},
        orderBy: { totalPurchases: "desc" },
      });
      return NextResponse.json({
        rows: customers.map((c) => ({
          name: c.name,
          phone: c.phone,
          type: c.customerType,
          totalPurchases: c.totalPurchases,
          outstanding: c.outstandingAmount,
          advance: c.advanceBalance,
          loyaltyPoints: c.loyaltyPoints,
        })),
      });
    }

    if (type === "suppliers") {
      const suppliers = await prisma.supplier.findMany({ include: { _count: { select: { purchases: true } } } });
      return NextResponse.json({
        rows: suppliers.map((s) => ({
          name: s.name,
          contact: s.contactPerson || "-",
          phone: s.phone,
          gstin: s.gstin || "-",
          purchases: s._count.purchases,
          pendingBalance: s.pendingBalance,
        })),
      });
    }

    if (type === "payments") {
      const payments = await prisma.payment.findMany({
        where: dateFilter ? { paymentDate: dateFilter } : {},
        include: { sale: { select: { invoiceNumber: true, customerName: true } } },
        orderBy: { paymentDate: "desc" },
      });
      return NextResponse.json({
        rows: payments.map((p) => ({
          date: p.paymentDate,
          invoice: p.sale?.invoiceNumber || "Direct",
          customer: p.sale?.customerName || p.notes || "-",
          method: p.method,
          amount: p.amount,
          reference: p.referenceNo || "-",
        })),
      });
    }

    if (type === "expenses") {
      const expenses = await prisma.expense.findMany({
        where: dateFilter ? { expenseDate: dateFilter } : {},
        orderBy: { expenseDate: "desc" },
      });
      return NextResponse.json({
        rows: expenses.map((e) => ({
          date: e.expenseDate,
          category: e.category,
          mode: e.paymentMode,
          amount: e.amount,
          description: e.description || "-",
        })),
      });
    }

    if (type === "returns") {
      const returns = await prisma.returnRecord.findMany({
        where: dateFilter ? { returnDate: dateFilter } : {},
        include: { sale: { select: { invoiceNumber: true, customerName: true } } },
        orderBy: { returnDate: "desc" },
      });
      return NextResponse.json({
        rows: returns.map((r) => ({
          returnNumber: r.returnNumber,
          date: r.returnDate,
          invoice: r.sale.invoiceNumber,
          customer: r.sale.customerName,
          reason: r.reason,
          refund: r.refundAmount,
          exchangeDiff: r.exchangeDiff,
          method: r.refundMethod,
        })),
      });
    }

    if (type === "staff") {
      const sales = await prisma.sale.findMany({
        where: { isCancelled: false, ...(dateFilter ? { saleDate: dateFilter } : {}) },
        include: { user: { select: { id: true, fullName: true, username: true } } },
      });
      const map = new Map<string, { staff: string; bills: number; totalSales: number; collected: number }>();
      for (const s of sales) {
        const key = s.user?.fullName || "Unassigned";
        const cur = map.get(key) || { staff: key, bills: 0, totalSales: 0, collected: 0 };
        cur.bills += 1;
        cur.totalSales += s.grandTotal;
        cur.collected += s.paidAmount;
        map.set(key, cur);
      }
      return NextResponse.json({ rows: Array.from(map.values()).sort((a, b) => b.totalSales - a.totalSales) });
    }

    if (type === "daily_closing") {
      const registers = await prisma.cashRegister.findMany({
        include: { openedBy: { select: { fullName: true } } },
        orderBy: { date: "desc" },
        take: 30,
      });
      return NextResponse.json({ rows: registers });
    }

    return NextResponse.json({ rows: [] });
  } catch (err) {
    console.error("Reports error:", err);
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 });
  }
}
