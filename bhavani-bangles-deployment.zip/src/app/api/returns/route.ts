import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth("returns", "canView");
  if (error) return error;

  const returns = await prisma.returnRecord.findMany({
    include: {
      sale: { select: { invoiceNumber: true, customerName: true, customerPhone: true } },
      user: { select: { fullName: true } },
    },
    orderBy: { returnDate: "desc" },
    take: 100,
  });
  return NextResponse.json({ returns });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("returns", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    const { saleId, returnedItems, exchangeItems = [], reason, refundMethod = "CASH" } = body;

    if (!saleId || !Array.isArray(returnedItems) || returnedItems.length === 0 || !reason?.trim()) {
      return NextResponse.json({ error: "Invoice, returned items and reason are required" }, { status: 400 });
    }

    const record = await prisma.$transaction(async (tx) => {
      const sale = await tx.sale.findUnique({ where: { id: saleId } });
      if (!sale) throw new Error("Original invoice not found");

      const count = await tx.returnRecord.count();
      const returnNumber = `RET-${new Date().getFullYear()}-${String(count + 1).padStart(3, "0")}`;

      let returnValue = 0;
      for (const item of returnedItems) {
        const qty = Number(item.quantity);
        if (!qty || qty <= 0) continue;
        returnValue += Number(item.unitPrice) * qty;

        const prod = await tx.product.findUnique({ where: { id: item.productId } });
        if (prod) {
          const newStock = prod.currentStock + qty;
          await tx.product.update({ where: { id: prod.id }, data: { currentStock: newStock } });
          await tx.stockMovement.create({
            data: {
              productId: prod.id,
              type: "SALE_RETURN",
              quantity: qty,
              previousStock: prod.currentStock,
              newStock,
              referenceId: returnNumber,
              reason: `Sales Return (${sale.invoiceNumber}): ${reason}`,
              userId: user.id,
            },
          });
        }
      }

      let exchangeValue = 0;
      if (Array.isArray(exchangeItems) && exchangeItems.length > 0) {
        for (const ex of exchangeItems) {
          const qty = Number(ex.quantity);
          if (!qty || qty <= 0) continue;
          const prod = await tx.product.findUnique({ where: { id: ex.productId } });
          if (!prod) throw new Error("Exchange product not found");
          if (prod.currentStock < qty) throw new Error(`Insufficient stock for exchange item ${prod.name}`);

          exchangeValue += Number(ex.unitPrice ?? prod.sellingPrice) * qty;
          const newStock = prod.currentStock - qty;
          await tx.product.update({ where: { id: prod.id }, data: { currentStock: newStock } });
          await tx.stockMovement.create({
            data: {
              productId: prod.id,
              type: "SALE",
              quantity: -qty,
              previousStock: prod.currentStock,
              newStock,
              referenceId: returnNumber,
              reason: `Exchanged against ${sale.invoiceNumber} (${returnNumber})`,
              userId: user.id,
            },
          });
        }
      }

      const refundAmount = Math.max(0, Number((returnValue - exchangeValue).toFixed(2)));
      const exchangeDiff = Math.max(0, Number((exchangeValue - returnValue).toFixed(2)));

      const created = await tx.returnRecord.create({
        data: {
          returnNumber,
          saleId,
          returnedItems: JSON.stringify(returnedItems),
          exchangeItems: exchangeItems.length > 0 ? JSON.stringify(exchangeItems) : null,
          reason: reason.trim(),
          refundAmount,
          exchangeDiff,
          refundMethod: exchangeItems.length > 0 && refundAmount === 0 ? "EXCHANGE" : refundMethod,
          userId: user.id,
        },
        include: { sale: { select: { invoiceNumber: true, customerName: true } } },
      });

      return created;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "SALES_RETURN",
      module: "returns",
      entityId: record.id,
      details: `Processed return ${record.returnNumber} for ${record.sale.invoiceNumber} (Refund: ₹${record.refundAmount})`,
    });

    return NextResponse.json({ returnRecord: record }, { status: 201 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Return failed" }, { status: 400 });
  }
}
