import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("dashboard", "canView");
  if (error) return error;

  try {
    const range = req.nextUrl.searchParams.get("range") || "this_month";
    const fromParam = req.nextUrl.searchParams.get("from");
    const toParam = req.nextUrl.searchParams.get("to");

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    let filterStart = startOfMonth;
    let filterEnd = endOfToday;

    if (range === "today") {
      filterStart = startOfToday;
      filterEnd = endOfToday;
    } else if (range === "yesterday") {
      filterStart = new Date(startOfToday.getTime() - 86400000);
      filterEnd = new Date(startOfToday.getTime() - 1);
    } else if (range === "this_week") {
      const day = now.getDay();
      filterStart = new Date(startOfToday.getTime() - day * 86400000);
    } else if (range === "this_month") {
      filterStart = startOfMonth;
    } else if (range === "custom" && fromParam && toParam) {
      filterStart = new Date(`${fromParam}T00:00:00`);
      filterEnd = new Date(`${toParam}T23:59:59.999`);
    }

    const [
      allValidSales,
      filteredSales,
      todaySales,
      monthSales,
      purchases,
      expenses,
      products,
      customers,
      recentSales,
    ] = await Promise.all([
      prisma.sale.findMany({
        where: { isCancelled: false, saleDate: { gte: startOfYear } },
        include: { items: { include: { product: { include: { category: true } } } }, payments: true },
        orderBy: { saleDate: "asc" },
      }),
      prisma.sale.findMany({
        where: { isCancelled: false, saleDate: { gte: filterStart, lte: filterEnd } },
        include: { items: { include: { product: { include: { category: true } } } }, payments: true },
      }),
      prisma.sale.findMany({
        where: { isCancelled: false, saleDate: { gte: startOfToday, lte: endOfToday } },
      }),
      prisma.sale.findMany({
        where: { isCancelled: false, saleDate: { gte: startOfMonth, lte: endOfToday } },
      }),
      prisma.purchase.findMany({
        where: { purchaseDate: { gte: filterStart, lte: filterEnd } },
      }),
      prisma.expense.findMany({
        where: { expenseDate: { gte: filterStart, lte: filterEnd } },
      }),
      prisma.product.findMany({
        where: { isActive: true },
        include: { category: true },
      }),
      prisma.customer.findMany(),
      prisma.sale.findMany({
        where: { isCancelled: false },
        orderBy: { saleDate: "desc" },
        take: 6,
        select: {
          id: true,
          invoiceNumber: true,
          customerName: true,
          grandTotal: true,
          paymentMethod: true,
          paymentStatus: true,
          saleDate: true,
        },
      }),
    ]);

    const todayTotalSales = todaySales.reduce((s, r) => s + r.grandTotal, 0);
    const todayTotalBills = todaySales.length;
    const monthlySales = monthSales.reduce((s, r) => s + r.grandTotal, 0);
    const totalRevenue = filteredSales.reduce((s, r) => s + r.grandTotal, 0);
    const totalPurchases = purchases.reduce((s, r) => s + r.totalAmount, 0);
    const totalExpenses = expenses.reduce((s, r) => s + r.amount, 0);

    // Profit estimate = Revenue (ex-GST) - COGS - Expenses
    let totalCOGS = 0;
    let totalNetSales = 0;
    for (const s of filteredSales) {
      totalNetSales += s.grandTotal - s.totalGst;
      for (const it of s.items) {
        totalCOGS += it.costPrice * it.quantity;
      }
    }
    const totalProfitEstimate = Number((totalNetSales - totalCOGS - totalExpenses).toFixed(2));

    const totalProducts = products.length;
    const totalStockQuantity = products.reduce((s, p) => s + p.currentStock, 0);
    const lowStockProducts = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert);
    const outOfStockProducts = products.filter((p) => p.currentStock <= 0);
    const customerCount = customers.length;
    const pendingCustomerPayments = customers.reduce((s, c) => s + c.outstandingAmount, 0);

    // Daily chart (last 14 days)
    const dailyMap = new Map<string, number>();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(startOfToday.getTime() - i * 86400000);
      const key = d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
      dailyMap.set(key, 0);
    }
    for (const s of allValidSales) {
      const d = new Date(s.saleDate);
      if (d >= new Date(startOfToday.getTime() - 13 * 86400000)) {
        const key = d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
        if (dailyMap.has(key)) dailyMap.set(key, (dailyMap.get(key) || 0) + s.grandTotal);
      }
    }
    const dailyChart = Array.from(dailyMap.entries()).map(([label, sales]) => ({ label, sales: Math.round(sales) }));

    // Weekly chart (last 6 weeks)
    const weeklyChart: { label: string; sales: number }[] = [];
    for (let w = 5; w >= 0; w--) {
      const wEnd = new Date(endOfToday.getTime() - w * 7 * 86400000);
      const wStart = new Date(wEnd.getTime() - 6 * 86400000);
      const sum = allValidSales
        .filter((s) => s.saleDate >= wStart && s.saleDate <= wEnd)
        .reduce((acc, s) => acc + s.grandTotal, 0);
      weeklyChart.push({
        label: `Wk ${6 - w}`,
        sales: Math.round(sum),
      });
    }

    // Monthly chart (current year Jan-Dec)
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const monthlyTotals = new Array(12).fill(0);
    for (const s of allValidSales) {
      monthlyTotals[new Date(s.saleDate).getMonth()] += s.grandTotal;
    }
    const monthlyChart = months.map((label, idx) => ({ label, sales: Math.round(monthlyTotals[idx]) }));

    // Yearly chart (grouped by year)
    const yearMap = new Map<string, number>();
    yearMap.set(String(now.getFullYear()), 0);
    for (const s of allValidSales) {
      const yr = String(new Date(s.saleDate).getFullYear());
      yearMap.set(yr, (yearMap.get(yr) || 0) + s.grandTotal);
    }
    const yearlyChart = Array.from(yearMap.entries()).map(([label, sales]) => ({ label, sales: Math.round(sales) }));

    // Category-wise sales
    const catMap = new Map<string, number>();
    const prodMap = new Map<string, { id: string; name: string; code: string; qty: number; revenue: number; stock: number }>();

    for (const s of filteredSales) {
      for (const it of s.items) {
        const catName = it.product?.category?.name || "Direct Billing";
        catMap.set(catName, (catMap.get(catName) || 0) + it.total);

        const prodKey = it.productId || `direct-${it.productCode}`;
        const existing = prodMap.get(prodKey) || {
          id: prodKey,
          name: it.productName,
          code: it.productCode,
          qty: 0,
          revenue: 0,
          stock: it.product?.currentStock ?? 0,
        };
        existing.qty += it.quantity;
        existing.revenue += it.total;
        prodMap.set(prodKey, existing);
      }
    }

    const categorySales = Array.from(catMap.entries())
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .sort((a, b) => b.value - a.value);

    const topProducts = Array.from(prodMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6);

    // Payment method breakdown
    const payMap = new Map<string, number>();
    for (const s of filteredSales) {
      if (s.payments.length > 0) {
        for (const p of s.payments) {
          payMap.set(p.method, (payMap.get(p.method) || 0) + p.amount);
        }
      } else {
        payMap.set(s.paymentMethod, (payMap.get(s.paymentMethod) || 0) + s.paidAmount);
      }
    }
    const paymentBreakdown = Array.from(payMap.entries()).map(([method, amount]) => ({
      method,
      amount: Math.round(amount),
    }));

    // AI Business Insights (100% derived from actual DB data)
    const insights: { title: string; detail: string; severity: "info" | "warning" | "success" }[] = [];
    if (categorySales.length > 0) {
      const topCat = categorySales[0];
      const share = totalRevenue > 0 ? Math.round((topCat.value / totalRevenue) * 100) : 0;
      insights.push({
        title: `Top Performing Category: ${topCat.name}`,
        detail: `${topCat.name} accounts for ${share}% (₹${topCat.value.toLocaleString("en-IN")}) of sales in the selected period.`,
        severity: "success",
      });
    }
    if (outOfStockProducts.length > 0) {
      insights.push({
        title: `${outOfStockProducts.length} Product(s) Out of Stock`,
        detail: `Immediate restock advised for: ${outOfStockProducts.slice(0, 3).map((p) => p.name).join(", ")}.`,
        severity: "warning",
      });
    }
    if (lowStockProducts.length > 0) {
      insights.push({
        title: `${lowStockProducts.length} Low-Stock Alert(s)`,
        detail: `Running below minimum threshold: ${lowStockProducts.slice(0, 3).map((p) => `${p.name} (${p.currentStock} left)`).join(", ")}.`,
        severity: "warning",
      });
    }
    if (pendingCustomerPayments > 0) {
      insights.push({
        title: `Pending Customer Receivables`,
        detail: `₹${pendingCustomerPayments.toLocaleString("en-IN")} is currently outstanding across customer accounts. Send WhatsApp reminders from CRM.`,
        severity: "info",
      });
    }
    if (topProducts.length > 0) {
      const best = topProducts[0];
      insights.push({
        title: `Best-Selling Design: ${best.name}`,
        detail: `${best.qty} units sold generating ₹${Math.round(best.revenue).toLocaleString("en-IN")} (${best.stock} remaining in stock).`,
        severity: "success",
      });
    }

    return NextResponse.json({
      kpis: {
        todayTotalSales,
        todayTotalBills,
        monthlySales,
        totalRevenue,
        totalPurchases,
        totalExpenses,
        totalProfitEstimate,
        totalProducts,
        totalStockQuantity,
        lowStockCount: lowStockProducts.length,
        outOfStockCount: outOfStockProducts.length,
        customerCount,
        pendingCustomerPayments,
      },
      charts: {
        daily: dailyChart,
        weekly: weeklyChart,
        monthly: monthlyChart,
        yearly: yearlyChart,
        categorySales,
        paymentBreakdown,
      },
      topProducts,
      lowStockList: [...outOfStockProducts, ...lowStockProducts].slice(0, 6).map((p) => ({
        id: p.id,
        name: p.name,
        code: p.code,
        currentStock: p.currentStock,
        minStockAlert: p.minStockAlert,
        unit: p.unit,
      })),
      recentSales,
      aiInsights: insights,
    });
  } catch (err) {
    console.error("Dashboard error:", err);
    return NextResponse.json({ error: "Failed to load dashboard data" }, { status: 500 });
  }
}
