import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  const categories = await prisma.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: { _count: { select: { products: true } } },
  });
  return NextResponse.json({ categories });
}

export async function POST(req: NextRequest) {
  const { error } = await requireAuth("products", "canCreate");
  if (error) return error;

  try {
    const { name, description } = await req.json();
    if (!name?.trim()) return NextResponse.json({ error: "Category name required" }, { status: 400 });

    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const category = await prisma.category.create({
      data: { name: name.trim(), slug, description: description || null },
    });
    return NextResponse.json({ category }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Category already exists" }, { status: 400 });
  }
}
