import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { createAuditLog } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { username, resetCode, newPassword } = await req.json();
    if (!username) {
      return NextResponse.json({ error: "Username is required" }, { status: 400 });
    }

    const user = await prisma.user.findUnique({
      where: { username: String(username).trim().toLowerCase() },
    });
    if (!user) {
      return NextResponse.json({ error: "Account not found" }, { status: 404 });
    }

    // Step 1: Request reset code
    if (!resetCode) {
      const code = String(Math.floor(100000 + Math.random() * 900000));
      await prisma.user.update({
        where: { id: user.id },
        data: {
          resetToken: code,
          resetExpires: new Date(Date.now() + 15 * 60 * 1000),
        },
      });
      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "PASSWORD_RESET_REQUEST",
        module: "auth",
        details: `Password reset OTP generated for ${user.username}`,
      });
      return NextResponse.json({
        message: "A 6-digit recovery code has been generated. Contact store owner or use the code below in local mode.",
        recoveryCodeHint: code,
      });
    }

    // Step 2: Verify code and set new password
    if (!newPassword || String(newPassword).length < 6) {
      return NextResponse.json({ error: "New password must be at least 6 characters" }, { status: 400 });
    }
    if (
      !user.resetToken ||
      user.resetToken !== String(resetCode).trim() ||
      !user.resetExpires ||
      user.resetExpires < new Date()
    ) {
      return NextResponse.json({ error: "Invalid or expired recovery code" }, { status: 400 });
    }

    const hash = await bcrypt.hash(String(newPassword), 10);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: hash, resetToken: null, resetExpires: null },
    });
    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PASSWORD_RESET_COMPLETE",
      module: "auth",
      details: "Password reset successfully",
    });

    return NextResponse.json({ message: "Password updated successfully. You may now sign in." });
  } catch (err) {
    console.error("Forgot password error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
