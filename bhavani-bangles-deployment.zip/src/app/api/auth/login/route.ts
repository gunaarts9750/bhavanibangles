import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { signSessionToken, setSessionCookie, createAuditLog } from "@/lib/auth";
import { ensureDefaultAdminSeeded } from "@/lib/bootstrap";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 });
    }

    const { username, password } = parsed.data;
    const normalizedUsername = username.trim().toLowerCase();
    let user = await prisma.user.findUnique({
      where: { username: normalizedUsername },
      include: { role: { include: { permissions: true } } },
    });

    if (!user) {
      const totalUsers = await prisma.user.count();
      if (totalUsers === 0) {
        await ensureDefaultAdminSeeded();
        user = await prisma.user.findUnique({
          where: { username: normalizedUsername },
          include: { role: { include: { permissions: true } } },
        });
      }
    }

    if (!user || !user.isActive) {
      return NextResponse.json({ error: "Invalid username or account disabled" }, { status: 401 });
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
    }

    const expiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000);
    const ipAddress = req.headers.get("x-forwarded-for") || "127.0.0.1";
    const userAgent = req.headers.get("user-agent") || "Unknown";

    const session = await prisma.session.create({
      data: {
        userId: user.id,
        token: crypto.randomUUID(),
        ipAddress,
        userAgent,
        expiresAt,
      },
    });

    const jwt = await signSessionToken({ userId: user.id, sessionId: session.id });
    const isHttps =
      req.headers.get("x-forwarded-proto") === "https" ||
      req.nextUrl.protocol === "https:";
    await setSessionCookie(jwt, isHttps);

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "LOGIN",
      module: "auth",
      details: `Logged in as ${user.role.displayName}`,
      ipAddress,
    });

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        roleName: user.role.name,
        roleDisplayName: user.role.displayName,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
