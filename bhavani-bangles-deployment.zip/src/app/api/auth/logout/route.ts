import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { verifySessionToken, clearSessionCookie, createAuditLog } from "@/lib/auth";

export async function POST() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("bb_session")?.value;
    if (token) {
      const payload = await verifySessionToken(token);
      if (payload?.sessionId) {
        await prisma.session.updateMany({
          where: { id: payload.sessionId },
          data: { isActive: false },
        });
        const user = await prisma.user.findUnique({ where: { id: payload.userId } });
        if (user) {
          await createAuditLog({
            userId: user.id,
            username: user.username,
            action: "LOGOUT",
            module: "auth",
            details: "User logged out",
          });
        }
      }
    }
    await clearSessionCookie();
    return NextResponse.json({ success: true });
  } catch {
    await clearSessionCookie();
    return NextResponse.json({ success: true });
  }
}
