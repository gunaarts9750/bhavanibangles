import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  const todayStr = new Date().toISOString().slice(0, 10);
  const [todayRegister, history] = await Promise.all([
    prisma.cashRegister.findFirst({
      where: { date: todayStr },
      orderBy: { createdAt: "desc" },
      include: { openedBy: { select: { fullName: true } } },
    }),
    prisma.cashRegister.findMany({
      orderBy: { createdAt: "desc" },
      take: 15,
      include: { openedBy: { select: { fullName: true } } },
    }),
  ]);

  return NextResponse.json({ todayRegister, history });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth();
  if (error) return error;

  try {
    const { action, openingCash, closingCash, notes } = await req.json();
    const todayStr = new Date().toISOString().slice(0, 10);

    if (action === "OPEN") {
      const openAmt = Number(openingCash || 0);
      const reg = await prisma.cashRegister.create({
        data: {
          date: todayStr,
          openingCash: openAmt,
          expectedCash: openAmt,
          status: "OPEN",
          openedById: user.id,
          notes: notes || "Register opened",
        },
      });
      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "CASH_REGISTER_OPEN",
        module: "pos",
        entityId: reg.id,
        details: `Opened cash register with ₹${openAmt}`,
      });
      return NextResponse.json({ register: reg }, { status: 201 });
    }

    if (action === "CLOSE") {
      const openReg = await prisma.cashRegister.findFirst({
        where: { date: todayStr, status: "OPEN" },
        orderBy: { createdAt: "desc" },
      });
      if (!openReg) return NextResponse.json({ error: "No open register found for today" }, { status: 400 });

      const counted = Number(closingCash || 0);
      const discrepancy = Number((counted - openReg.expectedCash).toFixed(2));
      const closed = await prisma.cashRegister.update({
        where: { id: openReg.id },
        data: {
          closingCash: counted,
          discrepancy,
          status: "CLOSED",
          closedAt: new Date(),
          notes: notes || openReg.notes,
        },
      });
      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "CASH_REGISTER_CLOSE",
        module: "pos",
        entityId: closed.id,
        details: `Closed register. Expected ₹${openReg.expectedCash}, Counted ₹${counted}, Diff ₹${discrepancy}`,
      });
      return NextResponse.json({ register: closed });
    }

    return NextResponse.json({ error: "Invalid register action" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Cash register operation failed" }, { status: 400 });
  }
}
