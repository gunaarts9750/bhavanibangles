import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error } = await requireAuth();
  if (error) return error;

  const { id } = await params;
  const product = await prisma.product.findUnique({
    where: { id },
    include: { category: true, supplier: true, variants: true },
  });
  if (!product) return NextResponse.json({ error: "Product not found" }, { status: 404 });
  return NextResponse.json({ product });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("products", "canEdit");
  if (error) return error;

  const { id } = await params;
  try {
    const body = await req.json();
    const updated = await prisma.product.update({
      where: { id },
      data: {
        name: body.name,
        code: body.code,
        barcode: body.barcode,
        imageUrl: body.imageUrl ?? undefined,
        categoryId: body.categoryId,
        brand: body.brand || null,
        designName: body.designName || null,
        color: body.color || null,
        size: body.size || null,
        material: body.material || null,
        unit: body.unit || "Set",
        purchasePrice: Number(body.purchasePrice || 0),
        sellingPrice: Number(body.sellingPrice || 0),
        mrp: Number(body.mrp || 0),
        discount: Number(body.discount || 0),
        gstPercent: Number(body.gstPercent ?? 3),
        hsnCode: body.hsnCode || "7117",
        minStockAlert: Number(body.minStockAlert ?? 5),
        supplierId: body.supplierId || null,
        rackNumber: body.rackNumber || null,
        description: body.description || null,
      },
      include: { category: true, supplier: true },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PRODUCT_UPDATE",
      module: "products",
      entityId: id,
      details: `Updated product ${updated.name} (${updated.code})`,
    });

    return NextResponse.json({ product: updated });
  } catch (err) {
    console.error("Product update error:", err);
    return NextResponse.json({ error: "Failed to update product" }, { status: 400 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("products", "canDelete");
  if (error) return error;

  const { id } = await params;
  try {
    // Soft delete to preserve historical invoice integrity
    const product = await prisma.product.update({
      where: { id },
      data: { isActive: false },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PRODUCT_DELETE",
      module: "products",
      entityId: id,
      details: `Archived product ${product.name} (${product.code})`,
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to delete product" }, { status: 400 });
  }
}
