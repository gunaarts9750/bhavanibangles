import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("products", "canCreate");
  if (error) return error;

  try {
    const { rows } = await req.json();
    if (!Array.isArray(rows) || rows.length === 0) {
      return NextResponse.json({ error: "No product rows provided" }, { status: 400 });
    }

    const categories = await prisma.category.findMany();
    const catByName = new Map(categories.map((c) => [c.name.toLowerCase(), c.id]));
    const fallbackCatId = categories[0]?.id;

    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const name = String(r.Name || r.name || r["Product Name"] || "").trim();
      if (!name) continue;

      const catKey = String(r.Category || r.category || "").trim().toLowerCase();
      const categoryId = catByName.get(catKey) || fallbackCatId;
      if (!categoryId) continue;

      const code = String(r.Code || r.code || `BB-IMP-${Date.now().toString().slice(-4)}-${i + 1}`).trim();
      const barcode = String(r.Barcode || r.barcode || `8902${Date.now().toString().slice(-7)}${String(i).padStart(2, "0")}`).trim();
      const stock = Number(r.Stock || r.stock || r["Opening Stock"] || 0);

      try {
        await prisma.product.create({
          data: {
            name,
            code,
            barcode,
            categoryId,
            brand: r.Brand || r.brand || null,
            designName: r.Design || r.designName || null,
            color: r.Color || r.Colour || r.color || null,
            size: r.Size ? String(r.Size) : null,
            material: r.Material || r.material || null,
            unit: r.Unit || r.unit || "Set",
            purchasePrice: Number(r["Purchase Price"] || r.purchasePrice || 0),
            sellingPrice: Number(r["Selling Price"] || r.sellingPrice || 0),
            mrp: Number(r.MRP || r.mrp || r["Selling Price"] || 0),
            gstPercent: Number(r.GST || r.gstPercent || 3),
            hsnCode: String(r.HSN || r.hsnCode || "7117"),
            openingStock: stock,
            currentStock: stock,
            minStockAlert: Number(r["Min Stock"] || r.minStockAlert || 5),
            rackNumber: r.Rack || r.rackNumber || null,
          },
        });
        imported++;
      } catch (e) {
        errors.push(`Row ${i + 1} (${name}): ${e instanceof Error ? e.message.slice(0, 60) : "skipped"}`);
      }
    }

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PRODUCT_BULK_IMPORT",
      module: "products",
      details: `Imported ${imported} products from Excel`,
    });

    return NextResponse.json({ imported, errors });
  } catch (err) {
    console.error("Bulk import error:", err);
    return NextResponse.json({ error: "Bulk import failed" }, { status: 500 });
  }
}
