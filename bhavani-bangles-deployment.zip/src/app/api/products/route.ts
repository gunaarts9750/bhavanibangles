import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth();
  if (error) return error;

  const q = req.nextUrl.searchParams.get("q")?.trim() || "";
  const categoryId = req.nextUrl.searchParams.get("categoryId") || "";
  const stockFilter = req.nextUrl.searchParams.get("stock") || "";
  const barcode = req.nextUrl.searchParams.get("barcode")?.trim() || "";

  const where: Record<string, unknown> = { isActive: true };
  if (barcode) {
    where.OR = [{ barcode }, { code: barcode }];
  } else if (q) {
    where.OR = [
      { name: { contains: q } },
      { code: { contains: q } },
      { barcode: { contains: q } },
      { designName: { contains: q } },
      { color: { contains: q } },
    ];
  }
  if (categoryId) where.categoryId = categoryId;
  if (stockFilter === "out") where.currentStock = { lte: 0 };

  let products = await prisma.product.findMany({
    where,
    include: { category: true, supplier: true, variants: true },
    orderBy: { createdAt: "desc" },
  });

  if (stockFilter === "low") {
    products = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert);
  }

  return NextResponse.json({ products });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("products", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    if (!body.name || !body.categoryId) {
      return NextResponse.json({ error: "Product name and category are required" }, { status: 400 });
    }

    const code = body.code?.trim() || `BB-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
    const barcode = body.barcode?.trim() || `8901${Date.now().toString().slice(-9)}`;
    const openingStock = Number(body.openingStock ?? body.currentStock ?? 0);

    const product = await prisma.$transaction(async (tx) => {
      const created = await tx.product.create({
        data: {
          name: body.name.trim(),
          code,
          barcode,
          imageUrl: body.imageUrl || null,
          categoryId: body.categoryId,
          brand: body.brand || null,
          designName: body.designName || null,
          color: body.color || null,
          size: body.size || null,
          material: body.material || null,
          unit: body.unit || "Set",
          purchasePrice: Number(body.purchasePrice || 0),
          sellingPrice: Number(body.sellingPrice || 0),
          mrp: Number(body.mrp || body.sellingPrice || 0),
          discount: Number(body.discount || 0),
          gstPercent: Number(body.gstPercent ?? 3),
          hsnCode: body.hsnCode || "7117",
          openingStock,
          currentStock: openingStock,
          minStockAlert: Number(body.minStockAlert ?? 5),
          supplierId: body.supplierId || null,
          rackNumber: body.rackNumber || null,
          description: body.description || null,
          variants: Array.isArray(body.variants) && body.variants.length > 0
            ? {
                create: body.variants.map((v: { color?: string; size?: string; sku?: string; sellingPrice?: number; stock?: number }, idx: number) => ({
                  color: v.color || null,
                  size: v.size || null,
                  sku: v.sku || `${code}-V${idx + 1}`,
                  sellingPrice: v.sellingPrice ? Number(v.sellingPrice) : null,
                  stock: Number(v.stock || 0),
                })),
              }
            : undefined,
        },
        include: { category: true, supplier: true, variants: true },
      });

      await tx.barcode.create({
        data: { productId: created.id, code: created.barcode, format: "CODE128" },
      });

      if (openingStock > 0) {
        await tx.stockMovement.create({
          data: {
            productId: created.id,
            type: "OPENING",
            quantity: openingStock,
            previousStock: 0,
            newStock: openingStock,
            reason: "Opening stock on product creation",
            userId: user.id,
          },
        });
      }

      return created;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "PRODUCT_CREATE",
      module: "products",
      entityId: product.id,
      details: `Created product ${product.name} (${product.code})`,
    });

    return NextResponse.json({ product }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to create product";
    return NextResponse.json({ error: message.includes("Unique") ? "Product code or barcode already exists" : message }, { status: 400 });
  }
}
