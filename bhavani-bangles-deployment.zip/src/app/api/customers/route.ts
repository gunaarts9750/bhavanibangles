import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth();
  if (error) return error;

  const q = req.nextUrl.searchParams.get("q")?.trim() || "";
  const type = req.nextUrl.searchParams.get("type") || "";

  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [{ name: { contains: q } }, { phone: { contains: q } }, { address: { contains: q } }];
  }
  if (type && type !== "ALL") where.customerType = type;

  const customers = await prisma.customer.findMany({
    where,
    include: {
      _count: { select: { sales: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ customers });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("customers", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    if (!body.name?.trim() || !body.phone?.trim()) {
      return NextResponse.json({ error: "Customer name and mobile number are required" }, { status: 400 });
    }

    const customer = await prisma.customer.create({
      data: {
        name: body.name.trim(),
        phone: body.phone.trim(),
        email: body.email || null,
        address: body.address || null,
        birthday: body.birthday || null,
        anniversary: body.anniversary || null,
        customerType: body.customerType || "REGULAR",
        advanceBalance: Number(body.advanceBalance || 0),
        notes: body.notes || null,
      },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "CUSTOMER_CREATE",
      module: "customers",
      entityId: customer.id,
      details: `Added customer ${customer.name} (${customer.phone})`,
    });

    return NextResponse.json({ customer }, { status: 201 });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Failed to create customer";
    return NextResponse.json({ error: msg.includes("Unique") ? "Mobile number already registered" : msg }, { status: 400 });
  }
}
