import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error } = await requireAuth("customers", "canView");
  if (error) return error;
  const { id } = await params;

  const customer = await prisma.customer.findUnique({
    where: { id },
    include: {
      sales: { orderBy: { saleDate: "desc" }, take: 50, include: { items: true } },
      ledgerEntries: { orderBy: { createdAt: "desc" }, take: 50 },
    },
  });
  if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  return NextResponse.json({ customer });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("customers", "canEdit");
  if (error) return error;
  const { id } = await params;

  try {
    const body = await req.json();

    if (body.action === "COLLECT_DUE") {
      const amount = Number(body.amount);
      if (!amount || amount <= 0) return NextResponse.json({ error: "Valid amount required" }, { status: 400 });

      const updated = await prisma.$transaction(async (tx) => {
        const cust = await tx.customer.findUnique({ where: { id } });
        if (!cust) throw new Error("Customer not found");
        const nextDue = Math.max(0, Number((cust.outstandingAmount - amount).toFixed(2)));
        const c = await tx.customer.update({ where: { id }, data: { outstandingAmount: nextDue } });
        await tx.customerLedger.create({
          data: {
            customerId: id,
            type: "PAYMENT",
            amount: -amount,
            balance: nextDue,
            notes: body.notes || `Due collected via ${body.method || "CASH"}`,
          },
        });
        await tx.payment.create({
          data: {
            amount,
            method: body.method || "CASH",
            notes: `Customer due payment from ${cust.name}`,
          },
        });
        return c;
      });

      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "CUSTOMER_PAYMENT",
        module: "customers",
        entityId: id,
        details: `Collected ₹${amount} due from ${updated.name}`,
      });
      return NextResponse.json({ customer: updated });
    }

    if (body.action === "ADD_ADVANCE") {
      const amount = Number(body.amount);
      if (!amount || amount <= 0) return NextResponse.json({ error: "Valid advance amount required" }, { status: 400 });

      const updated = await prisma.$transaction(async (tx) => {
        const cust = await tx.customer.findUnique({ where: { id } });
        if (!cust) throw new Error("Customer not found");
        const c = await tx.customer.update({
          where: { id },
          data: { advanceBalance: Number((cust.advanceBalance + amount).toFixed(2)) },
        });
        await tx.customerLedger.create({
          data: {
            customerId: id,
            type: "ADVANCE",
            amount,
            balance: cust.outstandingAmount,
            notes: body.notes || `Advance received via ${body.method || "CASH"}`,
          },
        });
        return c;
      });
      return NextResponse.json({ customer: updated });
    }

    const customer = await prisma.customer.update({
      where: { id },
      data: {
        name: body.name,
        phone: body.phone,
        email: body.email || null,
        address: body.address || null,
        birthday: body.birthday || null,
        anniversary: body.anniversary || null,
        customerType: body.customerType || "REGULAR",
        notes: body.notes || null,
      },
    });
    return NextResponse.json({ customer });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Update failed" }, { status: 400 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error } = await requireAuth("customers", "canDelete");
  if (error) return error;
  const { id } = await params;

  try {
    await prisma.customer.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to delete customer" }, { status: 400 });
  }
}
