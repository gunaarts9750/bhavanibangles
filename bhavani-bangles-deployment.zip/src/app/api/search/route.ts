import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth();
  if (error) return error;

  const q = req.nextUrl.searchParams.get("q")?.trim();
  if (!q || q.length < 2) {
    return NextResponse.json({ products: [], customers: [], invoices: [], suppliers: [] });
  }

  const [products, customers, invoices, suppliers] = await Promise.all([
    prisma.product.findMany({
      where: {
        OR: [
          { name: { contains: q } },
          { code: { contains: q } },
          { barcode: { contains: q } },
          { designName: { contains: q } },
        ],
      },
      take: 6,
      select: { id: true, name: true, code: true, sellingPrice: true, currentStock: true, unit: true },
    }),
    prisma.customer.findMany({
      where: { OR: [{ name: { contains: q } }, { phone: { contains: q } }] },
      take: 5,
      select: { id: true, name: true, phone: true, outstandingAmount: true },
    }),
    prisma.sale.findMany({
      where: {
        OR: [{ invoiceNumber: { contains: q } }, { customerName: { contains: q } }],
      },
      take: 5,
      orderBy: { saleDate: "desc" },
      select: { id: true, invoiceNumber: true, customerName: true, grandTotal: true, paymentStatus: true },
    }),
    prisma.supplier.findMany({
      where: { OR: [{ name: { contains: q } }, { phone: { contains: q } }] },
      take: 4,
      select: { id: true, name: true, phone: true, pendingBalance: true },
    }),
  ]);

  return NextResponse.json({ products, customers, invoices, suppliers });
}
