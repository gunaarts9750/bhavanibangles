import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  const settings = await prisma.setting.upsert({
    where: { id: "default" },
    update: {},
    create: { id: "default" },
  });
  return NextResponse.json({ settings });
}

export async function PUT(req: NextRequest) {
  const { user, error } = await requireAuth("settings", "canEdit");
  if (error) return error;

  try {
    const body = await req.json();
    const settings = await prisma.setting.upsert({
      where: { id: "default" },
      update: {
        shopName: body.shopName,
        shopTagline: body.shopTagline,
        shopLogoUrl: body.shopLogoUrl ?? undefined,
        address: body.address,
        phone: body.phone,
        email: body.email,
        gstin: body.gstin,
        invoicePrefix: body.invoicePrefix,
        nextInvoiceNumber: body.nextInvoiceNumber ? Number(body.nextInvoiceNumber) : undefined,
        quotationPrefix: body.quotationPrefix,
        defaultGstPercent: body.defaultGstPercent !== undefined ? Number(body.defaultGstPercent) : undefined,
        defaultHsnCode: body.defaultHsnCode,
        currency: body.currency,
        currencySymbol: body.currencySymbol,
        dateFormat: body.dateFormat,
        defaultPrintFormat: body.defaultPrintFormat,
        allowNegativeStock: body.allowNegativeStock !== undefined ? Boolean(body.allowNegativeStock) : undefined,
        enableLoyaltyPoints: body.enableLoyaltyPoints !== undefined ? Boolean(body.enableLoyaltyPoints) : undefined,
        loyaltyPointRate: body.loyaltyPointRate !== undefined ? Number(body.loyaltyPointRate) : undefined,
        invoiceTerms: body.invoiceTerms,
        thankYouMessage: body.thankYouMessage,
        upiId: body.upiId,
      },
      create: { id: "default" },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "SETTINGS_UPDATE",
      module: "settings",
      details: "Updated shop, invoice & tax configuration",
    });

    return NextResponse.json({ settings });
  } catch {
    return NextResponse.json({ error: "Failed to save settings" }, { status: 400 });
  }
}
