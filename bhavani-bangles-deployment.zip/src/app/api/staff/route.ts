import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth("staff", "canView");
  if (error) return error;

  const [staffList, roles, salesByUser] = await Promise.all([
    prisma.staff.findMany({
      include: {
        user: { select: { id: true, username: true, isActive: true, lastLoginAt: true, role: true } },
        attendances: { orderBy: { date: "desc" }, take: 31 },
      },
      orderBy: { createdAt: "asc" },
    }),
    prisma.role.findMany({ orderBy: { name: "asc" } }),
    prisma.sale.groupBy({
      by: ["userId"],
      where: { isCancelled: false, userId: { not: null } },
      _sum: { grandTotal: true },
      _count: { id: true },
    }),
  ]);

  const salesMap = new Map(salesByUser.map((s) => [s.userId, { total: s._sum.grandTotal || 0, bills: s._count.id }]));

  const staff = staffList.map((st) => ({
    ...st,
    salesSummary: st.userId ? salesMap.get(st.userId) || { total: 0, bills: 0 } : { total: 0, bills: 0 },
  }));

  return NextResponse.json({ staff, roles });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("staff", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    if (!body.name?.trim() || !body.phone?.trim() || !body.designation?.trim()) {
      return NextResponse.json({ error: "Name, phone and designation are required" }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      let userId: string | null = null;
      if (body.username?.trim() && body.password && body.roleId) {
        const hash = await bcrypt.hash(String(body.password), 10);
        const createdUser = await tx.user.create({
          data: {
            username: body.username.trim().toLowerCase(),
            email: body.email || null,
            fullName: body.name.trim(),
            phone: body.phone.trim(),
            passwordHash: hash,
            roleId: body.roleId,
          },
        });
        userId = createdUser.id;
      }

      const count = await tx.staff.count();
      const staffCode = body.staffCode?.trim() || `BB-STF-${String(count + 1).padStart(2, "0")}`;

      return tx.staff.create({
        data: {
          staffCode,
          userId,
          name: body.name.trim(),
          phone: body.phone.trim(),
          email: body.email || null,
          address: body.address || null,
          designation: body.designation.trim(),
          salary: Number(body.salary || 0),
          joiningDate: body.joiningDate ? new Date(body.joiningDate) : new Date(),
        },
        include: { user: { select: { username: true, role: true } } },
      });
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "STAFF_CREATE",
      module: "staff",
      entityId: result.id,
      details: `Added staff ${result.name} (${result.staffCode})`,
    });

    return NextResponse.json({ staff: result }, { status: 201 });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Failed to add staff";
    return NextResponse.json({ error: msg.includes("Unique") ? "Username or Staff ID already exists" : msg }, { status: 400 });
  }
}
