import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  const suppliers = await prisma.supplier.findMany({
    include: {
      _count: { select: { purchases: true, products: true } },
      ledgerEntries: { orderBy: { createdAt: "desc" }, take: 15 },
    },
    orderBy: { name: "asc" },
  });
  return NextResponse.json({ suppliers });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("purchases", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    if (!body.name?.trim() || !body.phone?.trim()) {
      return NextResponse.json({ error: "Supplier name and phone are required" }, { status: 400 });
    }
    const supplier = await prisma.supplier.create({
      data: {
        name: body.name.trim(),
        contactPerson: body.contactPerson || null,
        phone: body.phone.trim(),
        email: body.email || null,
        address: body.address || null,
        gstin: body.gstin || null,
        pendingBalance: Number(body.pendingBalance || 0),
        notes: body.notes || null,
      },
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "SUPPLIER_CREATE",
      module: "purchases",
      entityId: supplier.id,
      details: `Added supplier ${supplier.name}`,
    });

    return NextResponse.json({ supplier }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to add supplier" }, { status: 400 });
  }
}
