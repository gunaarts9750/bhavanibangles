import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("purchases", "canEdit");
  if (error) return error;
  const { id } = await params;

  try {
    const body = await req.json();
    if (body.action === "PAYMENT") {
      const amt = Number(body.amount);
      if (!amt || amt <= 0) return NextResponse.json({ error: "Invalid payment amount" }, { status: 400 });

      const updated = await prisma.$transaction(async (tx) => {
        const sup = await tx.supplier.findUnique({ where: { id } });
        if (!sup) throw new Error("Supplier not found");
        const nextBal = Math.max(0, Number((sup.pendingBalance - amt).toFixed(2)));
        const s = await tx.supplier.update({ where: { id }, data: { pendingBalance: nextBal } });
        await tx.supplierLedger.create({
          data: {
            supplierId: id,
            type: "PAYMENT",
            amount: -amt,
            balance: nextBal,
            referenceNo: body.referenceNo || null,
            notes: body.notes || `Supplier payment via ${body.method || "BANK_TRANSFER"}`,
          },
        });
        return s;
      });

      await createAuditLog({
        userId: user.id,
        username: user.username,
        action: "SUPPLIER_PAYMENT",
        module: "purchases",
        entityId: id,
        details: `Paid ₹${amt} to supplier ${updated.name}`,
      });
      return NextResponse.json({ supplier: updated });
    }

    const supplier = await prisma.supplier.update({
      where: { id },
      data: {
        name: body.name,
        contactPerson: body.contactPerson || null,
        phone: body.phone,
        email: body.email || null,
        address: body.address || null,
        gstin: body.gstin || null,
        notes: body.notes || null,
      },
    });
    return NextResponse.json({ supplier });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Update failed" }, { status: 400 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { error } = await requireAuth("purchases", "canDelete");
  if (error) return error;
  const { id } = await params;

  try {
    await prisma.supplier.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Cannot delete supplier with existing purchases" }, { status: 400 });
  }
}
