import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function GET() {
  const { error } = await requireAuth();
  if (error) return error;

  const notifications = await prisma.notification.findMany({
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  return NextResponse.json({ notifications, unreadCount });
}

export async function PATCH(req: NextRequest) {
  const { error } = await requireAuth();
  if (error) return error;

  const body = await req.json().catch(() => ({}));
  if (body.id) {
    await prisma.notification.update({ where: { id: body.id }, data: { isRead: true } });
  } else {
    await prisma.notification.updateMany({ where: { isRead: false }, data: { isRead: true } });
  }
  return NextResponse.json({ success: true });
}
