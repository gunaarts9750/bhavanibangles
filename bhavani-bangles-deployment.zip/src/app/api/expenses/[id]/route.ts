import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { user, error } = await requireAuth("expenses", "canDelete");
  if (error) return error;
  const { id } = await params;

  try {
    const exp = await prisma.expense.delete({ where: { id } });
    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "EXPENSE_DELETE",
      module: "expenses",
      entityId: id,
      details: `Deleted expense ${exp.category} (₹${exp.amount})`,
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to delete expense" }, { status: 400 });
  }
}
