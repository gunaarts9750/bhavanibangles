import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("expenses", "canView");
  if (error) return error;

  const from = req.nextUrl.searchParams.get("from");
  const to = req.nextUrl.searchParams.get("to");
  const category = req.nextUrl.searchParams.get("category");

  const where: Record<string, unknown> = {};
  if (category && category !== "ALL") where.category = category;
  if (from || to) {
    where.expenseDate = {
      ...(from ? { gte: new Date(`${from}T00:00:00`) } : {}),
      ...(to ? { lte: new Date(`${to}T23:59:59.999`) } : {}),
    };
  }

  const expenses = await prisma.expense.findMany({
    where,
    include: { user: { select: { fullName: true } } },
    orderBy: { expenseDate: "desc" },
  });

  const total = expenses.reduce((s, e) => s + e.amount, 0);
  const byCategory: Record<string, number> = {};
  for (const e of expenses) {
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
  }

  return NextResponse.json({
    expenses,
    total,
    categorySummary: Object.entries(byCategory).map(([name, value]) => ({ name, value })),
  });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("expenses", "canCreate");
  if (error) return error;

  try {
    const body = await req.json();
    const amount = Number(body.amount);
    if (!body.category || !amount || amount <= 0) {
      return NextResponse.json({ error: "Category and positive amount are required" }, { status: 400 });
    }

    const expense = await prisma.expense.create({
      data: {
        category: body.category,
        amount,
        expenseDate: body.expenseDate ? new Date(body.expenseDate) : new Date(),
        paymentMode: body.paymentMode || "CASH",
        description: body.description || null,
        receiptUrl: body.receiptUrl || null,
        userId: user.id,
      },
    });

    if (expense.paymentMode === "CASH") {
      const todayStr = new Date().toISOString().slice(0, 10);
      const reg = await prisma.cashRegister.findFirst({ where: { date: todayStr, status: "OPEN" } });
      if (reg) {
        await prisma.cashRegister.update({
          where: { id: reg.id },
          data: { cashExpenses: reg.cashExpenses + amount, expectedCash: reg.expectedCash - amount },
        });
      }
    }

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "EXPENSE_CREATE",
      module: "expenses",
      entityId: expense.id,
      details: `Recorded expense ${expense.category}: ₹${amount}`,
    });

    return NextResponse.json({ expense }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to create expense" }, { status: 400 });
  }
}
