import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { error } = await requireAuth("inventory", "canView");
  if (error) return error;

  const filter = req.nextUrl.searchParams.get("filter") || "all";

  const [products, movements] = await Promise.all([
    prisma.product.findMany({
      where: { isActive: true },
      include: { category: true, supplier: true },
      orderBy: { currentStock: "asc" },
    }),
    prisma.stockMovement.findMany({
      include: {
        product: { select: { name: true, code: true, unit: true } },
        user: { select: { fullName: true, username: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 150,
    }),
  ]);

  let filteredProducts = products;
  if (filter === "low") {
    filteredProducts = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert);
  } else if (filter === "out") {
    filteredProducts = products.filter((p) => p.currentStock <= 0);
  }

  return NextResponse.json({
    products: filteredProducts,
    movements,
    summary: {
      totalSkus: products.length,
      totalQty: products.reduce((s, p) => s + p.currentStock, 0),
      stockValue: products.reduce((s, p) => s + p.currentStock * p.purchasePrice, 0),
      retailValue: products.reduce((s, p) => s + p.currentStock * p.sellingPrice, 0),
      lowStock: products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert).length,
      outOfStock: products.filter((p) => p.currentStock <= 0).length,
    },
  });
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireAuth("inventory", "canEdit");
  if (error) return error;

  try {
    const { productId, type, quantity, reason } = await req.json();
    const qty = Number(quantity);
    if (!productId || !type || !qty) {
      return NextResponse.json({ error: "Product, movement type and quantity are required" }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      const settings = await tx.setting.findUnique({ where: { id: "default" } });
      const prod = await tx.product.findUnique({ where: { id: productId } });
      if (!prod) throw new Error("Product not found");

      const deductionTypes = ["DAMAGED", "LOST", "PURCHASE_RETURN", "TRANSFER"];
      const signedQty = deductionTypes.includes(type) ? -Math.abs(qty) : qty;
      const newStock = type === "AUDIT" ? Math.max(0, qty) : prod.currentStock + signedQty;
      const actualDelta = newStock - prod.currentStock;

      if (!settings?.allowNegativeStock && newStock < 0) {
        throw new Error(`Cannot reduce stock below 0 (Current stock: ${prod.currentStock})`);
      }

      await tx.product.update({
        where: { id: prod.id },
        data: { currentStock: newStock },
      });

      const movement = await tx.stockMovement.create({
        data: {
          productId: prod.id,
          type,
          quantity: actualDelta,
          previousStock: prod.currentStock,
          newStock,
          reason: reason?.trim() || `${type} stock update`,
          userId: user.id,
        },
        include: { product: { select: { name: true, code: true } } },
      });

      return movement;
    });

    await createAuditLog({
      userId: user.id,
      username: user.username,
      action: "STOCK_ADJUST",
      module: "inventory",
      entityId: productId,
      details: `${type} on ${result.product.name}: ${result.previousStock} -> ${result.newStock} (${result.reason})`,
    });

    return NextResponse.json({ movement: result }, { status: 201 });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Adjustment failed" }, { status: 400 });
  }
}
