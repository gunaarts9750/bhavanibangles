import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, createAuditLog } from "@/lib/auth";

export async function GET() {
  const { user, error } = await requireAuth("settings", "canEdit");
  if (error) return error;

  const [
    settings,
    categories,
    suppliers,
    products,
    customers,
    sales,
    purchases,
    expenses,
    quotations,
    returns,
    staff,
  ] = await Promise.all([
    prisma.setting.findMany(),
    prisma.category.findMany(),
    prisma.supplier.findMany(),
    prisma.product.findMany(),
    prisma.customer.findMany(),
    prisma.sale.findMany({ include: { items: true, payments: true } }),
    prisma.purchase.findMany({ include: { items: true } }),
    prisma.expense.findMany(),
    prisma.quotation.findMany({ include: { items: true } }),
    prisma.returnRecord.findMany(),
    prisma.staff.findMany(),
  ]);

  await createAuditLog({
    userId: user.id,
    username: user.username,
    action: "DATABASE_BACKUP",
    module: "settings",
    details: "Exported full JSON database backup",
  });

  const payload = {
    exportedAt: new Date().toISOString(),
    app: "BHAVANI BANGLES POS",
    data: { settings, categories, suppliers, products, customers, sales, purchases, expenses, quotations, returns, staff },
  };

  return new NextResponse(JSON.stringify(payload, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="bhavani-bangles-backup-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
