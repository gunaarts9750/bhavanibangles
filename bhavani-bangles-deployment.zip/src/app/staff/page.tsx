"use client";

import React, { useEffect, useState } from "react";
import { UserPlus, LogIn, LogOut as LogOutIcon, Calendar, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatDate, formatDateTime } from "@/lib/format";

interface StaffMember {
  id: string;
  staffCode: string;
  name: string;
  phone: string;
  email?: string | null;
  designation: string;
  salary: number;
  joiningDate: string;
  user?: { username: string; role: { displayName: string } } | null;
  attendances: { id: string; date: string; status: string; checkIn?: string | null; checkOut?: string | null }[];
  salesSummary: { total: number; bills: number };
}

export default function StaffPage() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [roles, setRoles] = useState<{ id: string; displayName: string }[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    designation: "Billing Executive",
    salary: 15000,
    username: "",
    password: "",
    roleId: "",
  });

  const todayStr = new Date().toISOString().slice(0, 10);

  const loadStaff = async () => {
    const res = await fetch("/api/staff");
    if (res.ok) {
      const d = await res.json();
      setStaff(d.staff || []);
      setRoles(d.roles || []);
    }
  };

  useEffect(() => {
    loadStaff();
  }, []);

  const handleAttendance = async (staffId: string, action?: string, status?: string) => {
    const res = await fetch("/api/attendance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ staffId, date: todayStr, action, status }),
    });
    if (res.ok) loadStaff();
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/staff", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      setModalOpen(false);
      setForm({ name: "", phone: "", email: "", designation: "Billing Executive", salary: 15000, username: "", password: "", roleId: "" });
      loadStaff();
    }
  };

  return (
    <AppShell
      title="Staff & Attendance"
      subtitle="Employee profiles, daily check-in/check-out, leave tracking & staff sales performance"
      actions={
        <button
          onClick={() => {
            setForm((prev) => ({ ...prev, roleId: roles[0]?.id || "" }));
            setModalOpen(true);
          }}
          className="bb-btn-primary py-2 px-3.5 text-xs"
        >
          <UserPlus className="w-4 h-4" /> Add Staff Member
        </button>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {staff.map((st) => {
          const todayAtt = st.attendances.find((a) => a.date === todayStr);
          return (
            <div key={st.id} className="bb-card p-5 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rosegold-600">{st.staffCode}</span>
                  <h3 className="font-serif text-xl font-bold text-espresso-900">{st.name}</h3>
                  <p className="text-xs text-espresso-500">
                    {st.designation} {st.user ? `• Login: @${st.user.username} (${st.user.role.displayName})` : ""}
                  </p>
                </div>
                <span className={todayAtt?.status === "PRESENT" ? "bb-badge-success" : todayAtt?.status === "LEAVE" ? "bb-badge-warning" : "bb-badge-blush"}>
                  {todayAtt?.status || "NOT MARKED"}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs bg-ivory-50 rounded-xl p-3 border border-ivory-200">
                <div>
                  <p className="text-[10px] text-espresso-400">Monthly Salary</p>
                  <p className="font-bold text-espresso-900 mt-0.5">{st.salary > 0 ? formatCurrency(st.salary) : "Owner"}</p>
                </div>
                <div>
                  <p className="text-[10px] text-espresso-400">Sales Billed</p>
                  <p className="font-bold text-rosegold-700 mt-0.5">{formatCurrency(st.salesSummary.total)}</p>
                </div>
                <div>
                  <p className="text-[10px] text-espresso-400">Joined</p>
                  <p className="font-semibold text-espresso-700 mt-0.5">{formatDate(st.joiningDate)}</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-ivory-200">
                <div className="text-[11px] text-espresso-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-rosegold-500" />
                  {todayAtt?.checkIn ? `In: ${formatDateTime(todayAtt.checkIn).split(",")[1]}` : "No check-in today"}
                  {todayAtt?.checkOut ? ` • Out: ${formatDateTime(todayAtt.checkOut).split(",")[1]}` : ""}
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleAttendance(st.id, "CHECK_IN")}
                    className="bb-btn-primary py-1.5 px-2.5 text-xs"
                  >
                    <LogIn className="w-3.5 h-3.5" /> Check In
                  </button>
                  <button
                    onClick={() => handleAttendance(st.id, "CHECK_OUT")}
                    className="bb-btn-secondary py-1.5 px-2.5 text-xs"
                  >
                    <LogOutIcon className="w-3.5 h-3.5" /> Check Out
                  </button>
                  <button
                    onClick={() => handleAttendance(st.id, undefined, "LEAVE")}
                    className="bb-btn-secondary py-1.5 px-2.5 text-xs text-amber-700"
                  >
                    Leave
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleCreate} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Add Staff & User Account</h3>
              <button type="button" onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div><label className="bb-label">Full Name *</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bb-input" required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">Mobile *</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="bb-input" required /></div>
              <div><label className="bb-label">Designation *</label><input value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} className="bb-input" required /></div>
            </div>
            <div><label className="bb-label">Monthly Salary (₹)</label><input type="number" value={form.salary} onChange={(e) => setForm({ ...form, salary: Number(e.target.value) })} className="bb-input" /></div>
            <div className="pt-2 border-t border-ivory-200">
              <p className="text-[11px] font-bold uppercase text-rosegold-600 mb-2">POS Login Credentials (Optional)</p>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="bb-label">Username</label><input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} className="bb-input" /></div>
                <div><label className="bb-label">Password</label><input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="bb-input" /></div>
              </div>
              <div className="mt-2">
                <label className="bb-label">Assigned Role</label>
                <select value={form.roleId} onChange={(e) => setForm({ ...form, roleId: e.target.value })} className="bb-input">
                  {roles.map((r) => <option key={r.id} value={r.id}>{r.displayName}</option>)}
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Create Staff</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
