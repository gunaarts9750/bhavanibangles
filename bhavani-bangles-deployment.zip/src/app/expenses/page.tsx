"use client";

import React, { useEffect, useState } from "react";
import { Plus, Trash2, Upload, X } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/components/AuthContext";
import { formatCurrency, formatDate } from "@/lib/format";

const EXPENSE_CATEGORIES = [
  "Shop Rent",
  "Electricity",
  "Staff Salary",
  "Transport",
  "Packaging",
  "Maintenance",
  "Marketing",
  "Other Expenses",
];

interface Expense {
  id: string;
  category: string;
  amount: number;
  expenseDate: string;
  paymentMode: string;
  description?: string | null;
  receiptUrl?: string | null;
}

export default function ExpensesPage() {
  const { can } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [total, setTotal] = useState(0);
  const [categorySummary, setCategorySummary] = useState<{ name: string; value: number }[]>([]);
  const [catFilter, setCatFilter] = useState("ALL");

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    category: "Packaging",
    amount: 0,
    expenseDate: new Date().toISOString().slice(0, 10),
    paymentMode: "CASH",
    description: "",
    receiptUrl: "",
  });

  const loadExpenses = async () => {
    const params = new URLSearchParams();
    if (catFilter !== "ALL") params.set("category", catFilter);
    const res = await fetch(`/api/expenses?${params.toString()}`);
    if (res.ok) {
      const d = await res.json();
      setExpenses(d.expenses || []);
      setTotal(d.total || 0);
      setCategorySummary(d.categorySummary || []);
    }
  };

  useEffect(() => {
    loadExpenses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catFilter]);

  const handleUploadReceipt = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const d = await res.json();
    if (res.ok && d.url) setForm((prev) => ({ ...prev, receiptUrl: d.url }));
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/expenses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      setModalOpen(false);
      setForm({ category: "Packaging", amount: 0, expenseDate: new Date().toISOString().slice(0, 10), paymentMode: "CASH", description: "", receiptUrl: "" });
      loadExpenses();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this expense record?")) return;
    const res = await fetch(`/api/expenses/${id}`, { method: "DELETE" });
    if (res.ok) loadExpenses();
  };

  return (
    <AppShell
      title="Expense Management"
      subtitle="Track showroom rent, utilities, salaries, packaging & operating costs"
      actions={
        <button onClick={() => setModalOpen(true)} className="bb-btn-primary py-2 px-3.5 text-xs">
          <Plus className="w-4 h-4" /> Add Expense
        </button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="bb-card p-5 flex flex-col justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-espresso-400">Total Recorded Expenses</p>
            <p className="text-3xl font-bold text-rosegold-700 mt-2 tabular-nums">{formatCurrency(total)}</p>
            <p className="text-xs text-espresso-500 mt-1">{expenses.length} transaction(s)</p>
          </div>
          <div className="mt-4">
            <label className="bb-label">Filter by Category</label>
            <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="bb-input py-2 text-xs">
              <option value="ALL">All Categories</option>
              {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div className="bb-card p-5 lg:col-span-2">
          <h3 className="font-serif text-lg font-bold text-espresso-900 mb-3">Expense Breakdown by Category</h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categorySummary}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EDE3D4" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#6E5A52" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#6E5A52" }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Bar dataKey="value" fill="#B76E79" radius={[6, 6, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-3 text-left">Category</th>
                <th className="py-3 px-3 text-left">Description</th>
                <th className="py-3 px-3 text-center">Payment Mode</th>
                <th className="py-3 px-3 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {expenses.map((e) => (
                <tr key={e.id}>
                  <td className="py-3 px-4 text-espresso-500">{formatDate(e.expenseDate)}</td>
                  <td className="py-3 px-3"><span className="bb-badge-blush">{e.category}</span></td>
                  <td className="py-3 px-3 text-espresso-700">
                    {e.description || "-"}
                    {e.receiptUrl && (
                      <a href={e.receiptUrl} target="_blank" rel="noreferrer" className="ml-2 text-rosegold-600 underline">
                        View Receipt
                      </a>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">{e.paymentMode}</td>
                  <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(e.amount)}</td>
                  <td className="py-3 px-4 text-right">
                    {can("expenses", "canDelete") && (
                      <button onClick={() => handleDelete(e.id)} className="text-rose-500 hover:text-rose-700">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={handleCreate} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3.5 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Record Store Expense</h3>
              <button type="button" onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <label className="bb-label">Expense Category *</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="bb-input">
                {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="bb-label">Amount (₹) *</label><input type="number" min={1} value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} className="bb-input" required /></div>
              <div><label className="bb-label">Date</label><input type="date" value={form.expenseDate} onChange={(e) => setForm({ ...form, expenseDate: e.target.value })} className="bb-input" /></div>
            </div>
            <div>
              <label className="bb-label">Payment Mode</label>
              <select value={form.paymentMode} onChange={(e) => setForm({ ...form, paymentMode: e.target.value })} className="bb-input">
                <option value="CASH">Cash</option>
                <option value="UPI">UPI</option>
                <option value="BANK_TRANSFER">Bank Transfer</option>
                <option value="CARD">Card</option>
              </select>
            </div>
            <div><label className="bb-label">Description</label><input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bb-input" placeholder="Bill or vendor note..." /></div>
            <div>
              <label className="bb-label">Attach Receipt (Optional)</label>
              <label className="bb-input flex items-center gap-2 cursor-pointer text-xs text-espresso-500">
                <Upload className="w-4 h-4 text-rosegold-500" />
                {form.receiptUrl ? "Receipt attached ✓" : "Upload image / PDF..."}
                <input type="file" accept="image/*,.pdf" onChange={handleUploadReceipt} className="hidden" />
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Save Expense</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
