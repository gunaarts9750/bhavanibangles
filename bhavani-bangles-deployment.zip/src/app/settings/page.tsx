"use client";

import React, { useEffect, useState } from "react";
import { Save, Palette, ReceiptText, Check, Languages, Printer } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { THEME_OPTIONS, ThemeId, applyTheme, getSavedTheme } from "@/lib/theme";
import { LANGUAGE_OPTIONS, useLanguage } from "@/lib/i18n";
import {
  PRINTER_PRESETS,
  PrinterConfig,
  PrinterPresetId,
  DEFAULT_PRINTER_CONFIG,
  getSavedPrinterConfig,
  savePrinterConfig,
  applyPresetToConfig,
  isThermalPreset,
  triggerConfiguredPrint,
} from "@/lib/printer";

interface SettingsData {
  shopName: string;
  shopTagline: string;
  address: string;
  phone: string;
  email: string;
  gstin: string;
  invoicePrefix: string;
  nextInvoiceNumber: number;
  defaultPrintFormat?: string;
  thankYouMessage: string;
  invoiceTerms: string;
}

export default function SettingsPage() {
  const { lang, setLang, t } = useLanguage();
  const [theme, setTheme] = useState<ThemeId>("rosegold");
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(DEFAULT_PRINTER_CONFIG);
  const [detectedPrinters, setDetectedPrinters] = useState<{ name: string; isDefault: boolean; isOnline: boolean }[]>([]);
  const [savingPrinter, setSavingPrinter] = useState(false);
  const [settings, setSettings] = useState<SettingsData>({
    shopName: "BHAVANI BANGLES",
    shopTagline: "",
    address: "",
    phone: "",
    email: "",
    gstin: "",
    invoicePrefix: "BB",
    nextInvoiceNumber: 1,
    defaultPrintFormat: "THERMAL_80",
    thankYouMessage: "Thank you for shopping at BHAVANI BANGLES!",
    invoiceTerms: "",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    setTheme(getSavedTheme());
    setPrinterConfig(getSavedPrinterConfig());
    fetch("/api/settings")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.settings) {
          setSettings((prev) => ({ ...prev, ...d.settings }));
          setPrinterConfig(getSavedPrinterConfig(d.settings.defaultPrintFormat));
        }
      })
      .finally(() => setLoading(false));

    fetch("/api/printers")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (Array.isArray(d?.printers)) {
          setDetectedPrinters(d.printers);
        }
      })
      .catch(() => {});
  }, []);

  const handleSelectPrinterPreset = (preset: PrinterPresetId) => {
    const next = applyPresetToConfig(printerConfig, preset);
    setPrinterConfig(next);
  };

  const handleSavePrinterSettings = async () => {
    setSavingPrinter(true);
    setMsg("");
    try {
      savePrinterConfig(printerConfig);
      if (printerConfig.printerLabel) {
        sessionStorage.setItem("bb_pos_printer_v1", printerConfig.printerLabel);
      }
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...settings,
          defaultPrintFormat: printerConfig.preset,
        }),
      });
      if (res.ok) {
        const d = await res.json();
        if (d?.settings) {
          setSettings((prev) => ({ ...prev, ...d.settings }));
          sessionStorage.setItem("bb_pos_shop_v1", JSON.stringify(d.settings));
        }
      }
      setMsg(`Printer settings saved (${printerConfig.paperWidthMm}mm, ${printerConfig.fontSizePx}px font)!`);
    } finally {
      setSavingPrinter(false);
    }
  };

  const handleTestPrint = () => {
    savePrinterConfig(printerConfig);
    triggerConfiguredPrint(printerConfig);
  };

  const handleSelectTheme = (id: ThemeId) => {
    setTheme(id);
    applyTheme(id);
    const chosen = THEME_OPTIONS.find((t) => t.id === id);
    setMsg(`Theme switched to ${chosen?.name || id}!`);
  };

  const handleSaveBillDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg("");
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        const d = await res.json();
        if (d?.settings) {
          sessionStorage.setItem("bb_pos_shop_v1", JSON.stringify(d.settings));
        }
      }
      setMsg(res.ok ? "Bill details saved! New bills will use these updated details." : "Failed to save settings.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppShell
      title={t("settings.title")}
      subtitle={t("settings.subtitle")}
    >
      {msg && (
        <div className="mb-5 rounded-xl bg-blush-100 border border-rosegold-300 px-4 py-2.5 text-xs text-rosegold-800 font-medium flex items-center justify-between max-w-3xl">
          <span>{msg}</span>
          <button onClick={() => setMsg("")} className="underline ml-3">Dismiss</button>
        </div>
      )}

      <div className="space-y-6 max-w-3xl">
        {/* Language Switcher */}
        <div className="bb-card p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Languages className="w-4.5 h-4.5 text-rosegold-600" />
            <div>
              <h3 className="font-serif text-lg font-bold text-espresso-900">{t("settings.language")}</h3>
              <p className="text-xs text-espresso-500">{t("settings.languageHint")}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {LANGUAGE_OPTIONS.map((opt) => {
              const active = lang === opt.code;
              return (
                <button
                  key={opt.code}
                  type="button"
                  onClick={() => {
                    setLang(opt.code);
                    setMsg(`Language switched to ${opt.native} (${opt.label})!`);
                  }}
                  className={`flex items-center justify-between gap-2 p-3 rounded-xl border text-left transition-all ${
                    active
                      ? "border-rosegold-500 bg-blush-50 ring-2 ring-rosegold-200"
                      : "border-ivory-300 bg-white hover:bg-ivory-50"
                  }`}
                >
                  <div>
                    <p className="text-sm font-bold text-espresso-900">{opt.native}</p>
                    <p className="text-[11px] text-espresso-500">{opt.label}</p>
                  </div>
                  {active && <Check className="w-4 h-4 text-rosegold-600 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Theme / Color Switcher */}
        <div className="bb-card p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Palette className="w-4.5 h-4.5 text-rosegold-600" />
            <div>
              <h3 className="font-serif text-lg font-bold text-espresso-900">{t("settings.themeColor")}</h3>
              <p className="text-xs text-espresso-500">{t("settings.themeHint")}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {THEME_OPTIONS.map((t) => {
              const active = theme === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => handleSelectTheme(t.id)}
                  className={`flex items-center justify-between gap-3 p-3 rounded-xl border text-left transition-all ${
                    active
                      ? "border-rosegold-500 bg-blush-50 ring-2 ring-rosegold-200"
                      : "border-ivory-300 bg-white hover:bg-ivory-50"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className="w-7 h-7 rounded-full shrink-0 border border-black/10 shadow-xs flex items-center justify-center text-white"
                      style={{ backgroundColor: t.swatch }}
                    >
                      {active && <Check className="w-3.5 h-3.5" />}
                    </span>
                    <span className="text-xs font-semibold text-espresso-900 truncate">{t.name}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Printer & Paper Size Setup */}
        <div className="bb-card p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Printer className="w-4.5 h-4.5 text-rosegold-600" />
              <div>
                <h3 className="font-serif text-lg font-bold text-espresso-900">
                  Printer & Receipt Settings
                </h3>
                <p className="text-xs text-espresso-500">
                  Select your printer (58mm small thermal, 76mm, 80mm, A5, A4, or custom) and adjust paper width, margin & font size.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleTestPrint}
              className="bb-btn-secondary py-1.5 px-3 text-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Test Print
            </button>
          </div>

          {/* Printer Type Presets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {PRINTER_PRESETS.map((p) => {
              const active = printerConfig.preset === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectPrinterPreset(p.id)}
                  className={`flex items-start justify-between gap-2 p-3 rounded-xl border text-left transition-all ${
                    active
                      ? "border-rosegold-500 bg-blush-50 ring-2 ring-rosegold-200"
                      : "border-ivory-300 bg-white hover:bg-ivory-50"
                  }`}
                >
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-espresso-900">{p.name}</p>
                    <p className="text-[11px] text-espresso-500 mt-0.5 leading-snug">{p.subtitle}</p>
                  </div>
                  {active && <Check className="w-4 h-4 text-rosegold-600 shrink-0 mt-0.5" />}
                </button>
              );
            })}
          </div>

          {/* Connected Printer Selector + Fine-Tune Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
            {detectedPrinters.length > 0 ? (
              <div className="sm:col-span-2 lg:col-span-4">
                <label className="bb-label">Detected Printer (Optional)</label>
                <select
                  value={printerConfig.printerLabel}
                  onChange={(e) => setPrinterConfig({ ...printerConfig, printerLabel: e.target.value })}
                  className="bb-input"
                >
                  <option value="">Browser Default / Ask When Printing</option>
                  {detectedPrinters.map((dp) => (
                    <option key={dp.name} value={dp.name}>
                      {dp.name} {dp.isDefault ? "(System Default)" : ""} {dp.isOnline ? "" : "— Offline"}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="sm:col-span-2 lg:col-span-4">
                <label className="bb-label">Printer Label / Model (Optional)</label>
                <input
                  type="text"
                  value={printerConfig.printerLabel}
                  onChange={(e) => setPrinterConfig({ ...printerConfig, printerLabel: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. Epson TM-T82, Rugtek RP58, TVS RP3160, HP LaserJet"
                />
              </div>
            )}

            <div>
              <label className="bb-label">Paper Width (mm)</label>
              <input
                type="number"
                min={40}
                max={220}
                value={printerConfig.paperWidthMm}
                onChange={(e) =>
                  setPrinterConfig({
                    ...printerConfig,
                    paperWidthMm: Number(e.target.value) || 58,
                  })
                }
                className="bb-input"
              />
            </div>

            <div>
              <label className="bb-label">Margin (mm)</label>
              <input
                type="number"
                min={0}
                max={20}
                value={printerConfig.marginMm}
                onChange={(e) =>
                  setPrinterConfig({
                    ...printerConfig,
                    marginMm: Math.max(0, Number(e.target.value) || 0),
                  })
                }
                className="bb-input"
              />
            </div>

            <div>
              <label className="bb-label">Font Size (px)</label>
              <input
                type="number"
                min={8}
                max={18}
                value={printerConfig.fontSizePx}
                onChange={(e) =>
                  setPrinterConfig({
                    ...printerConfig,
                    fontSizePx: Number(e.target.value) || 10,
                  })
                }
                className="bb-input"
              />
            </div>

            <div>
              <label className="bb-label">Bottom Feed Lines</label>
              <input
                type="number"
                min={0}
                max={8}
                value={printerConfig.extraFeedLines}
                onChange={(e) =>
                  setPrinterConfig({
                    ...printerConfig,
                    extraFeedLines: Math.max(0, Number(e.target.value) || 0),
                  })
                }
                className="bb-input"
              />
            </div>
          </div>

          {/* Receipt Toggle Options */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1 text-xs">
            {(
              [
                ["autoPrint", "Auto-Print on Checkout"],
                ["showAddress", "Show Shop Address"],
                ["showGstin", "Show GSTIN on Bill"],
                ["showItemGst", "Show Item GST %"],
                ["showThankYou", "Show Thank You Note"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-ivory-200 bg-ivory-50/60 cursor-pointer select-none"
              >
                <input
                  type="checkbox"
                  checked={Boolean(printerConfig[key])}
                  onChange={(e) =>
                    setPrinterConfig({ ...printerConfig, [key]: e.target.checked })
                  }
                  className="rounded accent-rosegold-600 w-4 h-4"
                />
                <span className="font-medium text-espresso-800">{label}</span>
              </label>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={handleSavePrinterSettings}
              disabled={savingPrinter}
              className="bb-btn-primary px-6 py-2.5"
            >
              <Save className="w-4 h-4" />
              {savingPrinter ? "Saving..." : "Save Printer Settings"}
            </button>
            <span className="text-[11px] text-espresso-500">
              Active layout: <strong>{printerConfig.paperWidthMm}mm</strong> width •{" "}
              <strong>{printerConfig.marginMm}mm</strong> margin •{" "}
              <strong>{printerConfig.fontSizePx}px</strong> font (
              {isThermalPreset(printerConfig.preset, printerConfig.paperWidthMm)
                ? "Thermal Roll"
                : "Sheet Invoice"}
              )
            </span>
          </div>
        </div>

        {/* Editable Bill Details */}
        <form onSubmit={handleSaveBillDetails} className="bb-card p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ReceiptText className="w-4.5 h-4.5 text-rosegold-600" />
            <div>
              <h3 className="font-serif text-lg font-bold text-espresso-900">{t("settings.billDetails")}</h3>
              <p className="text-xs text-espresso-500">{t("settings.billHint")}</p>
            </div>
          </div>

          {loading ? (
            <p className="text-xs text-espresso-400 py-4">Loading settings...</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="bb-label">{t("settings.shopName")}</label>
                <input
                  type="text"
                  value={settings.shopName || ""}
                  onChange={(e) => setSettings({ ...settings, shopName: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. BHAVANI BANGLES"
                  required
                />
              </div>

              <div>
                <label className="bb-label">{t("settings.phone")}</label>
                <input
                  type="text"
                  value={settings.phone || ""}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. +91 98765 43210"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="bb-label">{t("settings.address")}</label>
                <textarea
                  rows={2}
                  value={settings.address || ""}
                  onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                  className="bb-input"
                  placeholder="Enter shop address to print on bill"
                />
              </div>

              <div>
                <label className="bb-label">{t("settings.gstin")}</label>
                <input
                  type="text"
                  value={settings.gstin || ""}
                  onChange={(e) => setSettings({ ...settings, gstin: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. 33AABCB1234F1Z5"
                />
              </div>

              <div>
                <label className="bb-label">{t("settings.billPrefix")}</label>
                <input
                  type="text"
                  value={settings.invoicePrefix || ""}
                  onChange={(e) => setSettings({ ...settings, invoicePrefix: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. BB"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="bb-label">{t("settings.thankYou")}</label>
                <input
                  type="text"
                  value={settings.thankYouMessage || ""}
                  onChange={(e) => setSettings({ ...settings, thankYouMessage: e.target.value })}
                  className="bb-input"
                  placeholder="e.g. Thank you for shopping! Visit again."
                />
              </div>

              <div className="sm:col-span-2 pt-2">
                <button type="submit" disabled={saving} className="bb-btn-primary px-6 py-2.5">
                  <Save className="w-4 h-4" />
                  {saving ? t("settings.saving") : t("settings.save")}
                </button>
              </div>
            </div>
          )}
        </form>
      </div>

      {/* Hidden Test Print Receipt matching selected printer size */}
      <div className="hidden print:block">
        <div
          id="printable-area"
          className="font-mono bg-white text-black"
          style={{
            width: isThermalPreset(printerConfig.preset, printerConfig.paperWidthMm)
              ? `${Math.max(36, printerConfig.paperWidthMm - printerConfig.marginMm * 2)}mm`
              : "100%",
            fontSize: `${printerConfig.fontSizePx}px`,
            lineHeight: 1.3,
          }}
        >
          <div className="text-center border-b border-dashed border-black pb-1.5 mb-1.5">
            <div className="font-bold" style={{ fontSize: `${printerConfig.fontSizePx + 2}px` }}>
              {settings.shopName || "BHAVANI BANGLES"}
            </div>
            {printerConfig.showAddress && settings.address && <div>{settings.address}</div>}
            {settings.phone && <div>Ph: {settings.phone}</div>}
            {printerConfig.showGstin && settings.gstin && <div>GSTIN: {settings.gstin}</div>}
          </div>
          <div className="flex justify-between border-b border-dashed border-black pb-1 mb-1">
            <span>TEST BILL</span>
            <span>{printerConfig.paperWidthMm}mm</span>
          </div>
          <div className="border-b border-dashed border-black pb-1 mb-1">
            <div className="font-semibold">Bridal Glass Bangles Set</div>
            <div className="flex justify-between">
              <span>2 x 250{printerConfig.showItemGst ? " (3%)" : ""}</span>
              <span>₹500.00</span>
            </div>
          </div>
          <div className="flex justify-between font-bold border-b border-dashed border-black pb-1 mb-1">
            <span>TOTAL</span>
            <span>₹515.00</span>
          </div>
          {printerConfig.showThankYou && (
            <div className="text-center pt-1">
              {settings.thankYouMessage || "Thank you! Visit again."}
            </div>
          )}
          {Array.from({ length: printerConfig.extraFeedLines }).map((_, i) => (
            <div key={i}>&nbsp;</div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
