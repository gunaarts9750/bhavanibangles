"use client";

import React, { useEffect, useState } from "react";
import { Plus, ArrowRightCircle, Download, Trash2, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { InvoiceModal } from "@/components/InvoiceModal";
import { formatCurrency, formatDate } from "@/lib/format";
import { exportTableToPDF, PrintableInvoiceData } from "@/lib/export";

interface Quotation {
  id: string;
  quotationNumber: string;
  customerName: string;
  customerPhone?: string | null;
  quotationDate: string;
  validUntil?: string | null;
  subtotal: number;
  discount: number;
  totalGst: number;
  grandTotal: number;
  status: string;
  items: { productName: string; productCode: string; quantity: number; unitPrice: number; total: number }[];
}

export default function QuotationsPage() {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; sellingPrice: number; gstPercent: number }[]>([]);
  const [customers, setCustomers] = useState<{ id: string; name: string; phone: string }[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [convertedInvoice, setConvertedInvoice] = useState<PrintableInvoiceData | null>(null);
  const [msg, setMsg] = useState("");

  const [customerId, setCustomerId] = useState("");
  const [customerName, setCustomerName] = useState("Bridal Estimate Client");
  const [discount, setDiscount] = useState(0);
  const [validUntil, setValidUntil] = useState("");
  const [items, setItems] = useState<{ productId: string; quantity: number; unitPrice: number }[]>([]);

  const loadAll = async () => {
    const [qRes, pRes, cRes] = await Promise.all([
      fetch("/api/quotations"),
      fetch("/api/products"),
      fetch("/api/customers"),
    ]);
    if (qRes.ok) setQuotations((await qRes.json()).quotations || []);
    if (pRes.ok) setProducts((await pRes.json()).products || []);
    if (cRes.ok) setCustomers((await cRes.json()).customers || []);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const cust = customers.find((c) => c.id === customerId);
    const res = await fetch("/api/quotations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerId: customerId || null,
        customerName: cust ? cust.name : customerName,
        customerPhone: cust?.phone || null,
        validUntil: validUntil || undefined,
        discount,
        items,
      }),
    });
    if (res.ok) {
      setModalOpen(false);
      setItems([]);
      setMsg("Quotation created. Stock is NOT deducted until converted to an invoice.");
      loadAll();
    }
  };

  const handleConvert = async (q: Quotation) => {
    if (!confirm(`Convert Quotation ${q.quotationNumber} into a confirmed Tax Invoice and deduct stock?`)) return;
    const res = await fetch(`/api/quotations/${q.id}/convert`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paymentMethod: "CASH" }),
    });
    const d = await res.json();
    if (res.ok && d.sale) {
      setConvertedInvoice(d.sale);
      loadAll();
    } else {
      setMsg(d.error || "Conversion failed");
    }
  };

  const downloadQuotePDF = (q: Quotation) => {
    exportTableToPDF({
      title: `QUOTATION ${q.quotationNumber}`,
      subtitle: `Customer: ${q.customerName} | Valid Until: ${formatDate(q.validUntil)} | Grand Total: Rs.${q.grandTotal}`,
      headers: ["Product", "Code", "Qty", "Rate", "Total"],
      rows: q.items.map((it) => [it.productName, it.productCode, it.quantity, `Rs.${it.unitPrice}`, `Rs.${it.total}`]),
      fileName: q.quotationNumber,
    });
  };

  return (
    <AppShell
      title="Quotation Management"
      subtitle="Prepare bridal & bulk estimates and convert approved quotes to live invoices"
      actions={
        <button
          onClick={() => {
            if (products[0]) setItems([{ productId: products[0].id, quantity: 1, unitPrice: products[0].sellingPrice }]);
            setModalOpen(true);
          }}
          className="bb-btn-primary py-2 px-3.5 text-xs"
        >
          <Plus className="w-4 h-4" /> Create Quotation
        </button>
      }
    >
      {msg && (
        <div className="mb-4 rounded-xl bg-blush-100 border border-rosegold-300 px-4 py-2.5 text-xs flex justify-between">
          <span>{msg}</span>
          <button onClick={() => setMsg("")} className="underline">Dismiss</button>
        </div>
      )}

      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                <th className="py-3 px-4 text-left">Quotation #</th>
                <th className="py-3 px-3 text-left">Customer</th>
                <th className="py-3 px-3 text-left">Date / Valid Till</th>
                <th className="py-3 px-3 text-left">Items</th>
                <th className="py-3 px-3 text-right">Estimate Total</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {quotations.map((q) => (
                <tr key={q.id}>
                  <td className="py-3 px-4 font-bold text-espresso-900">{q.quotationNumber}</td>
                  <td className="py-3 px-3 font-medium">{q.customerName}</td>
                  <td className="py-3 px-3 text-espresso-500">
                    {formatDate(q.quotationDate)} → {formatDate(q.validUntil)}
                  </td>
                  <td className="py-3 px-3 text-espresso-600">
                    {q.items.map((it) => `${it.productName} (x${it.quantity})`).join(", ")}
                  </td>
                  <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(q.grandTotal)}</td>
                  <td className="py-3 px-3 text-center">
                    <span className={q.status === "CONVERTED" ? "bb-badge-success" : "bb-badge-blush"}>{q.status}</span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button onClick={() => downloadQuotePDF(q)} className="bb-btn-secondary py-1 px-2.5 text-xs">
                        <Download className="w-3.5 h-3.5" /> PDF
                      </button>
                      {q.status !== "CONVERTED" && (
                        <button onClick={() => handleConvert(q)} className="bb-btn-primary py-1 px-2.5 text-xs">
                          <ArrowRightCircle className="w-3.5 h-3.5" /> Convert to Invoice
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleCreate} className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Create Price Quotation</h3>
              <button type="button" onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="bb-label">Customer</label>
                <select value={customerId} onChange={(e) => setCustomerId(e.target.value)} className="bb-input">
                  <option value="">Custom / Walk-in</option>
                  {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              {!customerId && (
                <div>
                  <label className="bb-label">Client Name</label>
                  <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="bb-input" />
                </div>
              )}
              <div>
                <label className="bb-label">Valid Until</label>
                <input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className="bb-input" />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="bb-label mb-0">Quoted Products</label>
                <button
                  type="button"
                  onClick={() =>
                    products[0] &&
                    setItems((prev) => [...prev, { productId: products[0].id, quantity: 1, unitPrice: products[0].sellingPrice }])
                  }
                  className="text-xs font-semibold text-rosegold-600 hover:underline"
                >
                  + Add Item
                </button>
              </div>
              {items.map((row, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                  <select
                    value={row.productId}
                    onChange={(e) => {
                      const pr = products.find((x) => x.id === e.target.value);
                      setItems((prev) =>
                        prev.map((x, i) => (i === idx ? { ...x, productId: e.target.value, unitPrice: pr?.sellingPrice || 0 } : x))
                      );
                    }}
                    className="col-span-6 bb-input py-1.5 text-xs"
                  >
                    {products.map((pr) => <option key={pr.id} value={pr.id}>{pr.name}</option>)}
                  </select>
                  <input
                    type="number"
                    min={1}
                    value={row.quantity}
                    onChange={(e) => setItems((prev) => prev.map((x, i) => (i === idx ? { ...x, quantity: Number(e.target.value) } : x)))}
                    className="col-span-2 bb-input py-1.5 text-xs"
                  />
                  <input
                    type="number"
                    value={row.unitPrice}
                    onChange={(e) => setItems((prev) => prev.map((x, i) => (i === idx ? { ...x, unitPrice: Number(e.target.value) } : x)))}
                    className="col-span-3 bb-input py-1.5 text-xs"
                  />
                  <button type="button" onClick={() => setItems((prev) => prev.filter((_, i) => i !== idx))} className="col-span-1 text-rose-500 flex justify-center">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="w-44">
              <label className="bb-label">Quotation Discount (₹)</label>
              <input type="number" min={0} value={discount} onChange={(e) => setDiscount(Number(e.target.value))} className="bb-input" />
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setModalOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Save Quotation</button>
            </div>
          </form>
        </div>
      )}

      {convertedInvoice && <InvoiceModal invoice={convertedInvoice} onClose={() => setConvertedInvoice(null)} />}
    </AppShell>
  );
}
