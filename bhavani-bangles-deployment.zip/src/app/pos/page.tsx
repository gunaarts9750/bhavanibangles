"use client";

import React, { useEffect, useState, useRef, useMemo } from "react";
import {
  Barcode,
  Plus,
  Minus,
  Trash2,
  CreditCard,
  Banknote,
  Smartphone,
  Building2,
  Split,
  Clock,
  CheckCircle2,
  Zap,
  Wifi,
  WifiOff,
  RefreshCw,
  Printer,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency } from "@/lib/format";
import { PrintableInvoiceData, ShopSettingData } from "@/lib/export";
import { useLanguage } from "@/lib/i18n";
import {
  PrinterConfig,
  DEFAULT_PRINTER_CONFIG,
  getSavedPrinterConfig,
  isThermalPreset,
  triggerConfiguredPrint,
} from "@/lib/printer";
import {
  savePosCache,
  loadPosCache,
  getOfflineQueue,
  enqueueOfflineBill,
  generateOfflineInvoiceNumber,
  syncOfflineQueue,
  OfflineQueuedBill,
} from "@/lib/offline";

interface Product {
  id: string;
  name: string;
  code: string;
  barcode: string;
  unit: string;
  sellingPrice: number;
  gstPercent: number;
}

interface CartItem {
  key: string;
  productId: string | null;
  productName: string;
  productCode: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  gstPercent: number;
}

function computeTotals(
  items: CartItem[],
  billDiscount: number,
  gstType: "NONE" | "CGST_SGST" | "IGST",
  enableRoundOff: boolean
) {
  let subtotal = 0;
  let itemDiscount = 0;
  let totalGst = 0;

  for (const c of items) {
    const base = c.unitPrice * c.quantity;
    const taxable = Math.max(0, base - c.discount);
    const gst = gstType === "NONE" ? 0 : (taxable * c.gstPercent) / 100;
    subtotal += base;
    itemDiscount += c.discount;
    totalGst += gst;
  }

  const raw = Math.max(0, subtotal - itemDiscount - billDiscount + totalGst);
  const grandTotal = enableRoundOff ? Math.round(raw) : Number(raw.toFixed(2));
  const roundOff = Number((grandTotal - raw).toFixed(2));

  return {
    subtotal: Number(subtotal.toFixed(2)),
    itemDiscount: Number(itemDiscount.toFixed(2)),
    totalGst: Number(totalGst.toFixed(2)),
    roundOff,
    grandTotal,
  };
}

export default function PosBillingPage() {
  const { t } = useLanguage();
  const [products, setProducts] = useState<Product[]>([]);
  const [shop, setShop] = useState<ShopSettingData>({
    shopName: "BHAVANI BANGLES",
    shopTagline: "Exquisite Bangles & Bridal Jewellery",
    address: "",
    phone: "",
    gstin: "",
    invoiceTerms: "",
    thankYouMessage: "Thank you for shopping at BHAVANI BANGLES!",
  });

  // Quick Direct Entry (Code/Barcode + Qty + Price -> Enter = Instant Bill & Print!)
  const [quickCode, setQuickCode] = useState("");
  const [quickQty, setQuickQty] = useState("");
  const [quickPrice, setQuickPrice] = useState("");

  const [cart, setCart] = useState<CartItem[]>([]);
  const [billDiscount, setBillDiscount] = useState(0);
  const [gstType, setGstType] = useState<"NONE" | "CGST_SGST" | "IGST">("NONE");
  const [enableRoundOff, setEnableRoundOff] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState<"CASH" | "UPI" | "CARD" | "BANK_TRANSFER" | "SPLIT" | "CREDIT">("CASH");
  const [paidAmountInput, setPaidAmountInput] = useState<string>("");
  const [splitPayments, setSplitPayments] = useState<{ method: string; amount: number }[]>([
    { method: "CASH", amount: 0 },
    { method: "UPI", amount: 0 },
  ]);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [statusMsg, setStatusMsg] = useState("");
  const [printInvoice, setPrintInvoice] = useState<PrintableInvoiceData | null>(null);

  // Offline Billing Mode & Sync Queue
  const [offlineMode, setOfflineMode] = useState(false);
  const [offlineQueue, setOfflineQueue] = useState<OfflineQueuedBill[]>([]);
  const [syncing, setSyncing] = useState(false);

  // Connected Printer Detection & Instant Auto-Print on Enter
  const [defaultPrinter, setDefaultPrinter] = useState<string | null>(null);
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(DEFAULT_PRINTER_CONFIG);
  const [autoPrint, setAutoPrint] = useState(true);

  const quickCodeRef = useRef<HTMLInputElement>(null);
  const quickPriceRef = useRef<HTMLInputElement>(null);

  const loadPosData = async () => {
    try {
      const pRes = await fetch("/api/products");
      const nextProducts = pRes.ok ? (await pRes.json()).products || [] : [];
      setProducts(nextProducts);
      savePosCache({ products: nextProducts, categories: [], customers: [] });
      sessionStorage.setItem("bb_pos_products_v1", JSON.stringify(nextProducts));
    } catch {
      const cached = loadPosCache<{ products: Product[]; categories: unknown[]; customers: unknown[] }>();
      if (cached) {
        setProducts(cached.products || []);
      }
      setOfflineMode(true);
    }
  };

  const handleSyncOffline = async () => {
    if (syncing) return;
    setSyncing(true);
    setError("");
    try {
      const res = await syncOfflineQueue();
      setOfflineQueue(res.remaining);
      if (res.synced > 0) {
        setStatusMsg(`Synced ${res.synced} offline bill(s) to the database successfully.`);
        await loadPosData();
      } else if (res.failed > 0) {
        setError(`Could not sync ${res.failed} bill(s). Server may still be offline.`);
      }
    } finally {
      setSyncing(false);
    }
  };

  useEffect(() => {
    setOfflineQueue(getOfflineQueue());
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      setOfflineMode(true);
    }
    quickCodeRef.current?.focus();

    // Use lightweight session cache to avoid redundant API calls & save mobile data
    const cachedProducts = sessionStorage.getItem("bb_pos_products_v1");
    if (cachedProducts) {
      try {
        setProducts(JSON.parse(cachedProducts));
      } catch {
        loadPosData();
      }
    } else {
      loadPosData();
    }

    const cachedShop = sessionStorage.getItem("bb_pos_shop_v1");
    if (cachedShop) {
      try {
        setShop(JSON.parse(cachedShop));
      } catch {
        // fallback below
      }
    } else {
      fetch("/api/settings")
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (d?.settings) {
            setShop(d.settings);
            sessionStorage.setItem("bb_pos_shop_v1", JSON.stringify(d.settings));
          }
        })
        .catch(() => {});
    }

    const cachedPrinter = sessionStorage.getItem("bb_pos_printer_v1");
    if (cachedPrinter !== null) {
      setDefaultPrinter(cachedPrinter || null);
    } else {
      fetch("/api/printers")
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          const p = d?.defaultPrinter || "";
          setDefaultPrinter(p || null);
          sessionStorage.setItem("bb_pos_printer_v1", p);
        })
        .catch(() => {});
    }

    const onOnline = () => {
      setOfflineMode(false);
      if (getOfflineQueue().length > 0) {
        handleSyncOffline();
      }
    };
    const onOffline = () => setOfflineMode(true);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "F4") {
        e.preventDefault();
        quickCodeRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Trigger direct print: tries local Windows silent print first, then falls back to configured browser print (USB/Bluetooth 58mm/80mm/A4)
  const triggerDirectPrint = async (invoice: PrintableInvoiceData) => {
    const activeCfg = getSavedPrinterConfig();
    setPrinterConfig(activeCfg);
    setPrintInvoice(invoice);
    quickCodeRef.current?.focus();
    if (!autoPrint) return;

    try {
      const res = await fetch("/api/printers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          invoice,
          shop,
          printerName: activeCfg.printerLabel || defaultPrinter,
          paperWidthMm: activeCfg.paperWidthMm,
        }),
      });
      const data = await res.json();
      if (data?.printed) {
        setStatusMsg(`Bill ${invoice.invoiceNumber} printed to ${data.printer} • ${formatCurrency(invoice.grandTotal)}`);
        return;
      }
    } catch {
      // Fallback to browser print for cloud-hosted / USB / Bluetooth thermal printers
    }

    setTimeout(() => {
      triggerConfiguredPrint(activeCfg);
    }, 120);
  };

  const buildItemFromQuickInput = (existingCart: CartItem[]): CartItem | null => {
    const code = quickCode.trim();
    const qty = quickQty.trim() !== "" ? Math.max(1, Number(quickQty)) : 1;
    const enteredPrice = quickPrice.trim() !== "" ? Number(quickPrice) : undefined;

    const matched = code
      ? products.find((p) => p.barcode === code || p.code.toLowerCase() === code.toLowerCase())
      : undefined;

    if (matched) {
      const rate = enteredPrice !== undefined && !Number.isNaN(enteredPrice) ? enteredPrice : matched.sellingPrice;
      return {
        key: `${matched.id}-${Date.now()}`,
        productId: matched.id,
        productName: matched.name,
        productCode: matched.code,
        unit: matched.unit,
        quantity: qty,
        unitPrice: rate,
        discount: 0,
        gstPercent: matched.gstPercent,
      };
    }

    if (enteredPrice === undefined || Number.isNaN(enteredPrice) || enteredPrice <= 0) {
      return null;
    }

    const displayCode = code || String(existingCart.length + 1);
    return {
      key: `direct-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      productId: null,
      productName: `Item #${displayCode}`,
      productCode: displayCode,
      unit: "Pcs",
      quantity: qty,
      unitPrice: enteredPrice,
      discount: 0,
      gstPercent: 0,
    };
  };

  const mergeIntoCart = (baseCart: CartItem[], item: CartItem): CartItem[] => {
    if (item.productId) {
      const existing = baseCart.find((c) => c.productId === item.productId && c.unitPrice === item.unitPrice);
      if (existing) {
        return baseCart.map((c) =>
          c.key === existing.key ? { ...c, quantity: c.quantity + item.quantity } : c
        );
      }
    }
    return [...baseCart, item];
  };

  const clearQuickInputs = () => {
    setQuickCode("");
    setQuickQty("");
    setQuickPrice("");
  };

  // Optional: Add item to list without printing yet (for multi-item bills)
  const handleAddToCartOnly = () => {
    setError("");
    const newItem = buildItemFromQuickInput(cart);
    if (!newItem) {
      quickPriceRef.current?.focus();
      return;
    }
    setCart((prev) => mergeIntoCart(prev, newItem));
    clearQuickInputs();
    quickCodeRef.current?.focus();
  };

  // Pressing Enter: immediately bills & prints directly (zero modal/preview page!)
  const handleQuickBillSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setError("");

    const newItem = buildItemFromQuickInput(cart);
    const itemsToBill = newItem ? mergeIntoCart(cart, newItem) : cart;

    if (itemsToBill.length === 0) {
      quickPriceRef.current?.focus();
      return;
    }

    clearQuickInputs();
    await handleCheckout(itemsToBill);
  };

  const updateCartItem = (key: string, patch: Partial<CartItem>) => {
    setCart((prev) =>
      prev
        .map((c) => (c.key === key ? { ...c, ...patch } : c))
        .filter((c) => c.quantity > 0)
    );
  };

  const totals = useMemo(
    () => computeTotals(cart, billDiscount, gstType, enableRoundOff),
    [cart, billDiscount, gstType, enableRoundOff]
  );

  const handleCheckout = async (overrideItems?: CartItem[]) => {
    const billItems = overrideItems ?? cart;
    if (billItems.length === 0) {
      setError("Add at least one item to generate a bill.");
      return;
    }
    setError("");
    setSubmitting(true);

    const billTotals = computeTotals(billItems, billDiscount, gstType, enableRoundOff);

    try {
      const payload: Record<string, unknown> = {
        customerId: null,
        customerName: "Walk-in Customer",
        customerPhone: "",
        items: billItems.map((c) => ({
          productId: c.productId,
          productCode: c.productCode,
          productName: c.productName,
          unit: c.unit,
          quantity: c.quantity,
          unitPrice: c.unitPrice,
          discount: c.discount,
          gstPercent: c.gstPercent,
        })),
        billDiscount,
        gstType,
        enableRoundOff,
        paymentMethod,
        advanceUsed: 0,
      };

      if (paymentMethod === "SPLIT") {
        payload.payments = splitPayments.filter((p) => p.amount > 0);
      } else if (paymentMethod === "CREDIT") {
        payload.paidAmount = paidAmountInput !== "" ? Number(paidAmountInput) : 0;
      } else {
        payload.paidAmount = paidAmountInput !== "" ? Number(paidAmountInput) : billTotals.grandTotal;
      }

      const saveLocallyAndPrint = () => {
        const offlineInvNo = generateOfflineInvoiceNumber();
        const paidAmt =
          paymentMethod === "SPLIT"
            ? splitPayments.reduce((s, p) => s + Number(p.amount || 0), 0)
            : Number(payload.paidAmount ?? billTotals.grandTotal);
        const balDue = Math.max(0, Number((billTotals.grandTotal - paidAmt).toFixed(2)));

        const previewInvoice: PrintableInvoiceData = {
          invoiceNumber: offlineInvNo,
          saleDate: new Date().toISOString(),
          customerName: "Walk-in Customer",
          customerPhone: null,
          subtotal: billTotals.subtotal,
          itemDiscount: billTotals.itemDiscount,
          billDiscount,
          gstType,
          cgstAmount: gstType === "CGST_SGST" ? Number((billTotals.totalGst / 2).toFixed(2)) : 0,
          sgstAmount: gstType === "CGST_SGST" ? Number((billTotals.totalGst / 2).toFixed(2)) : 0,
          igstAmount: gstType === "IGST" ? billTotals.totalGst : 0,
          totalGst: billTotals.totalGst,
          roundOff: billTotals.roundOff,
          grandTotal: billTotals.grandTotal,
          paidAmount: paidAmt,
          balanceDue: balDue,
          paymentMethod,
          paymentStatus: balDue <= 0 ? "PAID" : paidAmt > 0 ? "PARTIAL" : "DUE",
          items: billItems.map((c) => {
            const base = c.unitPrice * c.quantity;
            const taxable = Math.max(0, base - c.discount);
            const gstAmt = gstType === "NONE" ? 0 : Number(((taxable * c.gstPercent) / 100).toFixed(2));
            return {
              productName: c.productName,
              productCode: c.productCode,
              hsnCode: null,
              unit: c.unit,
              quantity: c.quantity,
              unitPrice: c.unitPrice,
              discount: c.discount,
              gstPercent: gstType === "NONE" ? 0 : c.gstPercent,
              gstAmount: gstAmt,
              total: Number((taxable + gstAmt).toFixed(2)),
            };
          }),
        };

        const updatedQueue = enqueueOfflineBill({
          offlineId: offlineInvNo,
          createdAt: new Date().toISOString(),
          payload,
          previewInvoice,
        });
        setOfflineQueue(updatedQueue);
        setStatusMsg(`Bill ${offlineInvNo} saved offline • ${formatCurrency(billTotals.grandTotal)}`);
        setCart([]);
        setBillDiscount(0);
        setPaidAmountInput("");
        triggerDirectPrint(previewInvoice);
      };

      if (offlineMode || (typeof navigator !== "undefined" && !navigator.onLine)) {
        saveLocallyAndPrint();
        return;
      }

      try {
        const res = await fetch("/api/sales", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Could not complete invoice");
          return;
        }

        setStatusMsg(`Bill ${data.sale.invoiceNumber} generated • ${formatCurrency(data.sale.grandTotal)}`);
        setCart([]);
        setBillDiscount(0);
        setPaidAmountInput("");
        triggerDirectPrint(data.sale);
      } catch {
        setOfflineMode(true);
        saveLocallyAndPrint();
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppShell
      title={t("pos.title")}
      subtitle={t("pos.subtitle")}
      actions={
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setAutoPrint((prev) => !prev)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
              autoPrint
                ? "bg-blush-200 border-rosegold-300 text-rosegold-800"
                : "bg-white border-ivory-300 text-espresso-600"
            }`}
            title={defaultPrinter ? `Connected Printer: ${defaultPrinter}` : "Auto-Print on Enter"}
          >
            <Printer className="w-3.5 h-3.5" />
            {autoPrint ? (defaultPrinter ? `Auto-Print: ${defaultPrinter.slice(0, 18)}` : t("pos.autoPrintOn")) : t("pos.autoPrintOff")}
          </button>
          <button
            type="button"
            onClick={() => setOfflineMode((prev) => !prev)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
              offlineMode
                ? "bg-amber-50 border-amber-300 text-amber-800"
                : "bg-emerald-50 border-emerald-200 text-emerald-700"
            }`}
            title="Toggle Offline Billing Mode"
          >
            {offlineMode ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            {offlineMode ? t("pos.offlineMode") : t("pos.onlineMode")}
          </button>
          {offlineQueue.length > 0 && (
            <button
              type="button"
              onClick={handleSyncOffline}
              disabled={syncing}
              className="bb-btn-gold py-1.5 px-3 text-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? "animate-spin" : ""}`} />
              Sync ({offlineQueue.length})
            </button>
          )}
        </div>
      }
    >
      {statusMsg && (
        <div className="mb-4 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-xs text-emerald-800 font-medium flex items-center justify-between no-print">
          <span>{statusMsg}</span>
          <button onClick={() => setStatusMsg("")} className="underline ml-3">Dismiss</button>
        </div>
      )}

      {offlineQueue.length > 0 && (
        <div className="mb-4 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3 text-xs text-amber-900 flex flex-wrap items-center justify-between gap-2 no-print">
          <div>
            <p className="font-bold">
              {offlineQueue.length} Offline Bill(s) Saved Locally — Ready to Sync
            </p>
            <p className="text-[11px] opacity-85">
              You can keep billing &amp; printing offline. Click Sync Now once connected to save them into the main database.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => triggerDirectPrint(offlineQueue[0].previewInvoice)}
              className="bb-btn-secondary py-1.5 px-3 text-xs"
            >
              Reprint Last Offline Bill
            </button>
            <button
              type="button"
              onClick={handleSyncOffline}
              disabled={syncing}
              className="bb-btn-primary py-1.5 px-3 text-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? "animate-spin" : ""}`} />
              {syncing ? "Syncing..." : "Sync All Now"}
            </button>
          </div>
        </div>
      )}

      {error && (
        <div className="mb-4 rounded-xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-xs text-rose-700 font-medium flex items-center justify-between no-print">
          <span>{error}</span>
          <button onClick={() => setError("")} className="underline ml-3">Dismiss</button>
        </div>
      )}

      {/* QUICK DIRECT BILLING BAR (Code/Barcode + Qty + Price -> Enter = Direct Bill & Print!) */}
      <form
        onSubmit={handleQuickBillSubmit}
        className="bb-card p-5 mb-5 border-rosegold-300 bg-gradient-to-r from-white via-blush-50/50 to-white no-print"
      >
        <div className="flex items-center gap-2 mb-3">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-rosegold-700">
            <Zap className="w-4 h-4 text-rosegold-500" /> {t("pos.quickEntry")}
          </span>
          <span className="text-[11px] text-espresso-400">
            {t("pos.quickHint")}
          </span>
        </div>
        <div className="grid grid-cols-12 gap-3 items-end">
          <div className="col-span-12 sm:col-span-4">
            <label className="bb-label">{t("pos.code")}</label>
            <div className="relative">
              <Barcode className="w-4 h-4 text-rosegold-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={quickCodeRef}
                type="text"
                autoComplete="off"
                value={quickCode}
                onChange={(e) => setQuickCode(e.target.value)}
                placeholder={t("pos.codePlaceholder")}
                className="bb-input pl-9 bg-white"
              />
            </div>
          </div>
          <div className="col-span-4 sm:col-span-2">
            <label className="bb-label">{t("pos.qty")}</label>
            <input
              type="number"
              min={1}
              autoComplete="off"
              value={quickQty}
              onChange={(e) => setQuickQty(e.target.value)}
              placeholder={t("pos.qty")}
              className="bb-input bg-white text-center font-semibold"
            />
          </div>
          <div className="col-span-8 sm:col-span-3">
            <label className="bb-label">{t("pos.price")}</label>
            <input
              ref={quickPriceRef}
              type="number"
              autoComplete="off"
              step="0.01"
              min={0}
              value={quickPrice}
              onChange={(e) => setQuickPrice(e.target.value)}
              placeholder={t("pos.pricePlaceholder")}
              className="bb-input bg-white font-bold text-espresso-900"
            />
          </div>
          <div className="col-span-12 sm:col-span-3 flex gap-2">
            <button
              type="button"
              onClick={handleAddToCartOnly}
              className="bb-btn-secondary px-3 py-2.5 shrink-0"
              title="Add item to bill without printing yet"
            >
              <Plus className="w-4 h-4" /> {t("pos.add")}
            </button>
            <button type="submit" disabled={submitting} className="bb-btn-primary flex-1 py-2.5">
              <Printer className="w-4 h-4" /> {submitting ? t("pos.billing") : t("pos.billEnter")}
            </button>
          </div>
        </div>
      </form>

      {/* Billing Cart, Totals & Payment */}
      <div className="bb-card p-5 space-y-4 max-w-3xl no-print">
        {/* Cart Items (shown when multiple items are queued) */}
        {cart.length > 0 && (
          <div className="max-h-60 overflow-y-auto divide-y divide-ivory-200 pr-1 border-b border-ivory-200 pb-3">
            {cart.map((c) => (
              <div key={c.key} className="py-2.5 space-y-1.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-espresso-900 truncate">{c.productName}</p>
                    <p className="text-[10px] text-espresso-400">Code: {c.productCode}</p>
                  </div>
                  <button
                    onClick={() => updateCartItem(c.key, { quantity: 0 })}
                    className="text-espresso-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => updateCartItem(c.key, { quantity: c.quantity - 1 })}
                      className="w-6 h-6 rounded-lg bg-ivory-200 flex items-center justify-center hover:bg-rosegold-100"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-7 text-center font-bold tabular-nums">{c.quantity}</span>
                    <button
                      onClick={() => updateCartItem(c.key, { quantity: c.quantity + 1 })}
                      className="w-6 h-6 rounded-lg bg-ivory-200 flex items-center justify-center hover:bg-rosegold-100"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={c.unitPrice}
                      onChange={(e) => updateCartItem(c.key, { unitPrice: Number(e.target.value) })}
                      title="Unit Price ₹"
                      className="w-20 bb-input py-1 px-2 text-xs text-right tabular-nums"
                    />
                    <input
                      type="number"
                      min={0}
                      value={c.discount}
                      onChange={(e) => updateCartItem(c.key, { discount: Number(e.target.value) })}
                      placeholder="Disc ₹"
                      title="Discount ₹"
                      className="w-16 bb-input py-1 px-2 text-xs text-right tabular-nums"
                    />
                    <span className="w-20 text-right font-bold tabular-nums text-espresso-900">
                      {formatCurrency(Math.max(0, c.unitPrice * c.quantity - c.discount))}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Discounts, Tax Mode & Totals */}
        <div className="space-y-2 text-xs">
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] font-bold uppercase text-espresso-400">{t("pos.billDiscount")}</label>
              <input
                type="number"
                min={0}
                value={billDiscount}
                onChange={(e) => setBillDiscount(Number(e.target.value))}
                className="bb-input py-1.5 text-xs mt-0.5"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase text-espresso-400">{t("pos.taxMode")}</label>
              <select
                value={gstType}
                onChange={(e) => setGstType(e.target.value as "NONE" | "CGST_SGST" | "IGST")}
                className="bb-input py-1.5 text-xs mt-0.5"
              >
                <option value="NONE">{t("pos.noGst")}</option>
                <option value="CGST_SGST">CGST + SGST</option>
                <option value="IGST">IGST</option>
              </select>
            </div>
            <div className="flex items-end pb-1.5">
              <label className="flex items-center gap-1.5 cursor-pointer text-xs text-espresso-700 font-medium">
                <input
                  type="checkbox"
                  checked={enableRoundOff}
                  onChange={(e) => setEnableRoundOff(e.target.checked)}
                  className="rounded accent-rosegold-500"
                />
                {t("pos.roundOff")}
              </label>
            </div>
          </div>

          {cart.length > 0 && (
            <div className="bg-ivory-50 rounded-xl p-3 space-y-1 border border-ivory-200">
              <div className="flex justify-between text-espresso-600">
                <span>{t("pos.subtotal")} ({cart.reduce((s, c) => s + c.quantity, 0)})</span>
                <span className="tabular-nums font-medium">{formatCurrency(totals.subtotal)}</span>
              </div>
              {totals.itemDiscount + billDiscount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>{t("pos.totalDiscount")}</span>
                  <span className="tabular-nums">-{formatCurrency(totals.itemDiscount + billDiscount)}</span>
                </div>
              )}
              {totals.totalGst > 0 && (
                <div className="flex justify-between text-espresso-600">
                  <span>{gstType === "IGST" ? "IGST" : "CGST + SGST"}</span>
                  <span className="tabular-nums">{formatCurrency(totals.totalGst)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-rosegold-700 pt-1.5 border-t border-ivory-300">
                <span>{t("pos.grandTotal")}</span>
                <span className="tabular-nums">{formatCurrency(totals.grandTotal)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Payment Method Selector */}
        <div className="space-y-2.5">
          <label className="bb-label mb-0">{t("pos.paymentMode")}</label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
            {[
              { id: "CASH", label: t("pos.cash"), icon: Banknote },
              { id: "UPI", label: t("pos.upi"), icon: Smartphone },
              { id: "CARD", label: t("pos.card"), icon: CreditCard },
              { id: "BANK_TRANSFER", label: t("pos.bank"), icon: Building2 },
              { id: "SPLIT", label: t("pos.split"), icon: Split },
              { id: "CREDIT", label: t("pos.due"), icon: Clock },
            ].map((m) => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id as typeof paymentMethod)}
                  className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    paymentMethod === m.id
                      ? "bg-rosegold-500 text-white border-rosegold-500"
                      : "bg-white text-espresso-700 border-ivory-300 hover:bg-ivory-100"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" /> {m.label}
                </button>
              );
            })}
          </div>

          {paymentMethod === "SPLIT" && (
            <div className="space-y-1.5 bg-ivory-50 p-2.5 rounded-xl border border-ivory-200">
              {splitPayments.map((sp, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <select
                    value={sp.method}
                    onChange={(e) =>
                      setSplitPayments((prev) =>
                        prev.map((x, i) => (i === idx ? { ...x, method: e.target.value } : x))
                      )
                    }
                    className="bb-input py-1.5 text-xs w-28"
                  >
                    <option value="CASH">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="CARD">Card</option>
                    <option value="BANK_TRANSFER">Bank</option>
                  </select>
                  <input
                    type="number"
                    min={0}
                    value={sp.amount}
                    onChange={(e) =>
                      setSplitPayments((prev) =>
                        prev.map((x, i) => (i === idx ? { ...x, amount: Number(e.target.value) } : x))
                      )
                    }
                    placeholder="Amount ₹"
                    className="bb-input py-1.5 text-xs"
                  />
                </div>
              ))}
            </div>
          )}

          {cart.length > 0 && (
            <button
              type="button"
              onClick={() => handleCheckout()}
              disabled={submitting}
              className="bb-btn-primary w-full py-3.5 text-sm font-bold shadow-card"
            >
              <CheckCircle2 className="w-4 h-4" />
              {submitting ? "Generating Bill..." : `Confirm & Print Bill • ${formatCurrency(totals.grandTotal)}`}
            </button>
          )}
        </div>
      </div>

      {/* Hidden Receipt Area — dynamically adapts to 58mm small thermal, 76mm, 80mm, A5, A4, or Custom */}
      {printInvoice && (
        <div className="hidden print:block">
          <div
            id="printable-area"
            className="font-mono bg-white text-black"
            style={{
              width: isThermalPreset(printerConfig.preset, printerConfig.paperWidthMm)
                ? `${Math.max(36, printerConfig.paperWidthMm - printerConfig.marginMm * 2)}mm`
                : "100%",
              fontSize: `${printerConfig.fontSizePx}px`,
              lineHeight: 1.3,
            }}
          >
            <div className="space-y-1.5">
              <div className="text-center border-b border-dashed border-black pb-1.5">
                <p className="font-bold" style={{ fontSize: `${printerConfig.fontSizePx + 2}px` }}>
                  {shop.shopName}
                </p>
                {printerConfig.showAddress && shop.address && <p>{shop.address}</p>}
                {shop.phone && <p>Ph: {shop.phone}</p>}
                {printerConfig.showGstin && shop.gstin && <p>GSTIN: {shop.gstin}</p>}
              </div>
              <div className="border-b border-dashed border-black pb-1">
                <div className="flex justify-between">
                  <span>Inv: {printInvoice.invoiceNumber}</span>
                  <span>{new Date(printInvoice.saleDate).toLocaleDateString("en-IN")}</span>
                </div>
              </div>
              <div className="border-b border-dashed border-black pb-1 space-y-1">
                {printInvoice.items.map((it, idx) => (
                  <div key={idx}>
                    <div className="font-semibold break-words">{it.productName}</div>
                    <div className="flex justify-between">
                      <span>
                        {it.quantity} x {it.unitPrice.toFixed(0)}
                        {printerConfig.showItemGst && it.gstPercent > 0 ? ` (${it.gstPercent}%)` : ""}
                      </span>
                      <span className="font-semibold">{formatCurrency(it.total)}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="space-y-0.5">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{formatCurrency(printInvoice.subtotal)}</span>
                </div>
                {printInvoice.totalGst > 0 && (
                  <div className="flex justify-between">
                    <span>GST</span>
                    <span>{formatCurrency(printInvoice.totalGst)}</span>
                  </div>
                )}
                <div
                  className="flex justify-between font-bold border-t border-dashed border-black pt-1"
                  style={{ fontSize: `${printerConfig.fontSizePx + 1}px` }}
                >
                  <span>TOTAL</span>
                  <span>{formatCurrency(printInvoice.grandTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Paid ({printInvoice.paymentMethod})</span>
                  <span>{formatCurrency(printInvoice.paidAmount)}</span>
                </div>
              </div>
              {printerConfig.showThankYou && shop.thankYouMessage && (
                <p className="text-center pt-1.5 border-t border-dashed border-black">
                  {shop.thankYouMessage}
                </p>
              )}
              {Array.from({ length: printerConfig.extraFeedLines }).map((_, i) => (
                <div key={i}>&nbsp;</div>
              ))}
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
