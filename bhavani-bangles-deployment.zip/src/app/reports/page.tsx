"use client";

import React, { useEffect, useState } from "react";
import { Download, FileSpreadsheet, RotateCcw } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency } from "@/lib/format";
import { exportToExcel, exportTableToPDF } from "@/lib/export";
import { useLanguage } from "@/lib/i18n";

const REPORT_TABS = [
  { id: "sales", label: "Sales Report" },
  { id: "products", label: "Product Sales" },
  { id: "categories", label: "Category Sales" },
  { id: "pnl", label: "Profit & Loss" },
  { id: "gst", label: "GST Summary" },
  { id: "purchases", label: "Purchases" },
  { id: "stock", label: "Stock Valuation" },
  { id: "low_stock", label: "Low Stock" },
  { id: "customers", label: "Customers" },
  { id: "outstanding", label: "Outstanding Dues" },
  { id: "suppliers", label: "Suppliers" },
  { id: "payments", label: "Payment Collection" },
  { id: "expenses", label: "Expenses" },
  { id: "returns", label: "Returns" },
  { id: "staff", label: "Staff Performance" },
  { id: "daily_closing", label: "Daily Closing" },
];

export default function ReportsPage() {
  const { t } = useLanguage();
  const [type, setType] = useState("sales");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");

  const loadReport = async () => {
    setLoading(true);
    const params = new URLSearchParams({ type });
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    const res = await fetch(`/api/reports?${params.toString()}`);
    if (res.ok) {
      const d = await res.json();
      setRows(d.rows || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadReport();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const columns = rows.length > 0 ? Object.keys(rows[0]).filter((k) => k !== "id" && k !== "openedById" && k !== "openedBy" && k !== "createdAt" && k !== "updatedAt") : [];

  const formatCell = (key: string, val: unknown) => {
    if (val === null || val === undefined) return "-";
    if (typeof val === "number") {
      if (["qty", "bills", "items", "stock", "minAlert", "purchases", "loyaltyPoints", "gstRate"].includes(key)) {
        return key === "gstRate" ? `${val}%` : String(val);
      }
      return formatCurrency(val);
    }
    if (typeof val === "string" && /^\d{4}-\d{2}-\d{2}T/.test(val)) {
      return new Date(val).toLocaleDateString("en-IN");
    }
    return String(val);
  };

  const handleExcel = () => {
    if (rows.length === 0) return;
    exportToExcel(rows, `bhavani-bangles-${type}-report`, type);
  };

  const handlePDF = () => {
    if (rows.length === 0) return;
    const activeTab = REPORT_TABS.find((t) => t.id === type);
    exportTableToPDF({
      title: activeTab?.label || "Business Report",
      subtitle: from && to ? `Period: ${from} to ${to}` : "All recorded transactions",
      headers: columns.map((c) => c.replace(/([A-Z])/g, " $1").toUpperCase()),
      rows: rows.map((r) => columns.map((c) => formatCell(c, r[c]).replace("₹", "Rs."))),
      fileName: `bhavani-bangles-${type}-report`,
    });
  };

  const handleReset = async () => {
    const ok = window.confirm(
      "Reset all bills & sales reports to 0 and restart bill numbering from 01?"
    );
    if (!ok) return;
    setResetting(true);
    setStatusMsg("");
    try {
      const res = await fetch("/api/reports/reset", { method: "POST" });
      const d = await res.json();
      if (res.ok) {
        if (typeof window !== "undefined") {
          localStorage.removeItem("bb_pos_offline_queue_v1");
        }
        setStatusMsg(d.message || "All bills reset to 0. Next bill will start from 01.");
        await loadReport();
      } else {
        setStatusMsg(d.error || "Reset failed");
      }
    } finally {
      setResetting(false);
    }
  };

  return (
    <AppShell
      title={t("reports.title")}
      subtitle={t("reports.subtitle")}
      actions={
        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            disabled={resetting}
            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 transition-colors disabled:opacity-50"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${resetting ? "animate-spin" : ""}`} />
            {resetting ? t("reports.resetting") : t("reports.resetBills")}
          </button>
          <button onClick={handleExcel} className="bb-btn-secondary py-2 px-3 text-xs">
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> {t("reports.exportExcel")}
          </button>
          <button onClick={handlePDF} className="bb-btn-primary py-2 px-3 text-xs">
            <Download className="w-3.5 h-3.5" /> {t("reports.exportPdf")}
          </button>
        </div>
      }
    >
      {statusMsg && (
        <div className="mb-4 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-xs text-emerald-800 font-medium flex items-center justify-between">
          <span>{statusMsg}</span>
          <button onClick={() => setStatusMsg("")} className="underline ml-3">Dismiss</button>
        </div>
      )}
      {/* Report Type Selector */}
      <div className="flex flex-wrap gap-1.5 mb-5">
        {REPORT_TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setType(t.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              type === t.id
                ? "bg-rosegold-500 text-white border-rosegold-500 shadow-xs"
                : "bg-white border-ivory-300 text-espresso-600 hover:bg-ivory-100"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Date Range Filter */}
      <div className="bb-card p-4 mb-5 flex flex-wrap items-center gap-3">
        <span className="text-xs font-semibold text-espresso-600">{t("reports.dateRange")}</span>
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="bb-input py-1.5 text-xs w-40" />
        <span className="text-xs text-espresso-400">{t("reports.to")}</span>
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="bb-input py-1.5 text-xs w-40" />
        <button onClick={loadReport} className="bb-btn-primary py-1.5 px-4 text-xs">{t("reports.applyFilter")}</button>
        {(from || to) && (
          <button
            onClick={() => {
              setFrom("");
              setTo("");
            }}
            className="text-xs text-rosegold-600 hover:underline"
          >
            {t("reports.clear")}
          </button>
        )}
      </div>

      {/* Report Data Table */}
      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                {columns.map((col) => (
                  <th key={col} className="py-3 px-4 text-left whitespace-nowrap">
                    {col.replace(/([A-Z])/g, " $1")}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {loading ? (
                <tr><td colSpan={Math.max(1, columns.length)} className="py-10 text-center text-espresso-400">Generating report...</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={Math.max(1, columns.length)} className="py-10 text-center text-espresso-400">No records found for this report</td></tr>
              ) : (
                rows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-ivory-50/70">
                    {columns.map((col) => (
                      <td key={col} className="py-2.5 px-4 tabular-nums whitespace-nowrap text-espresso-800">
                        {formatCell(col, row[col])}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
