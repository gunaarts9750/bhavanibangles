"use client";

import React, { useEffect, useState } from "react";
import { Search, Printer, IndianRupee, Ban } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { InvoiceModal } from "@/components/InvoiceModal";
import { useAuth } from "@/components/AuthContext";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { PrintableInvoiceData } from "@/lib/export";

interface SaleRow extends PrintableInvoiceData {
  id: string;
  isCancelled: boolean;
  user?: { fullName: string } | null;
}

export default function InvoicesPage() {
  const { user } = useAuth();
  const isOwner = user?.roleName === "SUPER_ADMIN";

  const [sales, setSales] = useState<SaleRow[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [loading, setLoading] = useState(true);
  const [activeInvoice, setActiveInvoice] = useState<SaleRow | null>(null);

  // Due payment modal
  const [payModal, setPayModal] = useState<SaleRow | null>(null);
  const [payAmount, setPayAmount] = useState(0);
  const [payMethod, setPayMethod] = useState("UPI");

  const loadSales = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (status !== "ALL") params.set("status", status);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    const res = await fetch(`/api/sales?${params.toString()}`);
    if (res.ok) setSales((await res.json()).sales || []);
    setLoading(false);
  };

  useEffect(() => {
    loadSales();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const recordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModal) return;
    const res = await fetch(`/api/sales/${payModal.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "ADD_PAYMENT", amount: payAmount, method: payMethod }),
    });
    if (res.ok) {
      setPayModal(null);
      loadSales();
    }
  };

  const cancelInvoice = async (s: SaleRow) => {
    const reason = prompt(`Owner Approval: Enter cancellation reason for ${s.invoiceNumber}:`);
    if (!reason) return;
    const res = await fetch(`/api/sales/${s.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "CANCEL", reason }),
    });
    if (res.ok) loadSales();
  };

  return (
    <AppShell
      title="Invoice History"
      subtitle="Search, reprint A4/thermal bills, download PDFs, record due payments & manage cancellations"
    >
      <div className="bb-card p-4 mb-5 flex flex-wrap items-center gap-3">
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-espresso-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && loadSales()}
            placeholder="Invoice #, customer, mobile..."
            className="bb-input pl-10 py-2 text-xs"
          />
        </div>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="bb-input py-2 text-xs w-36">
          <option value="ALL">All Status</option>
          <option value="PAID">Paid</option>
          <option value="PARTIAL">Partial</option>
          <option value="DUE">Due / Credit</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="bb-input py-2 text-xs w-36" />
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="bb-input py-2 text-xs w-36" />
        <button onClick={loadSales} className="bb-btn-primary py-2 px-3.5 text-xs">Filter</button>
      </div>

      <div className="bb-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
              <tr>
                <th className="py-3 px-4 text-left">Invoice #</th>
                <th className="py-3 px-3 text-left">Date & Time</th>
                <th className="py-3 px-3 text-left">Customer</th>
                <th className="py-3 px-3 text-center">Mode</th>
                <th className="py-3 px-3 text-right">Grand Total</th>
                <th className="py-3 px-3 text-right">Paid / Due</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-200">
              {loading ? (
                <tr><td colSpan={8} className="py-10 text-center text-espresso-400">Loading invoices...</td></tr>
              ) : sales.length === 0 ? (
                <tr><td colSpan={8} className="py-10 text-center text-espresso-400">No invoices found</td></tr>
              ) : (
                sales.map((s) => (
                  <tr key={s.id} className={s.isCancelled ? "opacity-55 bg-rose-50/30" : "hover:bg-ivory-50/70"}>
                    <td className="py-3 px-4 font-bold text-espresso-900">{s.invoiceNumber}</td>
                    <td className="py-3 px-3 text-espresso-500 whitespace-nowrap">{formatDateTime(s.saleDate)}</td>
                    <td className="py-3 px-3">
                      <p className="font-semibold text-espresso-900">{s.customerName}</p>
                      {s.customerPhone && <p className="text-[10px] text-espresso-400">{s.customerPhone}</p>}
                    </td>
                    <td className="py-3 px-3 text-center font-medium">{s.paymentMethod}</td>
                    <td className="py-3 px-3 text-right font-bold tabular-nums">{formatCurrency(s.grandTotal)}</td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      <p className="text-emerald-700 font-semibold">{formatCurrency(s.paidAmount)}</p>
                      {s.balanceDue > 0 && <p className="text-[10px] text-rose-600 font-bold">Due: {formatCurrency(s.balanceDue)}</p>}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={
                          s.paymentStatus === "PAID"
                            ? "bb-badge-success"
                            : s.paymentStatus === "CANCELLED"
                            ? "bb-badge-danger"
                            : "bb-badge-warning"
                        }
                      >
                        {s.paymentStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() => setActiveInvoice(s)}
                          className="bb-btn-secondary py-1 px-2.5 text-xs"
                          title="View / Print / PDF / WhatsApp"
                        >
                          <Printer className="w-3.5 h-3.5" /> View
                        </button>
                        {!s.isCancelled && s.balanceDue > 0 && (
                          <button
                            onClick={() => {
                              setPayModal(s);
                              setPayAmount(s.balanceDue);
                            }}
                            className="bb-btn-gold py-1 px-2.5 text-xs"
                            title="Collect Due Payment"
                          >
                            <IndianRupee className="w-3.5 h-3.5" /> Pay
                          </button>
                        )}
                        {isOwner && !s.isCancelled && (
                          <button
                            onClick={() => cancelInvoice(s)}
                            className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-600"
                            title="Cancel Invoice (Owner Approval)"
                          >
                            <Ban className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {activeInvoice && <InvoiceModal invoice={activeInvoice} onClose={() => setActiveInvoice(null)} />}

      {payModal && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={recordPayment} className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-elevated">
            <h3 className="font-serif text-xl font-bold text-espresso-900">Record Due Payment</h3>
            <p className="text-xs text-espresso-500">
              Invoice <b>{payModal.invoiceNumber}</b> • Pending: <b>{formatCurrency(payModal.balanceDue)}</b>
            </p>
            <div>
              <label className="bb-label">Amount (₹)</label>
              <input type="number" min={1} max={payModal.balanceDue} value={payAmount} onChange={(e) => setPayAmount(Number(e.target.value))} className="bb-input" required />
            </div>
            <div>
              <label className="bb-label">Payment Mode</label>
              <select value={payMethod} onChange={(e) => setPayMethod(e.target.value)} className="bb-input">
                <option value="UPI">UPI</option>
                <option value="CASH">Cash</option>
                <option value="CARD">Card</option>
                <option value="BANK_TRANSFER">Bank Transfer</option>
              </select>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPayModal(null)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Confirm Payment</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
