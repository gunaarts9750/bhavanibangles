"use client";

import React, { useEffect, useState } from "react";
import { SlidersHorizontal, ArrowUpDown, AlertTriangle, Boxes, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/format";

interface StockProduct {
  id: string;
  name: string;
  code: string;
  unit: string;
  currentStock: number;
  minStockAlert: number;
  purchasePrice: number;
  sellingPrice: number;
  rackNumber?: string | null;
  category: { name: string };
}

interface Movement {
  id: string;
  type: string;
  quantity: number;
  previousStock: number;
  newStock: number;
  referenceId?: string | null;
  reason?: string | null;
  createdAt: string;
  product: { name: string; code: string; unit: string };
  user?: { fullName: string } | null;
}

export default function InventoryPage() {
  const [products, setProducts] = useState<StockProduct[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [summary, setSummary] = useState({ totalSkus: 0, totalQty: 0, stockValue: 0, retailValue: 0, lowStock: 0, outOfStock: 0 });
  const [filter, setFilter] = useState("all");
  const [tab, setTab] = useState<"stock" | "history">("stock");

  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjForm, setAdjForm] = useState({ productId: "", type: "ADJUSTMENT", quantity: 1, reason: "" });
  const [error, setError] = useState("");

  const loadData = async () => {
    const res = await fetch(`/api/inventory?filter=${filter}`);
    if (res.ok) {
      const d = await res.json();
      setProducts(d.products || []);
      setMovements(d.movements || []);
      setSummary(d.summary);
    }
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const handleAdjust = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/inventory", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(adjForm),
    });
    const d = await res.json();
    if (!res.ok) {
      setError(d.error || "Failed to update stock");
      return;
    }
    setAdjustOpen(false);
    setAdjForm({ productId: "", type: "ADJUSTMENT", quantity: 1, reason: "" });
    loadData();
  };

  return (
    <AppShell
      title="Inventory & Stock Control"
      subtitle="Real-time stock levels, audits, damaged/lost tracking & complete movement ledger"
      actions={
        <button
          onClick={() => {
            setAdjForm((prev) => ({ ...prev, productId: products[0]?.id || "" }));
            setAdjustOpen(true);
          }}
          className="bb-btn-primary py-2 px-3.5 text-xs"
        >
          <SlidersHorizontal className="w-4 h-4" /> Stock Adjustment
        </button>
      }
    >
      {/* Summary KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <div className="bb-card p-4">
          <p className="text-[11px] text-espresso-500">Total Active SKUs</p>
          <p className="text-xl font-bold text-espresso-900 mt-1">{formatNumber(summary.totalSkus)}</p>
        </div>
        <div className="bb-card p-4">
          <p className="text-[11px] text-espresso-500">Total Stock Units</p>
          <p className="text-xl font-bold text-espresso-900 mt-1">{formatNumber(summary.totalQty)}</p>
        </div>
        <div className="bb-card p-4">
          <p className="text-[11px] text-espresso-500">Inventory Cost Value</p>
          <p className="text-xl font-bold text-espresso-900 mt-1 tabular-nums">{formatCurrency(summary.stockValue)}</p>
        </div>
        <div className="bb-card p-4">
          <p className="text-[11px] text-espresso-500">Retail Stock Value</p>
          <p className="text-xl font-bold text-rosegold-700 mt-1 tabular-nums">{formatCurrency(summary.retailValue)}</p>
        </div>
        <div className="bb-card p-4 border-amber-200 bg-amber-50/40">
          <p className="text-[11px] text-amber-800 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" /> Low / Out of Stock
          </p>
          <p className="text-xl font-bold text-amber-900 mt-1">{summary.lowStock} / {summary.outOfStock}</p>
        </div>
      </div>

      {/* Tabs & Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-ivory-300">
          <button
            onClick={() => setTab("stock")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              tab === "stock" ? "bg-rosegold-500 text-white" : "text-espresso-600"
            }`}
          >
            <Boxes className="w-3.5 h-3.5" /> Product Stock Levels
          </button>
          <button
            onClick={() => setTab("history")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              tab === "history" ? "bg-rosegold-500 text-white" : "text-espresso-600"
            }`}
          >
            <ArrowUpDown className="w-3.5 h-3.5" /> Stock Movement Ledger
          </button>
        </div>

        {tab === "stock" && (
          <div className="flex items-center gap-1.5">
            {[
              { id: "all", label: "All Stock" },
              { id: "low", label: "Low Stock" },
              { id: "out", label: "Out of Stock" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                  filter === f.id
                    ? "bg-blush-200 border-rosegold-400 text-rosegold-700"
                    : "bg-white border-ivory-300 text-espresso-600"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {tab === "stock" ? (
        <div className="bb-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
                <tr>
                  <th className="py-3 px-4 text-left">Product</th>
                  <th className="py-3 px-3 text-left">Category</th>
                  <th className="py-3 px-3 text-center">Rack</th>
                  <th className="py-3 px-3 text-center">Current Stock</th>
                  <th className="py-3 px-3 text-center">Min Alert</th>
                  <th className="py-3 px-3 text-right">Stock Cost Value</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ivory-200">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-ivory-50/70">
                    <td className="py-3 px-4">
                      <p className="font-semibold text-espresso-900">{p.name}</p>
                      <p className="text-[10px] text-espresso-400">{p.code}</p>
                    </td>
                    <td className="py-3 px-3">{p.category.name}</td>
                    <td className="py-3 px-3 text-center">{p.rackNumber || "-"}</td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={
                          p.currentStock <= 0
                            ? "bb-badge-danger"
                            : p.currentStock <= p.minStockAlert
                            ? "bb-badge-warning"
                            : "bb-badge-success"
                        }
                      >
                        {p.currentStock} {p.unit}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center text-espresso-500">{p.minStockAlert}</td>
                    <td className="py-3 px-3 text-right tabular-nums font-semibold">
                      {formatCurrency(p.currentStock * p.purchasePrice)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => {
                          setAdjForm({ productId: p.id, type: "ADJUSTMENT", quantity: 1, reason: "" });
                          setAdjustOpen(true);
                        }}
                        className="text-xs font-semibold text-rosegold-600 hover:underline"
                      >
                        Adjust
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bb-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-ivory-100 border-b border-ivory-300 text-[10px] uppercase text-espresso-500">
                <tr>
                  <th className="py-3 px-4 text-left">Date & Time</th>
                  <th className="py-3 px-3 text-left">Product</th>
                  <th className="py-3 px-3 text-center">Type</th>
                  <th className="py-3 px-3 text-center">Change</th>
                  <th className="py-3 px-3 text-center">Before → After</th>
                  <th className="py-3 px-3 text-left">Reason / Ref</th>
                  <th className="py-3 px-4 text-left">Staff</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ivory-200">
                {movements.map((m) => (
                  <tr key={m.id}>
                    <td className="py-2.5 px-4 text-espresso-500 whitespace-nowrap">{formatDateTime(m.createdAt)}</td>
                    <td className="py-2.5 px-3">
                      <p className="font-semibold text-espresso-900">{m.product.name}</p>
                      <p className="text-[10px] text-espresso-400">{m.product.code}</p>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="bb-badge-blush">{m.type}</span>
                    </td>
                    <td className={`py-2.5 px-3 text-center font-bold tabular-nums ${m.quantity >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                      {m.quantity >= 0 ? `+${m.quantity}` : m.quantity}
                    </td>
                    <td className="py-2.5 px-3 text-center tabular-nums text-espresso-600">
                      {m.previousStock} → <b>{m.newStock}</b>
                    </td>
                    <td className="py-2.5 px-3 text-espresso-600">{m.reason || m.referenceId || "-"}</td>
                    <td className="py-2.5 px-4 text-espresso-500">{m.user?.fullName || "System"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustOpen && (
        <div className="fixed inset-0 z-50 bg-espresso-900/50 flex items-center justify-center p-4">
          <form onSubmit={handleAdjust} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-elevated">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-espresso-900">Stock Adjustment / Audit</h3>
              <button type="button" onClick={() => setAdjustOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            {error && <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700">{error}</div>}

            <div>
              <label className="bb-label">Select Product</label>
              <select
                value={adjForm.productId}
                onChange={(e) => setAdjForm({ ...adjForm, productId: e.target.value })}
                className="bb-input"
                required
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} (Stock: {p.currentStock})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="bb-label">Movement Type</label>
              <select
                value={adjForm.type}
                onChange={(e) => setAdjForm({ ...adjForm, type: e.target.value })}
                className="bb-input"
              >
                <option value="ADJUSTMENT">Manual Stock Addition / Correction (+/-)</option>
                <option value="DAMAGED">Damaged Stock (Deduct)</option>
                <option value="LOST">Lost / Shrinkage Stock (Deduct)</option>
                <option value="PURCHASE_RETURN">Purchase Return to Supplier (Deduct)</option>
                <option value="TRANSFER">Stock Transfer Out (Deduct)</option>
                <option value="AUDIT">Stock Audit (Set Exact Count)</option>
              </select>
            </div>
            <div>
              <label className="bb-label">{adjForm.type === "AUDIT" ? "Actual Counted Stock" : "Quantity"}</label>
              <input
                type="number"
                value={adjForm.quantity}
                onChange={(e) => setAdjForm({ ...adjForm, quantity: Number(e.target.value) })}
                className="bb-input"
                required
              />
            </div>
            <div>
              <label className="bb-label">Reason / Notes *</label>
              <input
                value={adjForm.reason}
                onChange={(e) => setAdjForm({ ...adjForm, reason: e.target.value })}
                className="bb-input"
                placeholder="e.g. Glass bangles broken during display setup"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setAdjustOpen(false)} className="bb-btn-secondary">Cancel</button>
              <button type="submit" className="bb-btn-primary">Update Stock</button>
            </div>
          </form>
        </div>
      )}
    </AppShell>
  );
}
