"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  IndianRupee,
  Receipt,
  TrendingUp,
  ShoppingBag,
  Package,
  AlertTriangle,
  Users,
  Clock,
  Sparkles,
  Wallet,
  Truck,
  ArrowUpRight,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import { formatCurrency, formatNumber, formatDateTime } from "@/lib/format";

const PIE_COLORS = ["#B76E79", "#C9A25E", "#6E5A52", "#DF9EA9", "#8C6634", "#9E5661"];

interface DashboardData {
  kpis: {
    todayTotalSales: number;
    todayTotalBills: number;
    monthlySales: number;
    totalRevenue: number;
    totalPurchases: number;
    totalExpenses: number;
    totalProfitEstimate: number;
    totalProducts: number;
    totalStockQuantity: number;
    lowStockCount: number;
    outOfStockCount: number;
    customerCount: number;
    pendingCustomerPayments: number;
  };
  charts: {
    daily: { label: string; sales: number }[];
    weekly: { label: string; sales: number }[];
    monthly: { label: string; sales: number }[];
    yearly: { label: string; sales: number }[];
    categorySales: { name: string; value: number }[];
    paymentBreakdown: { method: string; amount: number }[];
  };
  topProducts: { id: string; name: string; code: string; qty: number; revenue: number; stock: number }[];
  lowStockList: { id: string; name: string; code: string; currentStock: number; minStockAlert: number; unit: string }[];
  recentSales: { id: string; invoiceNumber: string; customerName: string; grandTotal: number; paymentMethod: string; paymentStatus: string; saleDate: string }[];
  aiInsights: { title: string; detail: string; severity: "info" | "warning" | "success" }[];
}

export default function DashboardPage() {
  const [range, setRange] = useState("this_month");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [chartTab, setChartTab] = useState<"daily" | "weekly" | "monthly" | "yearly">("daily");
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ range });
      if (range === "custom" && customFrom && customTo) {
        params.set("from", customFrom);
        params.set("to", customTo);
      }
      const res = await fetch(`/api/dashboard?${params.toString()}`, { cache: "no-store" });
      if (res.ok) {
        setData(await res.json());
      }
    } finally {
      setLoading(false);
    }
  }, [range, customFrom, customTo]);

  useEffect(() => {
    if (range !== "custom" || (customFrom && customTo)) {
      loadData();
    }
  }, [range, customFrom, customTo, loadData]);

  const activeSeries = data ? data.charts[chartTab] : [];

  return (
    <AppShell
      title="Owner Analytics Dashboard"
      subtitle="Live retail performance & inventory overview for BHAVANI BANGLES"
      actions={
        <Link href="/pos" className="bb-btn-primary text-xs py-2 px-3.5">
          <ShoppingBag className="w-4 h-4" /> Open POS Billing
        </Link>
      }
    >
      {/* Date Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex flex-wrap items-center gap-1.5 bg-white p-1.5 rounded-xl border border-ivory-300 shadow-xs">
          {[
            { id: "today", label: "Today" },
            { id: "yesterday", label: "Yesterday" },
            { id: "this_week", label: "This Week" },
            { id: "this_month", label: "This Month" },
            { id: "custom", label: "Custom Date" },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setRange(f.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                range === f.id
                  ? "bg-rosegold-500 text-white shadow-xs"
                  : "text-espresso-600 hover:bg-ivory-100"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {range === "custom" && (
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={customFrom}
              onChange={(e) => setCustomFrom(e.target.value)}
              className="bb-input py-1.5 text-xs w-36"
            />
            <span className="text-xs text-espresso-400">to</span>
            <input
              type="date"
              value={customTo}
              onChange={(e) => setCustomTo(e.target.value)}
              className="bb-input py-1.5 text-xs w-36"
            />
          </div>
        )}
      </div>

      {loading || !data ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bb-card p-5 h-28 animate-pulse bg-ivory-200/60" />
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Primary Financial KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard
              title="Today's Sales"
              value={formatCurrency(data.kpis.todayTotalSales)}
              sub={`${data.kpis.todayTotalBills} bill(s) generated today`}
              icon={IndianRupee}
              accent="rosegold"
            />
            <KpiCard
              title="Monthly Sales"
              value={formatCurrency(data.kpis.monthlySales)}
              sub={`Selected period: ${formatCurrency(data.kpis.totalRevenue)}`}
              icon={TrendingUp}
              accent="champagne"
            />
            <KpiCard
              title="Estimated Net Profit"
              value={formatCurrency(data.kpis.totalProfitEstimate)}
              sub={`After COGS & ₹${formatNumber(data.kpis.totalExpenses)} expenses`}
              icon={Wallet}
              accent="emerald"
            />
            <KpiCard
              title="Pending Customer Dues"
              value={formatCurrency(data.kpis.pendingCustomerPayments)}
              sub={`${data.kpis.customerCount} total registered customers`}
              icon={Clock}
              accent="amber"
            />
          </div>

          {/* Secondary Operational KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            <MiniStat label="Total Purchases" value={formatCurrency(data.kpis.totalPurchases)} icon={Truck} />
            <MiniStat label="Total Expenses" value={formatCurrency(data.kpis.totalExpenses)} icon={Receipt} />
            <MiniStat label="Total Products" value={formatNumber(data.kpis.totalProducts)} icon={Package} />
            <MiniStat label="Total Stock Qty" value={formatNumber(data.kpis.totalStockQuantity)} icon={Users} />
            <MiniStat
              label="Low / Out of Stock"
              value={`${data.kpis.lowStockCount} / ${data.kpis.outOfStockCount}`}
              icon={AlertTriangle}
              alert={data.kpis.lowStockCount + data.kpis.outOfStockCount > 0}
            />
          </div>

          {/* Sales Trend + Payment Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bb-card p-5 lg:col-span-2">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="font-serif text-lg font-bold text-espresso-900">Sales Revenue Trend</h3>
                  <p className="text-xs text-espresso-400">Computed from confirmed database invoices</p>
                </div>
                <div className="flex items-center gap-1 bg-ivory-100 p-1 rounded-lg">
                  {(["daily", "weekly", "monthly", "yearly"] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setChartTab(tab)}
                      className={`px-2.5 py-1 rounded-md text-xs font-semibold capitalize ${
                        chartTab === tab ? "bg-white text-rosegold-700 shadow-xs" : "text-espresso-500"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={activeSeries}>
                    <defs>
                      <linearGradient id="roseGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#B76E79" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#B76E79" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EDE3D4" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#6E5A52" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "#6E5A52" }} axisLine={false} tickLine={false} />
                    <Tooltip
                      formatter={(v: number) => [formatCurrency(v), "Sales"]}
                      contentStyle={{ borderRadius: 12, borderColor: "#EDE3D4", fontSize: 12 }}
                    />
                    <Area
                      type="monotone"
                      dataKey="sales"
                      stroke="#B76E79"
                      strokeWidth={2.5}
                      fill="url(#roseGrad)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bb-card p-5 flex flex-col">
              <h3 className="font-serif text-lg font-bold text-espresso-900">Payment Methods</h3>
              <p className="text-xs text-espresso-400 mb-3">Collection breakdown by tender type</p>
              <div className="h-52 flex-1">
                {data.charts.paymentBreakdown.length === 0 ? (
                  <p className="text-xs text-espresso-400 text-center pt-16">No payments in selected period</p>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={data.charts.paymentBreakdown}
                        dataKey="amount"
                        nameKey="method"
                        cx="50%"
                        cy="50%"
                        innerRadius={52}
                        outerRadius={78}
                        paddingAngle={3}
                      >
                        {data.charts.paymentBreakdown.map((_, idx) => (
                          <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v: number) => formatCurrency(v)} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
              <div className="space-y-1.5 mt-2">
                {data.charts.paymentBreakdown.map((p, idx) => (
                  <div key={p.method} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2 text-espresso-700 font-medium">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }}
                      />
                      {p.method}
                    </span>
                    <span className="font-semibold tabular-nums text-espresso-900">{formatCurrency(p.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Category Sales + AI Business Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bb-card p-5 lg:col-span-2">
              <h3 className="font-serif text-lg font-bold text-espresso-900">Category-Wise Sales</h3>
              <p className="text-xs text-espresso-400 mb-4">Revenue performance across bangle & jewellery collections</p>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.charts.categorySales.slice(0, 8)} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EDE3D4" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 11, fill: "#6E5A52" }} axisLine={false} tickLine={false} />
                    <YAxis
                      type="category"
                      dataKey="name"
                      width={125}
                      tick={{ fontSize: 11, fill: "#2C1E1A" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip formatter={(v: number) => formatCurrency(v)} />
                    <Bar dataKey="value" fill="#C9A25E" radius={[0, 8, 8, 0]} barSize={18} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* AI Business Insights (Data-Driven) */}
            <div className="bb-card p-5 bg-gradient-to-b from-white to-blush-50/50">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-xl bg-rosegold-500/10 text-rosegold-600">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-espresso-900">Smart Retail Insights</h3>
                  <p className="text-[11px] text-espresso-400">Live analysis from your store database</p>
                </div>
              </div>
              <div className="space-y-2.5">
                {data.aiInsights.map((ins, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs ${
                      ins.severity === "warning"
                        ? "bg-amber-50/70 border-amber-200/80 text-amber-900"
                        : ins.severity === "success"
                        ? "bg-emerald-50/60 border-emerald-200/80 text-emerald-900"
                        : "bg-ivory-50 border-ivory-300 text-espresso-800"
                    }`}
                  >
                    <p className="font-semibold">{ins.title}</p>
                    <p className="mt-0.5 opacity-85 leading-relaxed">{ins.detail}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Row: Top Products + Low Stock + Recent Invoices */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bb-card p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-espresso-900">Best-Selling Products</h3>
                <Link href="/reports" className="text-xs text-rosegold-600 font-semibold hover:underline flex items-center gap-0.5">
                  All <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="divide-y divide-ivory-200">
                {data.topProducts.length === 0 ? (
                  <p className="text-xs text-espresso-400 py-6 text-center">No sales yet in this period</p>
                ) : (
                  data.topProducts.map((p) => (
                    <div key={p.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                      <div className="min-w-0">
                        <p className="font-semibold text-espresso-900 truncate">{p.name}</p>
                        <p className="text-[11px] text-espresso-400">{p.qty} sold • {p.stock} in stock</p>
                      </div>
                      <span className="font-bold text-rosegold-700 tabular-nums shrink-0">
                        {formatCurrency(p.revenue)}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="bb-card p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-espresso-900">Low & Out-of-Stock</h3>
                <Link href="/inventory" className="text-xs text-rosegold-600 font-semibold hover:underline flex items-center gap-0.5">
                  Manage <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="divide-y divide-ivory-200">
                {data.lowStockList.length === 0 ? (
                  <p className="text-xs text-emerald-700 py-6 text-center">All products are well stocked!</p>
                ) : (
                  data.lowStockList.map((p) => (
                    <div key={p.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                      <div className="min-w-0">
                        <p className="font-semibold text-espresso-900 truncate">{p.name}</p>
                        <p className="text-[11px] text-espresso-400">{p.code} • Min: {p.minStockAlert}</p>
                      </div>
                      <span className={p.currentStock <= 0 ? "bb-badge-danger" : "bb-badge-warning"}>
                        {p.currentStock} {p.unit}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="bb-card p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-espresso-900">Recent Invoices</h3>
                <Link href="/invoices" className="text-xs text-rosegold-600 font-semibold hover:underline flex items-center gap-0.5">
                  History <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              <div className="divide-y divide-ivory-200">
                {data.recentSales.map((s) => (
                  <div key={s.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div className="min-w-0">
                      <p className="font-semibold text-espresso-900 truncate">
                        {s.invoiceNumber} • {s.customerName}
                      </p>
                      <p className="text-[11px] text-espresso-400">{formatDateTime(s.saleDate)}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-bold text-espresso-900 tabular-nums">{formatCurrency(s.grandTotal)}</p>
                      <span className={s.paymentStatus === "PAID" ? "text-[10px] text-emerald-600 font-semibold" : "text-[10px] text-amber-600 font-semibold"}>
                        {s.paymentMethod} • {s.paymentStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function KpiCard({
  title,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  title: string;
  value: string;
  sub: string;
  icon: React.ElementType;
  accent: "rosegold" | "champagne" | "emerald" | "amber";
}) {
  const colors = {
    rosegold: "bg-blush-200 text-rosegold-700",
    champagne: "bg-champagne-100 text-champagne-700",
    emerald: "bg-emerald-50 text-emerald-700",
    amber: "bg-amber-50 text-amber-700",
  }[accent];

  return (
    <div className="bb-card p-5 flex items-start justify-between gap-3">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-espresso-400">{title}</p>
        <p className="text-2xl font-bold text-espresso-900 mt-1.5 tabular-nums">{value}</p>
        <p className="text-[11px] text-espresso-500 mt-1">{sub}</p>
      </div>
      <div className={`p-2.5 rounded-xl ${colors}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  );
}

function MiniStat({
  label,
  value,
  icon: Icon,
  alert,
}: {
  label: string;
  value: string;
  icon: React.ElementType;
  alert?: boolean;
}) {
  return (
    <div className={`bb-card px-4 py-3.5 flex items-center gap-3 ${alert ? "border-amber-300 bg-amber-50/30" : ""}`}>
      <div className={`p-2 rounded-xl ${alert ? "bg-amber-100 text-amber-700" : "bg-ivory-200 text-espresso-600"}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] text-espresso-500 truncate">{label}</p>
        <p className="text-sm font-bold text-espresso-900 tabular-nums">{value}</p>
      </div>
    </div>
  );
}
