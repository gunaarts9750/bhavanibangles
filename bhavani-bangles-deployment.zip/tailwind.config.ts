import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: "#FDFBF8",
          100: "#FAF7F2",
          200: "#F5EFE6",
          300: "#EDE3D4",
          400: "#DFD0BC",
        },
        rosegold: {
          50: "rgb(var(--accent-50) / <alpha-value>)",
          100: "rgb(var(--accent-100) / <alpha-value>)",
          200: "rgb(var(--accent-200) / <alpha-value>)",
          300: "rgb(var(--accent-300) / <alpha-value>)",
          400: "rgb(var(--accent-400) / <alpha-value>)",
          500: "rgb(var(--accent-500) / <alpha-value>)",
          600: "rgb(var(--accent-600) / <alpha-value>)",
          700: "rgb(var(--accent-700) / <alpha-value>)",
          800: "rgb(var(--accent-800) / <alpha-value>)",
          900: "rgb(var(--accent-900) / <alpha-value>)",
        },
        champagne: {
          50: "#FCF9F0",
          100: "#F6EED9",
          200: "#ECDBB0",
          300: "#DFC382",
          400: "#D4AE5F",
          500: "#C9A25E",
          600: "#AE8443",
          700: "#8C6634",
          800: "#72522D",
          900: "#5D4327",
        },
        blush: {
          50: "rgb(var(--accent-50) / <alpha-value>)",
          100: "rgb(var(--accent-100) / <alpha-value>)",
          200: "rgb(var(--accent-200) / <alpha-value>)",
          300: "rgb(var(--accent-300) / <alpha-value>)",
        },
        espresso: {
          50: "#F6F2F0",
          100: "#E8DFDB",
          200: "#D1C0B8",
          300: "#B39A8E",
          400: "#91766A",
          500: "#6E5A52",
          600: "#56433C",
          700: "#42312B",
          800: "#34241F",
          900: "#2C1E1A",
        },
      },
      fontFamily: {
        serif: ['"Palatino Linotype"', '"Book Antiqua"', "Georgia", "serif"],
        sans: ['"Segoe UI"', "system-ui", "-apple-system", "BlinkMacSystemFont", "sans-serif"],
      },
      boxShadow: {
        soft: "0 2px 12px -2px rgba(44, 30, 26, 0.06), 0 1px 4px -1px rgba(44, 30, 26, 0.04)",
        card: "0 4px 20px -4px rgba(44, 30, 26, 0.08), 0 2px 6px -2px rgba(44, 30, 26, 0.04)",
        elevated: "0 12px 32px -8px rgba(44, 30, 26, 0.14)",
      },
      borderRadius: {
        xl: "0.875rem",
        "2xl": "1.125rem",
      },
    },
  },
  plugins: [],
};

export default config;
