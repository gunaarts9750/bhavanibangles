# BHAVANI BANGLES — Complete Retail Billing & Inventory Management Software

A production-ready, full-stack web POS, GST invoicing, and inventory management system built specifically for **BHAVANI BANGLES**.

## Features Implemented
- **Luxury Jewellery Retail UI**: Ivory & warm beige palette (`#FAF7F2`), rose-gold (`#B76E79`) and champagne-gold (`#C9A25E`) accents, soft blush highlights, espresso-brown typography, responsive sidebar & top navigation.
- **Role-Based Access Control (RBAC)**: Super Admin / Owner, Shop Manager, Billing Staff, Inventory Staff with granular module-level permissions (`View`, `Create`, `Edit`, `Delete`), bcrypt password hashing, JWT HTTP-only sessions, login history, and forgot-password recovery.
- **Owner Analytics Dashboard**: Live database metrics (Today's Sales, Bills, Monthly Sales, Purchases, Expenses, Estimated Net Profit, Stock Value, Low/Out-of-Stock Alerts, Pending Dues), Daily/Weekly/Monthly/Yearly charts, Category Sales, Payment Method breakdown, and Data-Driven Smart Retail Insights.
- **POS Billing Counter**: Barcode scanner input (`F4`), fast search (`F2`), category pills, item & bill discounts, permission-gated price overrides, CGST+SGST / IGST / No GST, round-off, Cash/UPI/Card/Bank/Split/Credit/Advance payments, atomic stock deduction, and instant invoice printing.
- **Multi-Format Printable Invoices**: A4 Tax Invoice, 80mm Thermal Receipt, 58mm Thermal Receipt, PDF Download, and WhatsApp Invoice Sharing.
- **Product Management**: 13 Bangles & Jewellery categories, image uploads, auto code & barcode generation, printable CODE128 barcode label sheets, Bulk Excel Import, Excel & PDF Export.
- **Inventory & Stock Control**: Opening, Purchase, Sale, Sale Return, Purchase Return, Damaged, Lost, Adjustment, Transfer, Audit tracking with full staff movement ledger and negative-stock protection.
- **Purchases & Suppliers**: Multi-item purchase entries with automatic stock addition, supplier directory, pending balances, and payment recording.
- **Customer CRM**: Customer profiles (Bridal, VIP, Regular, Wholesale), birthdays/anniversaries, loyalty points, due payment collection, advance balances, and WhatsApp outreach.
- **Invoice History & Quotations**: Search/filter/reprint/cancel invoices (Owner approval), create quotations (no stock deduction until converted to invoice).
- **Sales Returns & Exchange**: Return processing with automatic stock restoration and refund/exchange tracking.
- **Expenses, Staff & Attendance, Reports (16+ exportable reports), Daily Cash Register, JSON Database Backup & Audit Logs**.

## Demo Login Credentials
| Role | Username | Password |
| :--- | :--- | :--- |
| **Super Admin / Owner** | `owner` | `Owner@123` |
| **Shop Manager** | `manager` | `Manager@123` |
| **Billing Staff** | `cashier` | `Cashier@123` |
| **Inventory Staff** | `inventory` | `Inventory@123` |

## Local Quick Start
```bash
npm install
npx prisma generate
npx prisma db push
npm run db:seed       # Seeds demo catalog & sample transactions
npm run dev           # Starts on http://localhost:3000
```

## Production Deployment (PostgreSQL / Supabase)
1. Update `provider = "postgresql"` in `prisma/schema.prisma`.
2. Set `DATABASE_URL` and a strong `JWT_SECRET` in `.env` (see `.env.example`).
3. Run:
```bash
npx prisma migrate deploy
npx tsx prisma/bootstrap.ts   # Creates roles, permissions, categories & admin user WITHOUT demo transactions
npm run build
npm start
```
