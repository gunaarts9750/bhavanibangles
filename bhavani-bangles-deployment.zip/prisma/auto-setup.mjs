import { execSync } from "child_process";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";

function loadEnvFile() {
  const envPath = path.resolve(process.cwd(), ".env");
  if (!fs.existsSync(envPath)) return;
  const content = fs.readFileSync(envPath, "utf8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eqIndex = line.indexOf("=");
    if (eqIndex === -1) continue;
    const key = line.slice(0, eqIndex).trim();
    let val = line.slice(eqIndex + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (!process.env[key]) {
      process.env[key] = val;
    }
  }
}

loadEnvFile();

const resolvedDbUrl =
  process.env.DATABASE_URL ||
  process.env.POSTGRES_PRISMA_URL ||
  process.env.POSTGRES_URL ||
  "";

if (resolvedDbUrl && !process.env.DATABASE_URL) {
  process.env.DATABASE_URL = resolvedDbUrl;
}

// Auto-sync Prisma provider based on DATABASE_URL protocol
const schemaPath = path.resolve(process.cwd(), "prisma", "schema.prisma");
if (resolvedDbUrl && fs.existsSync(schemaPath)) {
  let targetProvider = null;
  if (resolvedDbUrl.startsWith("postgres://") || resolvedDbUrl.startsWith("postgresql://")) {
    targetProvider = "postgresql";
  } else if (resolvedDbUrl.startsWith("mysql://")) {
    targetProvider = "mysql";
  } else if (resolvedDbUrl.startsWith("file:")) {
    targetProvider = "sqlite";
  }

  if (targetProvider) {
    const currentSchema = fs.readFileSync(schemaPath, "utf8");
    const updatedSchema = currentSchema.replace(
      /(datasource\s+db\s*\{[\s\S]*?provider\s*=\s*)"(postgresql|mysql|sqlite)"/,
      `$1"${targetProvider}"`
    );
    if (updatedSchema !== currentSchema) {
      console.log(`[auto-setup] Detected ${targetProvider} URL — updating prisma/schema.prisma provider...`);
      fs.writeFileSync(schemaPath, updatedSchema, "utf8");
    }
  }
}

function run(cmd) {
  return execSync(cmd, {
    encoding: "utf8",
    stdio: "pipe",
    env: { ...process.env },
  });
}

console.log("[auto-setup] Generating Prisma Client...");
console.log(run("npx prisma generate"));

if (!resolvedDbUrl) {
  console.warn(
    "[auto-setup] No DATABASE_URL / POSTGRES_URL set yet — skipping build-time db push (attach a database in Vercel Storage and redeploy)."
  );
  process.exit(0);
}

try {
  console.log("[auto-setup] Running prisma db push...");
  const out = run("npx prisma db push --skip-generate");
  console.log(out);
} catch (err) {
  const combined = `${err.stdout || ""}\n${err.stderr || ""}`;
  console.log(combined);

  if (
    combined.includes("Added the required column `passwordHash`") ||
    combined.includes("Added the required column `fullName`") ||
    combined.includes("Added the required column `roleId`")
  ) {
    console.log("[auto-setup] Legacy tables detected — resetting database once for Next.js schema...");
    const resetOut = run("npx prisma db push --force-reset --skip-generate");
    console.log(resetOut);
  } else {
    console.error("[auto-setup] prisma db push failed; continuing build.");
  }
}

async function seedDefaults() {
  const { PrismaClient } = await import("@prisma/client");
  const prisma = new PrismaClient({
    datasources: { db: { url: resolvedDbUrl } },
  });

  try {
    console.log("[auto-setup] Ensuring default settings, roles, categories & admin accounts...");

    await prisma.setting.upsert({
      where: { id: "default" },
      update: {},
      create: {
        id: "default",
        shopName: "BHAVANI BANGLES",
        shopTagline: "Exquisite Bangles & Bridal Jewellery",
        defaultPrintFormat: "THERMAL_58",
      },
    });

    const modules = [
      "dashboard", "pos", "products", "inventory", "purchases",
      "customers", "invoices", "quotations", "returns", "expenses",
      "staff", "reports", "settings",
    ];

    const roleDefs = [
      { name: "SUPER_ADMIN", displayName: "Super Admin / Owner", description: "Full unrestricted access to all modules, reports, staff and settings." },
      { name: "SHOP_MANAGER", displayName: "Shop Manager", description: "Manages daily operations, billing, inventory, purchases, staff and reports." },
      { name: "BILLING_STAFF", displayName: "Billing Staff", description: "POS billing, invoice printing, quotations, customers and sales returns." },
      { name: "INVENTORY_STAFF", displayName: "Inventory Staff", description: "Product catalog, barcode labels, stock management and purchases." },
    ];

    const roles = {};
    for (const r of roleDefs) {
      const role = await prisma.role.upsert({
        where: { name: r.name },
        update: { displayName: r.displayName, description: r.description },
        create: r,
      });
      roles[r.name] = role.id;
    }

    const matrix = {
      SUPER_ADMIN: Object.fromEntries(modules.map((m) => [m, [true, true, true, true]])),
      SHOP_MANAGER: {
        dashboard: [true, false, false, false],
        pos: [true, true, true, false],
        products: [true, true, true, true],
        inventory: [true, true, true, false],
        purchases: [true, true, true, false],
        customers: [true, true, true, false],
        invoices: [true, true, true, false],
        quotations: [true, true, true, true],
        returns: [true, true, true, false],
        expenses: [true, true, true, false],
        staff: [true, true, true, false],
        reports: [true, false, false, false],
        settings: [true, false, false, false],
      },
      BILLING_STAFF: {
        dashboard: [true, false, false, false],
        pos: [true, true, false, false],
        products: [true, false, false, false],
        inventory: [false, false, false, false],
        purchases: [false, false, false, false],
        customers: [true, true, true, false],
        invoices: [true, true, false, false],
        quotations: [true, true, true, false],
        returns: [true, true, false, false],
        expenses: [false, false, false, false],
        staff: [false, false, false, false],
        reports: [false, false, false, false],
        settings: [false, false, false, false],
      },
      INVENTORY_STAFF: {
        dashboard: [true, false, false, false],
        pos: [false, false, false, false],
        products: [true, true, true, false],
        inventory: [true, true, true, false],
        purchases: [true, true, true, false],
        customers: [false, false, false, false],
        invoices: [false, false, false, false],
        quotations: [false, false, false, false],
        returns: [false, false, false, false],
        expenses: [false, false, false, false],
        staff: [false, false, false, false],
        reports: [true, false, false, false],
        settings: [false, false, false, false],
      },
    };

    for (const [roleName, perms] of Object.entries(matrix)) {
      const roleId = roles[roleName];
      for (const [mod, [canView, canCreate, canEdit, canDelete]] of Object.entries(perms)) {
        await prisma.permission.upsert({
          where: { roleId_module: { roleId, module: mod } },
          update: { canView, canCreate, canEdit, canDelete },
          create: { roleId, module: mod, canView, canCreate, canEdit, canDelete },
        });
      }
    }

    const categories = [
      { name: "Glass Bangles", slug: "glass-bangles", sortOrder: 1 },
      { name: "Metal Bangles", slug: "metal-bangles", sortOrder: 2 },
      { name: "Bridal Bangles", slug: "bridal-bangles", sortOrder: 3 },
      { name: "Designer Bangles", slug: "designer-bangles", sortOrder: 4 },
      { name: "Stone Bangles", slug: "stone-bangles", sortOrder: 5 },
      { name: "Antique Bangles", slug: "antique-bangles", sortOrder: 6 },
      { name: "Fancy Bangles", slug: "fancy-bangles", sortOrder: 7 },
      { name: "Kids Bangles", slug: "kids-bangles", sortOrder: 8 },
      { name: "Bracelet Collections", slug: "bracelet-collections", sortOrder: 9 },
      { name: "Artificial Jewellery", slug: "artificial-jewellery", sortOrder: 10 },
      { name: "Earrings", slug: "earrings", sortOrder: 11 },
      { name: "Necklaces", slug: "necklaces", sortOrder: 12 },
      { name: "Other Accessories", slug: "other-accessories", sortOrder: 13 },
    ];

    for (const cat of categories) {
      await prisma.category.upsert({
        where: { slug: cat.slug },
        update: {},
        create: cat,
      });
    }

    const adminPassword = process.env.INITIAL_ADMIN_PASSWORD || "bhavani@2026";
    const adminHash = await bcrypt.hash(adminPassword, 10);
    await prisma.user.upsert({
      where: { username: "admin" },
      update: { isActive: true },
      create: {
        username: "admin",
        email: "admin@bhavanibangles.in",
        fullName: "BHAVANI BANGLES Admin",
        passwordHash: adminHash,
        roleId: roles.SUPER_ADMIN,
        isActive: true,
      },
    });

    const ownerHash = await bcrypt.hash("Owner@123", 10);
    await prisma.user.upsert({
      where: { username: "owner" },
      update: { isActive: true },
      create: {
        username: "owner",
        email: "owner@bhavanibangles.in",
        fullName: "BHAVANI BANGLES Owner",
        passwordHash: ownerHash,
        roleId: roles.SUPER_ADMIN,
        isActive: true,
      },
    });

    console.log("[auto-setup] Default accounts ready: admin / bhavani@2026 and owner / Owner@123");
  } catch (err) {
    console.error("[auto-setup] Seed error:", err);
  } finally {
    await prisma.$disconnect();
  }
}

await seedDefaults();
