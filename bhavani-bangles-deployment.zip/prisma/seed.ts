import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const ALL_MODULES = [
  "dashboard",
  "pos",
  "products",
  "inventory",
  "purchases",
  "customers",
  "invoices",
  "quotations",
  "returns",
  "expenses",
  "staff",
  "reports",
  "settings",
];

const CATEGORIES = [
  { name: "Glass Bangles", slug: "glass-bangles", description: "Traditional and velvet-finish glass bangles", sortOrder: 1 },
  { name: "Metal Bangles", slug: "metal-bangles", description: "Brass, copper and gold-plated metal bangles", sortOrder: 2 },
  { name: "Bridal Bangles", slug: "bridal-bangles", description: "Complete bridal chooda and heavy wedding sets", sortOrder: 3 },
  { name: "Designer Bangles", slug: "designer-bangles", description: "Contemporary designer and partywear bangles", sortOrder: 4 },
  { name: "Stone Bangles", slug: "stone-bangles", description: "AD, Kundan, Polki and zircon studded bangles", sortOrder: 5 },
  { name: "Antique Bangles", slug: "antique-bangles", description: "Matte gold temple and heritage antique kadas", sortOrder: 6 },
  { name: "Fancy Bangles", slug: "fancy-bangles", description: "Trendy daily and festive fancy bangles", sortOrder: 7 },
  { name: "Kids Bangles", slug: "kids-bangles", description: "Lightweight colourful bangles for children", sortOrder: 8 },
  { name: "Bracelet Collections", slug: "bracelet-collections", description: "Charm, cuff and rose-gold bracelets", sortOrder: 9 },
  { name: "Artificial Jewellery", slug: "artificial-jewellery", description: "Fashion jewellery sets and accessories", sortOrder: 10 },
  { name: "Earrings", slug: "earrings", description: "Jhumkas, chandbalis and stud earrings", sortOrder: 11 },
  { name: "Necklaces", slug: "necklaces", description: "Chokers, rani haar and pendant sets", sortOrder: 12 },
  { name: "Other Accessories", slug: "other-accessories", description: "Bangle boxes, hair accessories and gift packs", sortOrder: 13 },
];

export async function seedCoreStructure() {
  // 1. Default Shop Settings
  await prisma.setting.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      shopName: "BHAVANI BANGLES",
      shopTagline: "Exquisite Bangles & Bridal Jewellery",
      address: "142, Sarafa Bazaar, Heritage Jewellery Lane, Jaipur, Rajasthan - 302003",
      phone: "+91 98290 45678",
      email: "contact@bhavanibangles.in",
      gstin: "08AABCB1234F1Z5",
      invoicePrefix: "BB",
      nextInvoiceNumber: 1001,
      quotationPrefix: "QT",
      nextQuotationNumber: 501,
      defaultGstPercent: 3,
      defaultHsnCode: "7117",
      currency: "INR",
      currencySymbol: "₹",
      dateFormat: "DD/MM/YYYY",
      defaultPrintFormat: "A4",
      allowNegativeStock: false,
      enableLoyaltyPoints: true,
      loyaltyPointRate: 100,
      upiId: "bhavanibangles@upi",
    },
  });

  // 2. Roles
  const roleDefs = [
    { name: "SUPER_ADMIN", displayName: "Super Admin / Owner", description: "Full unrestricted access to all modules, reports, staff and settings." },
    { name: "SHOP_MANAGER", displayName: "Shop Manager", description: "Manages daily operations, billing, inventory, purchases, staff and reports." },
    { name: "BILLING_STAFF", displayName: "Billing Staff", description: "POS billing, invoice printing, quotations, customers and sales returns." },
    { name: "INVENTORY_STAFF", displayName: "Inventory Staff", description: "Product catalog, barcode labels, stock management and purchases." },
  ];

  const roles: Record<string, string> = {};
  for (const r of roleDefs) {
    const role = await prisma.role.upsert({
      where: { name: r.name },
      update: { displayName: r.displayName, description: r.description },
      create: r,
    });
    roles[r.name] = role.id;
  }

  // 3. Permissions Matrix
  const matrix: Record<string, Record<string, [boolean, boolean, boolean, boolean]>> = {
    SUPER_ADMIN: Object.fromEntries(ALL_MODULES.map((m) => [m, [true, true, true, true]])),
    SHOP_MANAGER: {
      dashboard: [true, false, false, false],
      pos: [true, true, true, false],
      products: [true, true, true, true],
      inventory: [true, true, true, false],
      purchases: [true, true, true, false],
      customers: [true, true, true, false],
      invoices: [true, true, true, false],
      quotations: [true, true, true, true],
      returns: [true, true, true, false],
      expenses: [true, true, true, false],
      staff: [true, true, true, false],
      reports: [true, false, false, false],
      settings: [true, false, false, false],
    },
    BILLING_STAFF: {
      dashboard: [true, false, false, false],
      pos: [true, true, false, false],
      products: [true, false, false, false],
      inventory: [false, false, false, false],
      purchases: [false, false, false, false],
      customers: [true, true, true, false],
      invoices: [true, true, false, false],
      quotations: [true, true, true, false],
      returns: [true, true, false, false],
      expenses: [false, false, false, false],
      staff: [false, false, false, false],
      reports: [false, false, false, false],
      settings: [false, false, false, false],
    },
    INVENTORY_STAFF: {
      dashboard: [true, false, false, false],
      pos: [false, false, false, false],
      products: [true, true, true, false],
      inventory: [true, true, true, false],
      purchases: [true, true, true, false],
      customers: [false, false, false, false],
      invoices: [false, false, false, false],
      quotations: [false, false, false, false],
      returns: [false, false, false, false],
      expenses: [false, false, false, false],
      staff: [false, false, false, false],
      reports: [true, false, false, false],
      settings: [false, false, false, false],
    },
  };

  for (const [roleName, perms] of Object.entries(matrix)) {
    const roleId = roles[roleName];
    for (const [module, [canView, canCreate, canEdit, canDelete]] of Object.entries(perms)) {
      await prisma.permission.upsert({
        where: { roleId_module: { roleId, module } },
        update: { canView, canCreate, canEdit, canDelete },
        create: { roleId, module, canView, canCreate, canEdit, canDelete },
      });
    }
  }

  // 4. Categories
  const categoryMap: Record<string, string> = {};
  for (const c of CATEGORIES) {
    const cat = await prisma.category.upsert({
      where: { slug: c.slug },
      update: { name: c.name, description: c.description, sortOrder: c.sortOrder },
      create: c,
    });
    categoryMap[c.name] = cat.id;
  }

  return { roles, categoryMap };
}

async function main() {
  console.log("Seeding BHAVANI BANGLES database...");
  const { roles, categoryMap } = await seedCoreStructure();

  // 5. Users & Staff
  const ownerHash = await bcrypt.hash("bhavani@bangles@2026", 12);
  const managerHash = await bcrypt.hash("Manager@123", 10);
  const cashierHash = await bcrypt.hash("Cashier@123", 10);
  const invHash = await bcrypt.hash("Inventory@123", 10);

  const owner = await prisma.user.upsert({
    where: { username: "admin" },
    update: { passwordHash: ownerHash },
    create: {
      username: "admin",
      email: "admin@bhavanibangles.in",
      fullName: "Bhavani Bangles Admin",
      phone: "+91 98290 45678",
      passwordHash: ownerHash,
      roleId: roles.SUPER_ADMIN,
    },
  });

  const manager = await prisma.user.upsert({
    where: { username: "manager" },
    update: {},
    create: {
      username: "manager",
      email: "manager@bhavanibangles.in",
      fullName: "Rajeshwari Khandelwal",
      phone: "+91 98291 22334",
      passwordHash: managerHash,
      roleId: roles.SHOP_MANAGER,
    },
  });

  const cashier = await prisma.user.upsert({
    where: { username: "cashier" },
    update: {},
    create: {
      username: "cashier",
      email: "cashier@bhavanibangles.in",
      fullName: "Pooja Verma",
      phone: "+91 97822 11445",
      passwordHash: cashierHash,
      roleId: roles.BILLING_STAFF,
    },
  });

  const invStaff = await prisma.user.upsert({
    where: { username: "inventory" },
    update: {},
    create: {
      username: "inventory",
      email: "inventory@bhavanibangles.in",
      fullName: "Vikram Singh",
      phone: "+91 96100 77889",
      passwordHash: invHash,
      roleId: roles.INVENTORY_STAFF,
    },
  });

  const staffList = [
    { staffCode: "BB-STF-01", userId: owner.id, name: owner.fullName, phone: "+91 98290 45678", email: owner.email!, designation: "Owner / Managing Director", salary: 0, address: "Civil Lines, Jaipur" },
    { staffCode: "BB-STF-02", userId: manager.id, name: manager.fullName, phone: "+91 98291 22334", email: manager.email!, designation: "Store Manager", salary: 28000, address: "Malviya Nagar, Jaipur" },
    { staffCode: "BB-STF-03", userId: cashier.id, name: cashier.fullName, phone: "+91 97822 11445", email: cashier.email!, designation: "Senior Billing Executive", salary: 16500, address: "Vaishali Nagar, Jaipur" },
    { staffCode: "BB-STF-04", userId: invStaff.id, name: invStaff.fullName, phone: "+91 96100 77889", email: invStaff.email!, designation: "Inventory Coordinator", salary: 15000, address: "Mansarovar, Jaipur" },
  ];

  const createdStaff = [];
  for (const s of staffList) {
    const st = await prisma.staff.upsert({
      where: { staffCode: s.staffCode },
      update: {},
      create: s,
    });
    createdStaff.push(st);
  }

  // Today's Attendance
  const todayStr = new Date().toISOString().slice(0, 10);
  for (const st of createdStaff) {
    await prisma.attendance.upsert({
      where: { staffId_date: { staffId: st.id, date: todayStr } },
      update: {},
      create: {
        staffId: st.id,
        date: todayStr,
        status: "PRESENT",
        checkIn: new Date(new Date().setHours(10, 0, 0, 0)),
      },
    });
  }

  // 6. Suppliers
  const existingSuppliers = await prisma.supplier.count();
  let suppliers = await prisma.supplier.findMany();
  if (existingSuppliers === 0) {
    const supplierData = [
      { name: "Shree Mahaveer Bangle Works", contactPerson: "Ramesh Agarwal", phone: "+91 94122 55001", email: "mahaveerbangles@gmail.com", address: "Suhag Nagar, Firozabad, UP", gstin: "09AABCM4421K1Z8", pendingBalance: 12500 },
      { name: "Royal Jaipur Lac & Kundan Craft", contactPerson: "Harish Soni", phone: "+91 98290 66112", email: "royallac@jaipurcraft.in", address: "Johari Bazaar, Jaipur, RJ", gstin: "08AADCR8821M1Z2", pendingBalance: 8200 },
      { name: "Zaveri Designer Jewellery House", contactPerson: "Ketan Zaveri", phone: "+91 98201 33445", email: "orders@zaverihouse.in", address: "Bhuleshwar, Mumbai, MH", gstin: "27AAECZ1190P1Z4", pendingBalance: 0 },
      { name: "Charminar Pearl & Stone Bangles", contactPerson: "Salman Qureshi", phone: "+91 98480 99002", email: "charminarbangles@gmail.com", address: "Laad Bazaar, Hyderabad, TS", gstin: "36AABCC7712N1Z9", pendingBalance: 4500 },
    ];
    for (const sup of supplierData) {
      await prisma.supplier.create({ data: sup });
    }
    suppliers = await prisma.supplier.findMany();
  }

  // 7. Products (18 rich items across categories)
  const existingProducts = await prisma.product.count();
  if (existingProducts === 0) {
    const productSeed = [
      { name: "Rajasthani Royal Bridal Chooda Set (42 Pcs)", code: "BB-BRD-001", barcode: "8901001000011", category: "Bridal Bangles", brand: "Bhavani Signature", designName: "Maharani Rajwada", color: "Maroon & Gold", size: "2.4", material: "Lac & Kundan", unit: "Set", purchasePrice: 1250, sellingPrice: 2450, mrp: 2800, discount: 5, gstPercent: 3, hsnCode: "7117", openingStock: 24, currentStock: 18, minStockAlert: 6, rackNumber: "A-01", supplierIdx: 1, description: "Handcrafted bridal chooda set with intricate kundan work and pearl latkans." },
      { name: "Punjabi Velvet Maroon Bridal Bangle Set", code: "BB-BRD-002", barcode: "8901001000028", category: "Bridal Bangles", brand: "Bhavani Signature", designName: "Suhag Dulhan", color: "Deep Red", size: "2.6", material: "Acrylic & AD Stone", unit: "Set", purchasePrice: 950, sellingPrice: 1890, mrp: 2200, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 15, currentStock: 4, minStockAlert: 5, rackNumber: "A-02", supplierIdx: 1, description: "Premium velvet-lined bridal set with American diamond borders." },
      { name: "Firozabad Velvet Touch Glass Bangles", code: "BB-GLS-001", barcode: "8901001000035", category: "Glass Bangles", brand: "Suhag Heritage", designName: "Zari Velvet", color: "Rani Pink", size: "2.4", material: "Glass", unit: "Dozen", purchasePrice: 90, sellingPrice: 180, mrp: 220, discount: 0, gstPercent: 5, hsnCode: "7018", openingStock: 80, currentStock: 62, minStockAlert: 15, rackNumber: "B-01", supplierIdx: 0, description: "Soft matte velvet-finish glass bangles with delicate golden zari border." },
      { name: "Emerald Green Mirror Work Glass Bangles", code: "BB-GLS-002", barcode: "8901001000042", category: "Glass Bangles", brand: "Suhag Heritage", designName: "Sheesha Shimmer", color: "Emerald Green", size: "2.6", material: "Glass", unit: "Dozen", purchasePrice: 110, sellingPrice: 240, mrp: 280, discount: 0, gstPercent: 5, hsnCode: "7018", openingStock: 60, currentStock: 48, minStockAlert: 12, rackNumber: "B-02", supplierIdx: 0, description: "Festive emerald glass bangles studded with tiny sparkling mirrors." },
      { name: "Rose Gold Diamond-Cut Metal Bangles (4 Pcs)", code: "BB-MTL-001", barcode: "8901001000059", category: "Metal Bangles", brand: "Zaveri Luxe", designName: "Aurelia Rose", color: "Rose Gold", size: "2.4", material: "Brass Rose-Gold Plated", unit: "Set", purchasePrice: 280, sellingPrice: 590, mrp: 699, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 40, currentStock: 31, minStockAlert: 8, rackNumber: "C-01", supplierIdx: 2, description: "Tarnish-resistant rose gold plated dailywear bangles with diamond cut." },
      { name: "Champagne Gold Sleek Office Wear Bangles", code: "BB-MTL-002", barcode: "8901001000066", category: "Metal Bangles", brand: "Zaveri Luxe", designName: "Minimalist Aura", color: "Champagne Gold", size: "2.6", material: "Alloy Gold Plated", unit: "Pair", purchasePrice: 180, sellingPrice: 390, mrp: 450, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 35, currentStock: 3, minStockAlert: 8, rackNumber: "C-02", supplierIdx: 2, description: "Elegant lightweight champagne-gold bangle pair for everyday elegance." },
      { name: "American Diamond Solitaire Tennis Bangle", code: "BB-STN-001", barcode: "8901001000073", category: "Stone Bangles", brand: "Zaveri Luxe", designName: "Noor AD", color: "Silver & White", size: "2.4", material: "Rhodium & AAA Zircon", unit: "Pair", purchasePrice: 620, sellingPrice: 1290, mrp: 1550, discount: 5, gstPercent: 3, hsnCode: "7117", openingStock: 25, currentStock: 19, minStockAlert: 5, rackNumber: "D-01", supplierIdx: 2, description: "AAA cubic zirconia stone-studded bangle pair with micro-setting finish." },
      { name: "Hyderabadi Pearl & Ruby Stone Kangan", code: "BB-STN-002", barcode: "8901001000080", category: "Stone Bangles", brand: "Laad Royal", designName: "Nizami Moti", color: "Ruby & Pearl", size: "2.6", material: "Lac & Semi-Precious Stone", unit: "Pair", purchasePrice: 480, sellingPrice: 980, mrp: 1150, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 30, currentStock: 22, minStockAlert: 6, rackNumber: "D-02", supplierIdx: 3, description: "Authentic Hyderabad kangan handcrafted with freshwater pearls and ruby stones." },
      { name: "South Indian Temple Lakshmi Antique Kada", code: "BB-ANT-001", barcode: "8901001000097", category: "Antique Bangles", brand: "Heritage Gold", designName: "Goddess Lakshmi", color: "Antique Matte Gold", size: "2.4", material: "Copper Matte Gold", unit: "Pair", purchasePrice: 740, sellingPrice: 1550, mrp: 1850, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 20, currentStock: 14, minStockAlert: 5, rackNumber: "E-01", supplierIdx: 2, description: "Screw-openable antique temple kadas with Kemp stones and goddess motif." },
      { name: "Oxidised Silver Peacock Carving Kada", code: "BB-ANT-002", barcode: "8901001000103", category: "Antique Bangles", brand: "Heritage Gold", designName: "Mayur Craft", color: "Oxidised Silver", size: "Free Size", material: "German Silver", unit: "Piece", purchasePrice: 190, sellingPrice: 420, mrp: 499, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 18, currentStock: 0, minStockAlert: 5, rackNumber: "E-02", supplierIdx: 1, description: "Adjustable antique oxidised silver kada with traditional peacock carving." },
      { name: "Kundan Polki Meenakari Designer Bangles", code: "BB-DSN-001", barcode: "8901001000110", category: "Designer Bangles", brand: "Bhavani Signature", designName: "Jaipur Meena", color: "Pastel Mint & Gold", size: "2.4", material: "Brass & Meenakari", unit: "Set", purchasePrice: 540, sellingPrice: 1150, mrp: 1350, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 22, currentStock: 16, minStockAlert: 5, rackNumber: "F-01", supplierIdx: 1, description: "Hand-painted pastel meenakari designer bangles framed with Kundan stones." },
      { name: "Blush Pink Silk Thread Zardozi Bangle Set", code: "BB-FNC-001", barcode: "8901001000127", category: "Fancy Bangles", brand: "Bhavani Boutique", designName: "Gulab Resham", color: "Blush Pink", size: "2.6", material: "Silk Thread & Beads", unit: "Set", purchasePrice: 210, sellingPrice: 480, mrp: 550, discount: 0, gstPercent: 5, hsnCode: "7117", openingStock: 35, currentStock: 27, minStockAlert: 8, rackNumber: "G-01", supplierIdx: 3, description: "Hand-wrapped silk thread festive bangles with golden kundan accents." },
      { name: "Little Princess Rainbow Glitter Kids Bangles", code: "BB-KID-001", barcode: "8901001000134", category: "Kids Bangles", brand: "Cute Sparkle", designName: "Rainbow Pop", color: "Multi Colour", size: "1.8", material: "Safe Resin", unit: "Box", purchasePrice: 75, sellingPrice: 160, mrp: 199, discount: 0, gstPercent: 5, hsnCode: "7117", openingStock: 45, currentStock: 38, minStockAlert: 10, rackNumber: "H-01", supplierIdx: 0, description: "Unbreakable lightweight glitter bangle box specially crafted for kids." },
      { name: "Rose Gold Evil Eye Crystal Cuff Bracelet", code: "BB-BRC-001", barcode: "8901001000141", category: "Bracelet Collections", brand: "Zaveri Luxe", designName: "Aura Cuff", color: "Rose Gold", size: "Free Size", material: "Stainless Steel 316L", unit: "Piece", purchasePrice: 220, sellingPrice: 499, mrp: 599, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 30, currentStock: 24, minStockAlert: 6, rackNumber: "I-01", supplierIdx: 2, description: "Anti-tarnish rose-gold cuff bracelet with crystal evil eye charm." },
      { name: "Kundan Pearl Chandbali Statement Earrings", code: "BB-EAR-001", barcode: "8901001000158", category: "Earrings", brand: "Bhavani Signature", designName: "Chandni Royal", color: "Gold & Pearl", size: "Free Size", material: "Brass & Kundan", unit: "Pair", purchasePrice: 340, sellingPrice: 750, mrp: 899, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 28, currentStock: 21, minStockAlert: 6, rackNumber: "J-01", supplierIdx: 1, description: "Regal chandbali earrings with cascading pearl drops for weddings." },
      { name: "Bridal Kundan Choker Necklace Set", code: "BB-NCK-001", barcode: "8901001000165", category: "Necklaces", brand: "Bhavani Signature", designName: "Rajputana Choker", color: "Gold & Ruby", size: "Free Size", material: "Kundan & Meenakari", unit: "Set", purchasePrice: 1450, sellingPrice: 2950, mrp: 3500, discount: 5, gstPercent: 3, hsnCode: "7117", openingStock: 12, currentStock: 9, minStockAlert: 3, rackNumber: "K-01", supplierIdx: 1, description: "Complete bridal choker necklace set with matching earrings and maang tikka." },
      { name: "Festive AD Pendant & Earring Combo", code: "BB-ART-001", barcode: "8901001000172", category: "Artificial Jewellery", brand: "Zaveri Luxe", designName: "Sparkle Drop", color: "Rose Gold & White", size: "Free Size", material: "Alloy & AD", unit: "Set", purchasePrice: 380, sellingPrice: 820, mrp: 990, discount: 0, gstPercent: 3, hsnCode: "7117", openingStock: 20, currentStock: 15, minStockAlert: 5, rackNumber: "L-01", supplierIdx: 2, description: "Delicate American diamond pendant set ideal for gifting and parties." },
      { name: "Velvet 4-Rod Luxury Bangle Organizer Box", code: "BB-ACC-001", barcode: "8901001000189", category: "Other Accessories", brand: "Bhavani Boutique", designName: "Ivory Velvet Case", color: "Ivory & Rose Gold", size: "Large", material: "Velvet & Wood", unit: "Piece", purchasePrice: 240, sellingPrice: 520, mrp: 650, discount: 0, gstPercent: 12, hsnCode: "4202", openingStock: 25, currentStock: 18, minStockAlert: 5, rackNumber: "M-01", supplierIdx: 3, description: "Premium 4-rod travel-friendly velvet bangle box with golden clasp." },
    ];

    for (const p of productSeed) {
      const created = await prisma.product.create({
        data: {
          name: p.name,
          code: p.code,
          barcode: p.barcode,
          categoryId: categoryMap[p.category],
          brand: p.brand,
          designName: p.designName,
          color: p.color,
          size: p.size,
          material: p.material,
          unit: p.unit,
          purchasePrice: p.purchasePrice,
          sellingPrice: p.sellingPrice,
          mrp: p.mrp,
          discount: p.discount,
          gstPercent: p.gstPercent,
          hsnCode: p.hsnCode,
          openingStock: p.openingStock,
          currentStock: p.currentStock,
          minStockAlert: p.minStockAlert,
          supplierId: suppliers[p.supplierIdx]?.id,
          rackNumber: p.rackNumber,
          description: p.description,
        },
      });

      await prisma.barcode.create({
        data: { productId: created.id, code: created.barcode, format: "CODE128" },
      });

      await prisma.stockMovement.create({
        data: {
          productId: created.id,
          type: "OPENING",
          quantity: p.openingStock,
          previousStock: 0,
          newStock: p.openingStock,
          reason: "Initial store inventory",
          userId: owner.id,
        },
      });
    }
  }

  const products = await prisma.product.findMany();

  // 8. Customers
  const existingCustomers = await prisma.customer.count();
  if (existingCustomers === 0) {
    const custData = [
      { name: "Ananya Rathore", phone: "9829011223", email: "ananya.r@gmail.com", address: "C-Scheme, Jaipur", birthday: "1995-03-14", anniversary: "2021-11-28", customerType: "BRIDAL", loyaltyPoints: 145, totalPurchases: 14500, outstandingAmount: 0 },
      { name: "Meenakshi Joshi", phone: "9829144556", email: "meenakshi.j@gmail.com", address: "Bapu Nagar, Jaipur", birthday: "1988-08-22", customerType: "VIP", loyaltyPoints: 210, totalPurchases: 21200, outstandingAmount: 1500 },
      { name: "Priya Maheshwari", phone: "9784512390", address: "Malviya Nagar, Jaipur", birthday: "1992-05-10", customerType: "REGULAR", loyaltyPoints: 64, totalPurchases: 6450, outstandingAmount: 0 },
      { name: "Sunita Agarwal", phone: "9414078912", address: "Raja Park, Jaipur", customerType: "WHOLESALE", loyaltyPoints: 320, totalPurchases: 32400, outstandingAmount: 4200 },
      { name: "Kavita Shekhawat", phone: "9928055667", address: "Vaishali Nagar, Jaipur", birthday: "1997-12-02", customerType: "BRIDAL", loyaltyPoints: 88, totalPurchases: 8800, outstandingAmount: 0 },
      { name: "Deepika Sharma", phone: "9636188990", address: "Tonk Road, Jaipur", customerType: "REGULAR", loyaltyPoints: 42, totalPurchases: 4200, outstandingAmount: 0 },
    ];
    for (const c of custData) {
      await prisma.customer.create({ data: c });
    }
  }
  const customers = await prisma.customer.findMany();

  // 9. Historical Sales (so Dashboard charts & analytics have rich real DB transactions!)
  const existingSales = await prisma.sale.count();
  if (existingSales === 0 && products.length >= 10 && customers.length >= 4) {
    const now = new Date();
    const saleSeeds = [
      { daysAgo: 0, inv: "BB-1001", custIdx: 0, method: "UPI", status: "PAID", items: [{ pIdx: 0, qty: 1 }, { pIdx: 14, qty: 1 }] },
      { daysAgo: 0, inv: "BB-1002", custIdx: 2, method: "CASH", status: "PAID", items: [{ pIdx: 2, qty: 3 }, { pIdx: 4, qty: 1 }] },
      { daysAgo: 0, inv: "BB-1003", custIdx: 1, method: "CARD", status: "PARTIAL", paidRatio: 0.7, items: [{ pIdx: 6, qty: 2 }, { pIdx: 10, qty: 1 }] },
      { daysAgo: 1, inv: "BB-1004", custIdx: 4, method: "UPI", status: "PAID", items: [{ pIdx: 15, qty: 1 }, { pIdx: 1, qty: 1 }] },
      { daysAgo: 2, inv: "BB-1005", custIdx: 3, method: "BANK_TRANSFER", status: "PAID", items: [{ pIdx: 3, qty: 6 }, { pIdx: 11, qty: 4 }] },
      { daysAgo: 3, inv: "BB-1006", custIdx: 5, method: "CASH", status: "PAID", items: [{ pIdx: 7, qty: 2 }, { pIdx: 12, qty: 2 }] },
      { daysAgo: 5, inv: "BB-1007", custIdx: 0, method: "CARD", status: "PAID", items: [{ pIdx: 8, qty: 1 }, { pIdx: 13, qty: 2 }] },
      { daysAgo: 8, inv: "BB-1008", custIdx: 1, method: "UPI", status: "PAID", items: [{ pIdx: 0, qty: 1 }, { pIdx: 17, qty: 2 }] },
      { daysAgo: 12, inv: "BB-1009", custIdx: 2, method: "CASH", status: "PAID", items: [{ pIdx: 5, qty: 3 }, { pIdx: 16, qty: 1 }] },
      { daysAgo: 18, inv: "BB-1010", custIdx: 3, method: "UPI", status: "PAID", items: [{ pIdx: 2, qty: 10 }, { pIdx: 4, qty: 3 }] },
      { daysAgo: 25, inv: "BB-1011", custIdx: 4, method: "CARD", status: "PAID", items: [{ pIdx: 15, qty: 1 }, { pIdx: 6, qty: 1 }] },
    ];

    for (const s of saleSeeds) {
      const saleDate = new Date(now.getTime() - s.daysAgo * 24 * 60 * 60 * 1000);
      const cust = customers[s.custIdx];
      let subtotal = 0;
      let totalGst = 0;

      const saleItemsData = s.items.map((it) => {
        const prod = products[it.pIdx];
        const lineBase = prod.sellingPrice * it.qty;
        const gstAmt = Number(((lineBase * prod.gstPercent) / 100).toFixed(2));
        subtotal += lineBase;
        totalGst += gstAmt;
        return {
          productId: prod.id,
          productName: prod.name,
          productCode: prod.code,
          hsnCode: prod.hsnCode,
          unit: prod.unit,
          quantity: it.qty,
          unitPrice: prod.sellingPrice,
          costPrice: prod.purchasePrice,
          discount: 0,
          gstPercent: prod.gstPercent,
          gstAmount: gstAmt,
          total: Number((lineBase + gstAmt).toFixed(2)),
        };
      });

      const rawGrand = subtotal + totalGst;
      const grandTotal = Math.round(rawGrand);
      const roundOff = Number((grandTotal - rawGrand).toFixed(2));
      const paidAmount = s.paidRatio ? Math.round(grandTotal * s.paidRatio) : grandTotal;
      const balanceDue = Number((grandTotal - paidAmount).toFixed(2));

      const createdSale = await prisma.sale.create({
        data: {
          invoiceNumber: s.inv,
          customerId: cust.id,
          customerName: cust.name,
          customerPhone: cust.phone,
          userId: s.daysAgo % 2 === 0 ? cashier.id : manager.id,
          saleDate,
          subtotal: Number(subtotal.toFixed(2)),
          itemDiscount: 0,
          billDiscount: 0,
          gstType: "CGST_SGST",
          cgstAmount: Number((totalGst / 2).toFixed(2)),
          sgstAmount: Number((totalGst / 2).toFixed(2)),
          igstAmount: 0,
          totalGst: Number(totalGst.toFixed(2)),
          roundOff,
          grandTotal,
          paidAmount,
          balanceDue,
          paymentStatus: s.status,
          paymentMethod: s.method,
          items: { create: saleItemsData },
          payments: {
            create: [
              {
                amount: paidAmount,
                method: s.method,
                paymentDate: saleDate,
                notes: "Invoice payment",
              },
            ],
          },
        },
      });

      await prisma.customerLedger.create({
        data: {
          customerId: cust.id,
          type: "SALE",
          amount: grandTotal,
          balance: cust.outstandingAmount,
          referenceNo: createdSale.invoiceNumber,
          notes: `Invoice ${createdSale.invoiceNumber}`,
          createdAt: saleDate,
        },
      });
    }

    await prisma.setting.update({
      where: { id: "default" },
      data: { nextInvoiceNumber: 1012 },
    });
  }

  // 10. Purchases
  const existingPurchases = await prisma.purchase.count();
  if (existingPurchases === 0 && suppliers.length > 0 && products.length >= 4) {
    const p1 = products[0];
    const p2 = products[2];
    await prisma.purchase.create({
      data: {
        purchaseNumber: "PUR-2026-001",
        supplierInvoice: "RJL-8891",
        supplierId: suppliers[1].id,
        purchaseDate: new Date(Date.now() - 4 * 86400000),
        subtotal: 12500,
        gstAmount: 375,
        totalAmount: 12875,
        paidAmount: 10000,
        pendingAmount: 2875,
        paymentStatus: "PARTIAL",
        paymentMethod: "BANK_TRANSFER",
        userId: invStaff.id,
        items: {
          create: [
            {
              productId: p1.id,
              quantity: 10,
              purchasePrice: 1250,
              gstPercent: 3,
              gstAmount: 375,
              total: 12875,
            },
          ],
        },
      },
    });

    await prisma.purchase.create({
      data: {
        purchaseNumber: "PUR-2026-002",
        supplierInvoice: "SMB-4412",
        supplierId: suppliers[0].id,
        purchaseDate: new Date(Date.now() - 10 * 86400000),
        subtotal: 4500,
        gstAmount: 225,
        totalAmount: 4725,
        paidAmount: 4725,
        pendingAmount: 0,
        paymentStatus: "PAID",
        paymentMethod: "UPI",
        userId: invStaff.id,
        items: {
          create: [
            {
              productId: p2.id,
              quantity: 50,
              purchasePrice: 90,
              gstPercent: 5,
              gstAmount: 225,
              total: 4725,
            },
          ],
        },
      },
    });
  }

  // 11. Expenses
  const existingExpenses = await prisma.expense.count();
  if (existingExpenses === 0) {
    const expSeed = [
      { category: "Shop Rent", amount: 18000, paymentMode: "BANK_TRANSFER", description: "Monthly showroom rent - Sarafa Bazaar", daysAgo: 10 },
      { category: "Electricity", amount: 3450, paymentMode: "UPI", description: "Showroom lighting & AC electricity bill", daysAgo: 6 },
      { category: "Packaging", amount: 2200, paymentMode: "CASH", description: "Custom Bhavani Bangles velvet boxes & carry bags", daysAgo: 3 },
      { category: "Transport", amount: 850, paymentMode: "CASH", description: "Firozabad parcel freight charges", daysAgo: 2 },
      { category: "Marketing", amount: 1500, paymentMode: "UPI", description: "Festive bridal collection Instagram promotion", daysAgo: 1 },
    ];
    for (const e of expSeed) {
      await prisma.expense.create({
        data: {
          category: e.category,
          amount: e.amount,
          paymentMode: e.paymentMode,
          description: e.description,
          expenseDate: new Date(Date.now() - e.daysAgo * 86400000),
          userId: owner.id,
        },
      });
    }
  }

  // 12. Sample Quotation
  const existingQuotes = await prisma.quotation.count();
  if (existingQuotes === 0 && customers.length > 0 && products.length > 2) {
    const prod = products[0];
    const subtotal = prod.sellingPrice * 2;
    const gst = Number((subtotal * 0.03).toFixed(2));
    await prisma.quotation.create({
      data: {
        quotationNumber: "QT-501",
        customerId: customers[4].id,
        customerName: customers[4].name,
        customerPhone: customers[4].phone,
        validUntil: new Date(Date.now() + 14 * 86400000),
        subtotal,
        discount: 200,
        gstType: "CGST_SGST",
        totalGst: gst,
        grandTotal: Math.round(subtotal - 200 + gst),
        status: "APPROVED",
        notes: "Bridal trousseau quotation for December wedding",
        userId: manager.id,
        items: {
          create: [
            {
              productId: prod.id,
              productName: prod.name,
              productCode: prod.code,
              unit: prod.unit,
              quantity: 2,
              unitPrice: prod.sellingPrice,
              discount: 200,
              gstPercent: 3,
              gstAmount: gst,
              total: Math.round(subtotal - 200 + gst),
            },
          ],
        },
      },
    });
    await prisma.setting.update({ where: { id: "default" }, data: { nextQuotationNumber: 502 } });
  }

  // 13. Open Cash Register for Today
  const existingReg = await prisma.cashRegister.findFirst({ where: { date: todayStr } });
  if (!existingReg) {
    await prisma.cashRegister.create({
      data: {
        date: todayStr,
        openingCash: 5000,
        cashSales: 1130,
        upiSales: 3296,
        cardSales: 2684,
        cashExpenses: 0,
        expectedCash: 6130,
        status: "OPEN",
        openedById: cashier.id,
        notes: "Morning counter shift opened",
      },
    });
  }

  // 14. Notifications for low stock / out of stock
  const existingNotifs = await prisma.notification.count();
  if (existingNotifs === 0) {
    const lowStockProducts = await prisma.product.findMany();
    for (const p of lowStockProducts) {
      if (p.currentStock === 0) {
        await prisma.notification.create({
          data: {
            type: "OUT_OF_STOCK",
            title: `Out of Stock: ${p.name}`,
            message: `${p.code} (${p.name}) has 0 units remaining. Reorder immediately.`,
            entityId: p.id,
          },
        });
      } else if (p.currentStock <= p.minStockAlert) {
        await prisma.notification.create({
          data: {
            type: "LOW_STOCK",
            title: `Low Stock Alert: ${p.name}`,
            message: `${p.code} has only ${p.currentStock} ${p.unit} left (Min: ${p.minStockAlert}).`,
            entityId: p.id,
          },
        });
      }
    }
  }

  // 15. Initial Audit Log
  const existingAudit = await prisma.auditLog.count();
  if (existingAudit === 0) {
    await prisma.auditLog.create({
      data: {
        userId: owner.id,
        username: owner.username,
        action: "SYSTEM_INIT",
        module: "settings",
        details: "BHAVANI BANGLES retail database initialized with demo catalog and transactions.",
      },
    });
  }

  console.log("BHAVANI BANGLES seed completed successfully!");
}

main()
  .catch((e) => {
    console.error("Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
