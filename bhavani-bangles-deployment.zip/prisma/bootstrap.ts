/**
 * Production Bootstrap Script (No Demo Transactions)
 * Run with: npx tsx prisma/bootstrap.ts
 * Creates roles, permissions, categories, default settings, and the initial Super Admin account.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { seedCoreStructure } from "./seed";

const prisma = new PrismaClient();

async function bootstrapProduction() {
  const { roles } = await seedCoreStructure();
  const adminPassword = process.env.INITIAL_ADMIN_PASSWORD || "BhavaniAdmin@2026";
  const hash = await bcrypt.hash(adminPassword, 10);

  await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      username: "admin",
      email: "admin@bhavanibangles.in",
      fullName: "BHAVANI BANGLES Owner",
      passwordHash: hash,
      roleId: roles.SUPER_ADMIN,
    },
  });

  console.log("Production bootstrap complete. Admin username: admin");
}

bootstrapProduction()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
